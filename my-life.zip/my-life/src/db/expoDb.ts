import * as SQLite from 'expo-sqlite';
import type { Db, SqlValue } from './db';

export async function openExpoDb(name = 'mylife.db'): Promise<Db> {
  const raw = await SQLite.openDatabaseAsync(name);
  await raw.execAsync('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
  const db: Db = {
    exec: (sql) => raw.execAsync(sql),
    run: async (sql, params: SqlValue[] = []) => {
      const r = await raw.runAsync(sql, params);
      return { lastInsertRowId: Number(r.lastInsertRowId), changes: r.changes };
    },
    all: (sql, params: SqlValue[] = []) => raw.getAllAsync(sql, params) as Promise<any[]>,
    first: async (sql, params: SqlValue[] = []) => ((await raw.getFirstAsync(sql, params)) as any) ?? null,
    transaction: (fn) => raw.withTransactionAsync(fn),
  };
  return db;
}
