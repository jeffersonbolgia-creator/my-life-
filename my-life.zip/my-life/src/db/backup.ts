// Copias de seguridad: exporta/importa todos los datos de UN perfil.
// El PIN nunca se incluye en la copia.

import { getDb } from './db';
import { profilesRepo } from './repos';
import type { Transaction } from '../types';

export const BACKUP_FORMAT = 'mylife-backup';
export const BACKUP_VERSION = 1;

const TABLES = ['tasks', 'events', 'goals', 'habits', 'notes', 'transactions', 'reminders'] as const;

export interface BackupFile {
  format: string;
  version: number;
  exportedAt: string;
  profile: { name: string; birthDate: string | null; age: number | null; avatarColor: string; answers: unknown; settings: unknown };
  tables: Record<string, any[]>;
  habitLogs: { habit_id: number; date: string }[];
}

export async function exportProfile(pid: number): Promise<BackupFile> {
  const db = getDb();
  const p = await profilesRepo.get(pid);
  if (!p) throw new Error('Perfil inexistente');
  const tables: Record<string, any[]> = {};
  for (const t of TABLES) tables[t] = await db.all(`SELECT * FROM ${t} WHERE profile_id = ? ORDER BY id`, [pid]);
  const habitLogs = await db.all<{ habit_id: number; date: string }>(
    'SELECT l.habit_id, l.date FROM habit_logs l JOIN habits h ON h.id = l.habit_id WHERE h.profile_id = ?',
    [pid],
  );
  return {
    format: BACKUP_FORMAT,
    version: BACKUP_VERSION,
    exportedAt: new Date().toISOString(),
    profile: { name: p.name, birthDate: p.birthDate, age: p.age, avatarColor: p.avatarColor, answers: p.answers, settings: p.settings },
    tables,
    habitLogs,
  };
}

const COLUMNS: Record<(typeof TABLES)[number], string[]> = {
  tasks: ['title', 'description', 'due_date', 'due_time', 'priority', 'category', 'remind_minutes', 'completed_at', 'created_at'],
  events: ['title', 'type', 'date', 'start_time', 'end_time', 'all_day', 'recurrence', 'weekdays', 'until_date', 'remind_minutes', 'location', 'notes', 'created_at'],
  goals: ['title', 'description', 'term', 'target_date', 'progress', 'completed_at', 'created_at'],
  habits: ['title', 'frequency', 'weekdays', 'target_per_week', 'reminder_time', 'color', 'icon', 'archived', 'created_at'],
  notes: ['title', 'body', 'category', 'is_list', 'items', 'favorite', 'created_at', 'updated_at'],
  transactions: ['kind', 'name', 'emoji', 'category', 'quantity', 'unit_price', 'amount', 'date', 'description', 'created_at'],
  reminders: ['title', 'kind', 'date', 'time', 'repeat', 'amount', 'notes', 'done', 'created_at'],
};

export function validateBackup(data: any): data is BackupFile {
  return !!data && data.format === BACKUP_FORMAT && typeof data.version === 'number' && data.version <= BACKUP_VERSION &&
    typeof data.tables === 'object' && data.profile && typeof data.profile.name === 'string';
}

/** Reemplaza todos los datos del perfil por los de la copia. */
export async function restoreProfile(pid: number, data: BackupFile, opts: { restoreSettings: boolean }): Promise<{ total: number }> {
  if (!validateBackup(data)) throw new Error('El archivo no es una copia válida de MY LIFE');
  const db = getDb();
  let total = 0;
  await db.transaction(async () => {
    await db.run('DELETE FROM habit_logs WHERE habit_id IN (SELECT id FROM habits WHERE profile_id = ?)', [pid]);
    for (const t of TABLES) await db.run(`DELETE FROM ${t} WHERE profile_id = ?`, [pid]);
    const habitIdMap = new Map<number, number>();
    for (const t of TABLES) {
      const rows = Array.isArray(data.tables[t]) ? data.tables[t] : [];
      const cols = COLUMNS[t];
      for (const row of rows) {
        const values = cols.map((c) => {
          const v = row[c];
          return v === undefined ? null : typeof v === 'object' && v !== null ? JSON.stringify(v) : v;
        });
        const sql = `INSERT INTO ${t} (profile_id, ${cols.join(', ')}) VALUES (?, ${cols.map(() => '?').join(', ')})`;
        const r = await db.run(sql, [pid, ...values]);
        if (t === 'habits' && typeof row.id === 'number') habitIdMap.set(row.id, r.lastInsertRowId);
        total++;
      }
    }
    for (const l of data.habitLogs ?? []) {
      const nid = habitIdMap.get(l.habit_id);
      if (nid && typeof l.date === 'string') await db.run('INSERT OR IGNORE INTO habit_logs (habit_id, date) VALUES (?,?)', [nid, l.date]);
    }
  });
  if (opts.restoreSettings) {
    const patch: Parameters<typeof profilesRepo.update>[1] = {
      birthDate: data.profile.birthDate ?? null,
      age: data.profile.age ?? null,
      answers: (data.profile.answers as any) ?? {},
    };
    if (data.profile.name) patch.name = data.profile.name;
    await profilesRepo.update(pid, patch);
    if (data.profile.settings && typeof data.profile.settings === 'object') {
      // El PIN no viaja en la copia, así que se conservan su largo y la huella actuales.
      const { pinLength: _p, biometrics: _b, ...rest } = data.profile.settings as any;
      await profilesRepo.updateSettings(pid, rest);
    }
  }
  return { total };
}

function csvCell(v: unknown): string {
  const s = v == null ? '' : String(v);
  return /[",;\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** CSV de movimientos (separado por ; para que Excel/Sheets en español lo abra bien). */
export function transactionsToCsv(txs: Transaction[]): string {
  const head = ['Fecha', 'Tipo', 'Nombre', 'Categoría', 'Cantidad', 'Precio unitario', 'Importe', 'Descripción'];
  const money = (c: number | null) => (c == null ? '' : (c / 100).toFixed(2).replace('.', ','));
  const lines = txs.map((t) =>
    [t.date, t.kind === 'income' ? 'Ingreso' : 'Gasto', t.name, t.category, String(t.quantity).replace('.', ','), money(t.unitPrice), money(t.amount), t.description]
      .map(csvCell)
      .join(';'),
  );
  return '﻿' + [head.join(';'), ...lines].join('\n');
}
