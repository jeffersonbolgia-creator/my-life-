import type { DashboardCardKey, ProfileSettings } from '../types';

export const ALL_DASHBOARD_CARDS: DashboardCardKey[] = ['today', 'tasks', 'events', 'habits', 'finance', 'reminders', 'goals', 'weekly'];

export const DASHBOARD_CARD_LABELS: Record<DashboardCardKey, string> = {
  today: 'Resumen del día',
  tasks: 'Próximas tareas',
  events: 'Próximos eventos',
  reminders: 'Recordatorios',
  habits: 'Hábitos de hoy',
  goals: 'Objetivos',
  finance: 'Resumen financiero',
  weekly: 'Resumen semanal',
};

export function defaultSettings(): ProfileSettings {
  return {
    themeMode: 'dark',
    accent: 'violet',
    gradients: true,
    haptics: true,
    compact: false,
    dashboardCards: ALL_DASHBOARD_CARDS.map((key) => ({ key, visible: true })),
    showWeeklySummary: true,
    showMonthlySummary: true,
    autoLockMinutes: 1,
    biometrics: false,
    pinLength: 4,
    notifications: {
      enabled: true,
      tasks: true,
      events: true,
      habits: true,
      payments: true,
      reminders: true,
      goals: true,
      dailySummary: false,
      dailySummaryTime: '08:00',
      defaultTime: '09:00',
      discreet: false,
    },
    currency: 'ARS',
    initialBalance: 0,
    initialBalanceDate: null,
  };
}

/** Combina la configuración guardada con los valores por defecto (por si se agregan opciones nuevas). */
export function mergeSettings(raw: Partial<ProfileSettings> | null | undefined): ProfileSettings {
  const d = defaultSettings();
  if (!raw || typeof raw !== 'object') return d;
  const cards = Array.isArray(raw.dashboardCards) ? raw.dashboardCards.filter((c) => ALL_DASHBOARD_CARDS.includes(c.key)) : d.dashboardCards;
  for (const k of ALL_DASHBOARD_CARDS) if (!cards.some((c) => c.key === k)) cards.push({ key: k, visible: true });
  return {
    ...d,
    ...raw,
    dashboardCards: cards,
    notifications: { ...d.notifications, ...(raw.notifications ?? {}) },
  };
}

export const AVATAR_COLORS = ['#8B5CF6', '#6366F1', '#D946EF', '#3B82F6', '#10B981', '#F59E0B', '#F43F5E'];

export const TASK_CATEGORIES = ['Personal', 'Estudio', 'Trabajo', 'Casa', 'Salud', 'Compras', 'Trámites'];
export const NOTE_CATEGORIES = ['General', 'Ideas', 'Estudio', 'Trabajo', 'Compras', 'Personal'];
