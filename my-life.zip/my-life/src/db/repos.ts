// Repositorios: todas las consultas filtran por profile_id, de modo que
// cada perfil sólo puede leer y modificar sus propios datos.

import { getDb, nowStamp } from './db';
import { mergeSettings } from './defaults';
import type {
  CalendarEvent, Goal, Habit, Note, NoteItem, Profile, ProfileAnswers, ProfileSettings, Reminder, Task, Transaction,
} from '../types';

const bool = (v: unknown) => v === 1 || v === true || v === '1';
const parseJSON = <T>(s: unknown, fallback: T): T => {
  if (typeof s !== 'string' || !s) return fallback;
  try {
    return JSON.parse(s) as T;
  } catch {
    return fallback;
  }
};
const numList = (s: unknown): number[] =>
  typeof s === 'string' && s ? s.split(',').map(Number).filter((n) => Number.isInteger(n) && n >= 0 && n <= 6) : [];
const listStr = (a: number[]) => [...new Set(a)].sort().join(',');

// ---------- Perfiles ----------

function mapProfile(r: any): Profile {
  return {
    id: r.id,
    name: r.name,
    birthDate: r.birth_date ?? null,
    age: r.age ?? null,
    avatarColor: r.avatar_color,
    answers: parseJSON<ProfileAnswers>(r.answers, {}),
    settings: mergeSettings(parseJSON<Partial<ProfileSettings>>(r.settings, {})),
    securityQuestion: r.security_question ?? '',
    createdAt: r.created_at,
  };
}

export const profilesRepo = {
  async list(): Promise<Profile[]> {
    return (await getDb().all('SELECT * FROM profiles ORDER BY id')).map(mapProfile);
  },
  async get(id: number): Promise<Profile | null> {
    const r = await getDb().first('SELECT * FROM profiles WHERE id = ?', [id]);
    return r ? mapProfile(r) : null;
  },
  async create(p: Omit<Profile, 'id' | 'createdAt'>): Promise<number> {
    const r = await getDb().run(
      'INSERT INTO profiles (name, birth_date, age, avatar_color, answers, settings, security_question, created_at) VALUES (?,?,?,?,?,?,?,?)',
      [p.name, p.birthDate, p.age, p.avatarColor, JSON.stringify(p.answers), JSON.stringify(p.settings), p.securityQuestion, nowStamp()],
    );
    return r.lastInsertRowId;
  },
  async update(id: number, p: Partial<Omit<Profile, 'id' | 'createdAt'>>): Promise<void> {
    const cur = await this.get(id);
    if (!cur) return;
    const n = { ...cur, ...p };
    await getDb().run(
      'UPDATE profiles SET name=?, birth_date=?, age=?, avatar_color=?, answers=?, settings=?, security_question=? WHERE id=?',
      [n.name, n.birthDate, n.age, n.avatarColor, JSON.stringify(n.answers), JSON.stringify(n.settings), n.securityQuestion, id],
    );
  },
  async updateSettings(id: number, patch: Partial<ProfileSettings>): Promise<ProfileSettings | null> {
    const cur = await this.get(id);
    if (!cur) return null;
    const settings = mergeSettings({ ...cur.settings, ...patch });
    await getDb().run('UPDATE profiles SET settings=? WHERE id=?', [JSON.stringify(settings), id]);
    return settings;
  },
  async remove(id: number): Promise<void> {
    const db = getDb();
    await db.transaction(async () => {
      await db.run('DELETE FROM habit_logs WHERE habit_id IN (SELECT id FROM habits WHERE profile_id = ?)', [id]);
      for (const t of ['tasks', 'events', 'goals', 'habits', 'notes', 'transactions', 'reminders']) {
        await db.run(`DELETE FROM ${t} WHERE profile_id = ?`, [id]);
      }
      await db.run('DELETE FROM profiles WHERE id = ?', [id]);
    });
  },
};

// ---------- Tareas ----------

function mapTask(r: any): Task {
  return {
    id: r.id,
    profileId: r.profile_id,
    title: r.title,
    description: r.description ?? '',
    dueDate: r.due_date ?? null,
    dueTime: r.due_time ?? null,
    priority: (r.priority ?? 1) as Task['priority'],
    category: r.category ?? '',
    remindMinutes: r.remind_minutes ?? null,
    completedAt: r.completed_at ?? null,
    createdAt: r.created_at,
  };
}

export type TaskInput = Omit<Task, 'id' | 'profileId' | 'createdAt' | 'completedAt'>;

export const tasksRepo = {
  async list(pid: number): Promise<Task[]> {
    return (await getDb().all(
      `SELECT * FROM tasks WHERE profile_id = ?
       ORDER BY completed_at IS NOT NULL, due_date IS NULL, due_date, due_time IS NULL, due_time, priority DESC, id DESC`,
      [pid],
    )).map(mapTask);
  },
  async get(pid: number, id: number): Promise<Task | null> {
    const r = await getDb().first('SELECT * FROM tasks WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapTask(r) : null;
  },
  async create(pid: number, t: TaskInput): Promise<number> {
    const r = await getDb().run(
      'INSERT INTO tasks (profile_id, title, description, due_date, due_time, priority, category, remind_minutes, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
      [pid, t.title, t.description, t.dueDate, t.dueTime, t.priority, t.category, t.remindMinutes, nowStamp()],
    );
    return r.lastInsertRowId;
  },
  async update(pid: number, id: number, t: TaskInput): Promise<void> {
    await getDb().run(
      'UPDATE tasks SET title=?, description=?, due_date=?, due_time=?, priority=?, category=?, remind_minutes=? WHERE id=? AND profile_id=?',
      [t.title, t.description, t.dueDate, t.dueTime, t.priority, t.category, t.remindMinutes, id, pid],
    );
  },
  async setCompleted(pid: number, id: number, done: boolean): Promise<void> {
    await getDb().run('UPDATE tasks SET completed_at=? WHERE id=? AND profile_id=?', [done ? nowStamp() : null, id, pid]);
  },
  async remove(pid: number, id: number): Promise<void> {
    await getDb().run('DELETE FROM tasks WHERE id=? AND profile_id=?', [id, pid]);
  },
};

// ---------- Eventos ----------

function mapEvent(r: any): CalendarEvent {
  return {
    id: r.id,
    profileId: r.profile_id,
    title: r.title,
    type: r.type,
    date: r.date,
    startTime: r.start_time ?? null,
    endTime: r.end_time ?? null,
    allDay: bool(r.all_day),
    recurrence: r.recurrence,
    weekdays: numList(r.weekdays),
    untilDate: r.until_date ?? null,
    remindMinutes: r.remind_minutes ?? null,
    location: r.location ?? '',
    notes: r.notes ?? '',
    createdAt: r.created_at,
  };
}

export type EventInput = Omit<CalendarEvent, 'id' | 'profileId' | 'createdAt'>;

export const eventsRepo = {
  async list(pid: number): Promise<CalendarEvent[]> {
    return (await getDb().all('SELECT * FROM events WHERE profile_id = ? ORDER BY date, start_time', [pid])).map(mapEvent);
  },
  async get(pid: number, id: number): Promise<CalendarEvent | null> {
    const r = await getDb().first('SELECT * FROM events WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapEvent(r) : null;
  },
  async create(pid: number, e: EventInput): Promise<number> {
    const r = await getDb().run(
      `INSERT INTO events (profile_id, title, type, date, start_time, end_time, all_day, recurrence, weekdays, until_date, remind_minutes, location, notes, created_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [pid, e.title, e.type, e.date, e.startTime, e.endTime, e.allDay ? 1 : 0, e.recurrence, listStr(e.weekdays), e.untilDate, e.remindMinutes, e.location, e.notes, nowStamp()],
    );
    return r.lastInsertRowId;
  },
  async update(pid: number, id: number, e: EventInput): Promise<void> {
    await getDb().run(
      `UPDATE events SET title=?, type=?, date=?, start_time=?, end_time=?, all_day=?, recurrence=?, weekdays=?, until_date=?, remind_minutes=?, location=?, notes=?
       WHERE id=? AND profile_id=?`,
      [e.title, e.type, e.date, e.startTime, e.endTime, e.allDay ? 1 : 0, e.recurrence, listStr(e.weekdays), e.untilDate, e.remindMinutes, e.location, e.notes, id, pid],
    );
  },
  async remove(pid: number, id: number): Promise<void> {
    await getDb().run('DELETE FROM events WHERE id=? AND profile_id=?', [id, pid]);
  },
};

// ---------- Objetivos ----------

function mapGoal(r: any): Goal {
  return {
    id: r.id,
    profileId: r.profile_id,
    title: r.title,
    description: r.description ?? '',
    term: r.term,
    targetDate: r.target_date ?? null,
    progress: r.progress ?? 0,
    completedAt: r.completed_at ?? null,
    createdAt: r.created_at,
  };
}

export type GoalInput = Omit<Goal, 'id' | 'profileId' | 'createdAt' | 'completedAt'>;

export const goalsRepo = {
  async list(pid: number): Promise<Goal[]> {
    return (await getDb().all(
      'SELECT * FROM goals WHERE profile_id = ? ORDER BY completed_at IS NOT NULL, target_date IS NULL, target_date, id DESC',
      [pid],
    )).map(mapGoal);
  },
  async get(pid: number, id: number): Promise<Goal | null> {
    const r = await getDb().first('SELECT * FROM goals WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapGoal(r) : null;
  },
  async create(pid: number, g: GoalInput): Promise<number> {
    const progress = Math.max(0, Math.min(100, Math.round(g.progress)));
    const r = await getDb().run(
      'INSERT INTO goals (profile_id, title, description, term, target_date, progress, completed_at, created_at) VALUES (?,?,?,?,?,?,?,?)',
      [pid, g.title, g.description, g.term, g.targetDate, progress, progress >= 100 ? nowStamp() : null, nowStamp()],
    );
    return r.lastInsertRowId;
  },
  async update(pid: number, id: number, g: GoalInput): Promise<void> {
    const cur = await this.get(pid, id);
    if (!cur) return;
    const progress = Math.max(0, Math.min(100, Math.round(g.progress)));
    const completedAt = progress >= 100 ? cur.completedAt ?? nowStamp() : null;
    await getDb().run(
      'UPDATE goals SET title=?, description=?, term=?, target_date=?, progress=?, completed_at=? WHERE id=? AND profile_id=?',
      [g.title, g.description, g.term, g.targetDate, progress, completedAt, id, pid],
    );
  },
  async setProgress(pid: number, id: number, progress: number): Promise<void> {
    const cur = await this.get(pid, id);
    if (!cur) return;
    await this.update(pid, id, { ...cur, progress });
  },
  async remove(pid: number, id: number): Promise<void> {
    await getDb().run('DELETE FROM goals WHERE id=? AND profile_id=?', [id, pid]);
  },
};

// ---------- Hábitos ----------

function mapHabit(r: any): Habit {
  return {
    id: r.id,
    profileId: r.profile_id,
    title: r.title,
    frequency: r.frequency,
    weekdays: numList(r.weekdays),
    targetPerWeek: r.target_per_week ?? 3,
    reminderTime: r.reminder_time ?? null,
    color: r.color,
    icon: r.icon,
    archived: bool(r.archived),
    createdAt: r.created_at,
  };
}

export type HabitInput = Omit<Habit, 'id' | 'profileId' | 'createdAt' | 'archived'>;

export const habitsRepo = {
  async list(pid: number, includeArchived = false): Promise<Habit[]> {
    return (await getDb().all(
      `SELECT * FROM habits WHERE profile_id = ? ${includeArchived ? '' : 'AND archived = 0'} ORDER BY archived, id`,
      [pid],
    )).map(mapHabit);
  },
  async get(pid: number, id: number): Promise<Habit | null> {
    const r = await getDb().first('SELECT * FROM habits WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapHabit(r) : null;
  },
  async create(pid: number, h: HabitInput): Promise<number> {
    const r = await getDb().run(
      'INSERT INTO habits (profile_id, title, frequency, weekdays, target_per_week, reminder_time, color, icon, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
      [pid, h.title, h.frequency, listStr(h.weekdays), h.targetPerWeek, h.reminderTime, h.color, h.icon, nowStamp()],
    );
    return r.lastInsertRowId;
  },
  async update(pid: number, id: number, h: HabitInput): Promise<void> {
    await getDb().run(
      'UPDATE habits SET title=?, frequency=?, weekdays=?, target_per_week=?, reminder_time=?, color=?, icon=? WHERE id=? AND profile_id=?',
      [h.title, h.frequency, listStr(h.weekdays), h.targetPerWeek, h.reminderTime, h.color, h.icon, id, pid],
    );
  },
  async setArchived(pid: number, id: number, archived: boolean): Promise<void> {
    await getDb().run('UPDATE habits SET archived=? WHERE id=? AND profile_id=?', [archived ? 1 : 0, id, pid]);
  },
  async remove(pid: number, id: number): Promise<void> {
    const db = getDb();
    const own = await db.first('SELECT id FROM habits WHERE id=? AND profile_id=?', [id, pid]);
    if (!own) return;
    await db.transaction(async () => {
      await db.run('DELETE FROM habit_logs WHERE habit_id=?', [id]);
      await db.run('DELETE FROM habits WHERE id=? AND profile_id=?', [id, pid]);
    });
  },
  async logs(pid: number): Promise<Map<number, Set<string>>> {
    const rows = await getDb().all<{ habit_id: number; date: string }>(
      'SELECT l.habit_id, l.date FROM habit_logs l JOIN habits h ON h.id = l.habit_id WHERE h.profile_id = ?',
      [pid],
    );
    const map = new Map<number, Set<string>>();
    for (const r of rows) {
      if (!map.has(r.habit_id)) map.set(r.habit_id, new Set());
      map.get(r.habit_id)!.add(r.date);
    }
    return map;
  },
  async toggle(pid: number, habitId: number, date: string): Promise<boolean> {
    const db = getDb();
    const own = await db.first('SELECT id FROM habits WHERE id=? AND profile_id=?', [habitId, pid]);
    if (!own) return false;
    const exists = await db.first('SELECT 1 AS x FROM habit_logs WHERE habit_id=? AND date=?', [habitId, date]);
    if (exists) {
      await db.run('DELETE FROM habit_logs WHERE habit_id=? AND date=?', [habitId, date]);
      return false;
    }
    await db.run('INSERT INTO habit_logs (habit_id, date) VALUES (?,?)', [habitId, date]);
    return true;
  },
};

// ---------- Notas ----------

function mapNote(r: any): Note {
  return {
    id: r.id,
    profileId: r.profile_id,
    title: r.title ?? '',
    body: r.body ?? '',
    category: r.category ?? '',
    isList: bool(r.is_list),
    items: parseJSON<NoteItem[]>(r.items, []),
    favorite: bool(r.favorite),
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

export type NoteInput = Pick<Note, 'title' | 'body' | 'category' | 'isList' | 'items' | 'favorite'>;

export const notesRepo = {
  async list(pid: number): Promise<Note[]> {
    return (await getDb().all('SELECT * FROM notes WHERE profile_id = ? ORDER BY favorite DESC, updated_at DESC', [pid])).map(mapNote);
  },
  async get(pid: number, id: number): Promise<Note | null> {
    const r = await getDb().first('SELECT * FROM notes WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapNote(r) : null;
  },
  async create(pid: number, n: NoteInput): Promise<number> {
    const now = nowStamp();
    const r = await getDb().run(
      'INSERT INTO notes (profile_id, title, body, category, is_list, items, favorite, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)',
      [pid, n.title, n.body, n.category, n.isList ? 1 : 0, JSON.stringify(n.items), n.favorite ? 1 : 0, now, now],
    );
    return r.lastInsertRowId;
  },
  async update(pid: number, id: number, n: NoteInput): Promise<void> {
    await getDb().run(
      'UPDATE notes SET title=?, body=?, category=?, is_list=?, items=?, favorite=?, updated_at=? WHERE id=? AND profile_id=?',
      [n.title, n.body, n.category, n.isList ? 1 : 0, JSON.stringify(n.items), n.favorite ? 1 : 0, nowStamp(), id, pid],
    );
  },
  async setFavorite(pid: number, id: number, fav: boolean): Promise<void> {
    await getDb().run('UPDATE notes SET favorite=? WHERE id=? AND profile_id=?', [fav ? 1 : 0, id, pid]);
  },
  async remove(pid: number, id: number): Promise<void> {
    await getDb().run('DELETE FROM notes WHERE id=? AND profile_id=?', [id, pid]);
  },
};

// ---------- Finanzas ----------

function mapTx(r: any): Transaction {
  return {
    id: r.id,
    profileId: r.profile_id,
    kind: r.kind,
    name: r.name,
    emoji: r.emoji ?? '',
    category: r.category ?? 'Otros',
    quantity: Number(r.quantity ?? 1),
    unitPrice: r.unit_price ?? null,
    amount: Number(r.amount),
    date: r.date,
    description: r.description ?? '',
    createdAt: r.created_at,
  };
}

export type TxInput = Omit<Transaction, 'id' | 'profileId' | 'createdAt'>;

function validateTx(t: TxInput) {
  if (!t.name.trim()) throw new Error('Falta el nombre');
  if (!Number.isFinite(t.amount) || t.amount <= 0) throw new Error('El importe debe ser mayor a cero');
}

export const financeRepo = {
  async list(pid: number): Promise<Transaction[]> {
    return (await getDb().all('SELECT * FROM transactions WHERE profile_id = ? ORDER BY date DESC, id DESC', [pid])).map(mapTx);
  },
  async get(pid: number, id: number): Promise<Transaction | null> {
    const r = await getDb().first('SELECT * FROM transactions WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapTx(r) : null;
  },
  async create(pid: number, t: TxInput): Promise<number> {
    validateTx(t);
    const r = await getDb().run(
      'INSERT INTO transactions (profile_id, kind, name, emoji, category, quantity, unit_price, amount, date, description, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
      [pid, t.kind, t.name.trim(), t.emoji, t.category, t.quantity, t.unitPrice, Math.round(t.amount), t.date, t.description, nowStamp()],
    );
    return r.lastInsertRowId;
  },
  async update(pid: number, id: number, t: TxInput): Promise<void> {
    validateTx(t);
    await getDb().run(
      'UPDATE transactions SET kind=?, name=?, emoji=?, category=?, quantity=?, unit_price=?, amount=?, date=?, description=? WHERE id=? AND profile_id=?',
      [t.kind, t.name.trim(), t.emoji, t.category, t.quantity, t.unitPrice, Math.round(t.amount), t.date, t.description, id, pid],
    );
  },
  async remove(pid: number, id: number): Promise<void> {
    await getDb().run('DELETE FROM transactions WHERE id=? AND profile_id=?', [id, pid]);
  },
};

// ---------- Recordatorios ----------

function mapReminder(r: any): Reminder {
  return {
    id: r.id,
    profileId: r.profile_id,
    title: r.title,
    kind: r.kind,
    date: r.date,
    time: r.time,
    repeat: r.repeat,
    amount: r.amount ?? null,
    notes: r.notes ?? '',
    done: bool(r.done),
    createdAt: r.created_at,
  };
}

export type ReminderInput = Omit<Reminder, 'id' | 'profileId' | 'createdAt' | 'done'>;

export const remindersRepo = {
  async list(pid: number): Promise<Reminder[]> {
    return (await getDb().all('SELECT * FROM reminders WHERE profile_id = ? ORDER BY done, date, time', [pid])).map(mapReminder);
  },
  async get(pid: number, id: number): Promise<Reminder | null> {
    const r = await getDb().first('SELECT * FROM reminders WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapReminder(r) : null;
  },
  async create(pid: number, r: ReminderInput): Promise<number> {
    const res = await getDb().run(
      'INSERT INTO reminders (profile_id, title, kind, date, time, repeat, amount, notes, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
      [pid, r.title, r.kind, r.date, r.time, r.repeat, r.amount, r.notes, nowStamp()],
    );
    return res.lastInsertRowId;
  },
  async update(pid: number, id: number, r: ReminderInput): Promise<void> {
    await getDb().run(
      'UPDATE reminders SET title=?, kind=?, date=?, time=?, repeat=?, amount=?, notes=? WHERE id=? AND profile_id=?',
      [r.title, r.kind, r.date, r.time, r.repeat, r.amount, r.notes, id, pid],
    );
  },
  async setDone(pid: number, id: number, done: boolean): Promise<void> {
    await getDb().run('UPDATE reminders SET done=? WHERE id=? AND profile_id=?', [done ? 1 : 0, id, pid]);
  },
  async remove(pid: number, id: number): Promise<void> {
    await getDb().run('DELETE FROM reminders WHERE id=? AND profile_id=?', [id, pid]);
  },
};
