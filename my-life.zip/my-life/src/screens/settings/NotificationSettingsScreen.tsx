import React, { useCallback, useState } from 'react';
import { Alert, Platform, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import * as IntentLauncher from 'expo-intent-launcher';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Button, Card, Group, Row, Screen, SectionHeader, T, TimeField, ToggleRow } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import {
  countScheduled, getPermission, openSystemNotificationSettings, requestPermission, sendTestNotification, syncProfileNotifications, type PermissionState,
} from '../../notifications/notifications';
import type { NotificationSettings } from '../../types';
import { toast } from '../../ui/haptics';

export default function NotificationSettingsScreen() {
  const t = useTheme();
  const profile = useProfile();
  const { updateSettings, suspendAutoLock } = useApp();
  const n = profile.settings.notifications;
  const [perm, setPerm] = useState<PermissionState>('undetermined');
  const [count, setCount] = useState<number | null>(null);

  const refresh = useCallback(() => {
    getPermission().then(setPerm);
    countScheduled(profile.id).then(setCount).catch(() => setCount(null));
  }, [profile.id]);
  useFocusEffect(refresh);

  const set = async (patch: Partial<NotificationSettings>) => {
    await updateSettings({ notifications: { ...n, ...patch } });
    setTimeout(refresh, 2000);
  };

  const ask = async () => {
    suspendAutoLock(30_000);
    const r = await requestPermission();
    setPerm(r);
    if (r === 'granted') {
      await syncProfileNotifications(profile.id);
      refresh();
    } else {
      Alert.alert('Permiso necesario', 'Para recibir avisos tenés que permitir las notificaciones de MY LIFE en los ajustes del teléfono.', [
        { text: 'Ahora no', style: 'cancel' },
        { text: 'Abrir ajustes', onPress: () => { suspendAutoLock(); openSystemNotificationSettings(); } },
      ]);
    }
  };

  const openBattery = async () => {
    suspendAutoLock();
    try {
      await IntentLauncher.startActivityAsync('android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS');
    } catch {
      openSystemNotificationSettings();
    }
  };

  const test = async () => {
    const ok = await sendTestNotification(profile.name.split(' ')[0]);
    toast(ok ? 'Te llegará una notificación en 5 segundos' : 'Primero permití las notificaciones');
  };

  return (
    <Screen title="Notificaciones" back>
      {perm !== 'granted' && (
        <Card accentBorder>
          <View style={{ flexDirection: 'row', gap: 12 }}>
            <Icon name="BellOff" size={22} color={t.c.warning} />
            <View style={{ flex: 1, gap: 6 }}>
              <T variant="bodyStrong">Las notificaciones están bloqueadas</T>
              <T variant="caption" secondary>MY LIFE necesita tu permiso para avisarte de tareas, eventos, hábitos y pagos aunque la app esté cerrada. No usa internet ni comparte nada.</T>
            </View>
          </View>
          <Button title="Permitir notificaciones" icon="Bell" style={{ marginTop: 14 }} onPress={ask} />
        </Card>
      )}

      <Group>
        <ToggleRow icon="Bell" title="Notificaciones de MY LIFE" subtitle="Activa o desactiva todos los avisos de tu perfil" value={n.enabled} onChange={(v) => set({ enabled: v })} />
      </Group>

      <SectionHeader title="Tipos de aviso" />
      <Group>
        <ToggleRow icon="CircleCheck" title="Tareas" subtitle="Según el aviso de cada tarea" value={n.tasks} disabled={!n.enabled} onChange={(v) => set({ tasks: v })} />
        <ToggleRow icon="CalendarDays" title="Eventos y cumpleaños" value={n.events} disabled={!n.enabled} onChange={(v) => set({ events: v })} />
        <ToggleRow icon="Repeat" title="Hábitos" subtitle="A la hora configurada en cada hábito" value={n.habits} disabled={!n.enabled} onChange={(v) => set({ habits: v })} />
        <ToggleRow icon="Receipt" title="Pagos" value={n.payments} disabled={!n.enabled} onChange={(v) => set({ payments: v })} />
        <ToggleRow icon="BellRing" title="Recordatorios" value={n.reminders} disabled={!n.enabled} onChange={(v) => set({ reminders: v })} />
        <ToggleRow icon="Target" title="Objetivos" subtitle="3 días antes y el día de la fecha límite" value={n.goals} disabled={!n.enabled} onChange={(v) => set({ goals: v })} />
        <ToggleRow icon="Sunrise" title="Resumen diario" subtitle="Un aviso por la mañana para revisar tu día" value={n.dailySummary} disabled={!n.enabled} onChange={(v) => set({ dailySummary: v })} />
      </Group>

      <SectionHeader title="Horarios" />
      <View style={{ gap: 12 }}>
        {n.dailySummary && <TimeField label="Hora del resumen diario" value={n.dailySummaryTime} onChange={(v) => v && set({ dailySummaryTime: v })} clearable={false} />}
        <TimeField label="Hora para avisos sin horario (tareas con sólo fecha, cumpleaños, objetivos)" value={n.defaultTime} onChange={(v) => v && set({ defaultTime: v })} clearable={false} />
      </View>

      <SectionHeader title="Privacidad" />
      <Group>
        <ToggleRow icon="EyeOff" title="Avisos discretos" subtitle="Muestra “Tenés un aviso nuevo” sin el detalle, para que nadie más lo lea" value={n.discreet} onChange={(v) => set({ discreet: v })} />
      </Group>

      <SectionHeader title="Funcionamiento" />
      <Group>
        <Row icon="Send" title="Enviar notificación de prueba" subtitle="Llega en 5 segundos" onPress={test} />
        {Platform.OS === 'android' && <Row icon="BatteryCharging" title="Optimización de batería" subtitle="En algunos Motorola y Samsung conviene excluir MY LIFE para que los avisos lleguen a tiempo" chevron onPress={openBattery} />}
        <Row icon="Settings2" title="Ajustes del sistema" subtitle="Sonido, vibración y canales de notificación" chevron onPress={() => { suspendAutoLock(); openSystemNotificationSettings(); }} />
      </Group>
      <T variant="small" muted align="center">
        {count != null && perm === 'granted' ? `${count} avisos programados para tu perfil.` : ''}
      </T>
    </Screen>
  );
}
