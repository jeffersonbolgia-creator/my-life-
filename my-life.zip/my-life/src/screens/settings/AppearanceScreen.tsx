import React from 'react';
import { Pressable, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Card, Group, Screen, SectionHeader, Segmented, T, ToggleRow } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { ACCENTS } from '../../theme/theme';
import type { AccentKey, ThemeMode } from '../../types';

export default function AppearanceScreen() {
  const t = useTheme();
  const profile = useProfile();
  const { updateSettings } = useApp();
  const s = profile.settings;
  return (
    <Screen title="Apariencia" back>
      <Card padding={0} style={{ overflow: 'hidden' }}>
        <LinearGradient colors={t.gradients ? t.gradient : [t.accent.base, t.accent.base]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ padding: 18 }}>
          <T variant="small" color="#FFFFFFCC">Vista previa</T>
          <T variant="title" color="#fff" style={{ marginTop: 4 }}>MY LIFE</T>
        </LinearGradient>
        <View style={{ padding: 16, flexDirection: 'row', gap: 10, alignItems: 'center' }}>
          <View style={{ width: 36, height: 36, borderRadius: 12, backgroundColor: t.accentSoft, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="Sparkles" size={18} color={t.accent.base} />
          </View>
          <View style={{ flex: 1 }}>
            <T variant="bodyStrong">Así se ven tus tarjetas</T>
            <T variant="caption" secondary>Con el color de acento elegido</T>
          </View>
        </View>
      </Card>

      <SectionHeader title="Tema" />
      <Segmented<ThemeMode>
        value={s.themeMode}
        onChange={(v) => updateSettings({ themeMode: v })}
        options={[{ value: 'dark', label: 'Oscuro' }, { value: 'light', label: 'Claro' }, { value: 'system', label: 'Automático' }]}
      />

      <SectionHeader title="Color de acento" />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
        {Object.values(ACCENTS).map((a) => (
          <Pressable key={a.key} onPress={() => updateSettings({ accent: a.key as AccentKey })} style={{ alignItems: 'center', gap: 6, width: 70 }} accessibilityLabel={a.name}>
            <LinearGradient colors={[a.deep, a.base]} style={{ width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center', borderWidth: 3, borderColor: s.accent === a.key ? t.c.text : 'transparent' }}>
              {s.accent === a.key ? <Icon name="Check" size={22} color="#fff" strokeWidth={3} /> : null}
            </LinearGradient>
            <T variant="small" secondary>{a.name}</T>
          </Pressable>
        ))}
      </View>

      <SectionHeader title="Detalles" />
      <Group>
        <ToggleRow icon="Blend" title="Degradados" subtitle="Fondos y botones con degradado sutil" value={s.gradients} onChange={(v) => updateSettings({ gradients: v })} />
        <ToggleRow icon="Rows3" title="Modo compacto" subtitle="Menos espacio entre elementos" value={s.compact} onChange={(v) => updateSettings({ compact: v })} />
        <ToggleRow icon="Vibrate" title="Vibración al tocar" subtitle="Respuesta háptica suave" value={s.haptics} onChange={(v) => updateSettings({ haptics: v })} />
      </Group>
    </Screen>
  );
}
