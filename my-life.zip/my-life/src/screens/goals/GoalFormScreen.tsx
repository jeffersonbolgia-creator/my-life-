import React, { useEffect, useState } from 'react';
import { Alert, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Card, ChipGroup, DateField, Field, FormActions, IconButton, ProgressBar, Screen, Segmented, T } from '../../ui/kit';
import { goalsRepo } from '../../db/repos';
import type { GoalTerm } from '../../types';
import { success, toast } from '../../ui/haptics';

export default function GoalFormScreen({ navigation, route }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { bump } = useApp();
  const id: number | undefined = route.params?.id;
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [term, setTerm] = useState<GoalTerm>('short');
  const [targetDate, setTargetDate] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) return;
    goalsRepo.get(profile.id, id).then((g) => {
      if (!g) return;
      setTitle(g.title);
      setDescription(g.description);
      setTerm(g.term);
      setTargetDate(g.targetDate);
      setProgress(g.progress);
    });
  }, [id, profile.id]);

  const save = async () => {
    if (!title.trim()) return setError('Escribí tu objetivo');
    setSaving(true);
    const data = { title: title.trim(), description: description.trim(), term, targetDate, progress };
    try {
      if (id) await goalsRepo.update(profile.id, id, data);
      else await goalsRepo.create(profile.id, data);
      success();
      toast(progress >= 100 ? '¡Objetivo alcanzado!' : 'Objetivo guardado');
      bump();
      navigation.goBack();
    } catch (e: any) {
      setSaving(false);
      Alert.alert('Error', String(e?.message ?? e));
    }
  };

  const remove = () =>
    Alert.alert('Eliminar objetivo', '¿Seguro?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Eliminar', style: 'destructive', onPress: async () => { await goalsRepo.remove(profile.id, id!); bump(); navigation.goBack(); } },
    ]);

  const setP = (v: number) => setProgress(Math.max(0, Math.min(100, Math.round(v))));

  return (
    <Screen title={id ? 'Editar objetivo' : 'Nuevo objetivo'} back>
      <Field label="Objetivo" value={title} onChangeText={(v) => { setTitle(v); setError(null); }} placeholder="Ej.: Ahorrar para una bici" error={error} autoFocus={!id} maxLength={100} />
      <Field label="Descripción (opcional)" value={description} onChangeText={setDescription} multiline placeholder="¿Por qué es importante? ¿Cómo lo vas a lograr?" />
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Plazo</T>
        <Segmented value={term} onChange={setTerm} options={[{ value: 'short', label: 'Corto plazo' }, { value: 'long', label: 'Largo plazo' }]} />
      </View>
      <DateField label="Fecha límite (opcional)" value={targetDate} onChange={setTargetDate} placeholder="Sin fecha límite" />
      <Card>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <T variant="bodyStrong">Progreso</T>
          <T variant="title" color={progress >= 100 ? t.c.success : t.accent.base}>{progress}%</T>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginVertical: 14 }}>
          <IconButton icon="Minus" label="Restar 5%" size={38} onPress={() => setP(progress - 5)} />
          <View style={{ flex: 1 }}><ProgressBar value={progress} height={10} color={progress >= 100 ? t.c.success : undefined} /></View>
          <IconButton icon="Plus" label="Sumar 5%" size={38} filled onPress={() => setP(progress + 5)} />
        </View>
        <ChipGroup options={[0, 25, 50, 75, 100].map((v) => ({ value: v, label: `${v}%` }))} value={progress} onChange={setP} />
        {progress >= 100 ? <T variant="small" color={t.c.success} style={{ marginTop: 10 }}>Al guardar se marcará como alcanzado.</T> : null}
      </Card>
      <FormActions onSave={save} saving={saving} onDelete={id ? remove : undefined} />
    </Screen>
  );
}
