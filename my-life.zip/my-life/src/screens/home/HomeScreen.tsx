import React from 'react';
import { Pressable, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { Avatar, Button, Card, Check, IconBox, ProgressBar, ProgressRing, Screen, SectionHeader, Stat, T, Badge } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { tasksRepo, eventsRepo, remindersRepo, habitsRepo, goalsRepo, financeRepo } from '../../db/repos';
import { todayISO, formatLongDate, greetingFor, addDays, formatRelativeDay, capitalize, monthKey } from '../../lib/dates';
import { occurrencesInRange } from '../../logic/calendar';
import { isScheduledOn, currentStreak } from '../../logic/habits';
import { availableBalance, monthSummary } from '../../logic/finance';
import { computePeriodStats, periodRange } from '../../logic/stats';
import { formatMoney } from '../../lib/money';
import { firstName } from '../../lib/text';
import { PRIORITY_COLORS } from '../agenda/shared';
import { tap } from '../../ui/haptics';

async function loadDashboard(pid: number) {
  const today = todayISO();
  const [tasks, events, reminders, habits, logs, goals, txs] = await Promise.all([
    tasksRepo.list(pid), eventsRepo.list(pid), remindersRepo.list(pid), habitsRepo.list(pid), habitsRepo.logs(pid), goalsRepo.list(pid), financeRepo.list(pid),
  ]);
  return { today, tasks, events, reminders, habits, logs, goals, txs };
}

type Dash = Awaited<ReturnType<typeof loadDashboard>>;

export default function HomeScreen() {
  const t = useTheme();
  const nav = useNavigation<any>();
  const profile = useProfile();
  const { bump } = useApp();
  const { data } = useData<Dash | null>(loadDashboard, null);
  const s = profile.settings;
  const today = todayISO();

  const header = (
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
      <View style={{ flex: 1 }}>
        <T secondary variant="caption">{capitalize(formatLongDate(today))}</T>
        <T variant="display" style={{ marginTop: 4 }} numberOfLines={1}>{greetingFor()}, {firstName(profile.name)}</T>
      </View>
      <Pressable onPress={() => nav.navigate('Settings')} accessibilityLabel="Configuración" hitSlop={8}>
        <Avatar name={profile.name} color={profile.avatarColor} size={46} />
      </Pressable>
    </View>
  );

  if (!data) return <Screen tabs hero>{header}</Screen>;

  const pending = data.tasks.filter((x) => !x.completedAt);
  const todayTasks = pending.filter((x) => x.dueDate && x.dueDate <= today);
  const doneToday = data.tasks.filter((x) => x.completedAt?.slice(0, 10) === today).length;
  const upcomingTasks = [...pending].sort((a, b) => (a.dueDate ?? '9999') .localeCompare(b.dueDate ?? '9999')).slice(0, 4);
  const occ = occurrencesInRange(data.events, today, addDays(today, 7));
  const todayEvents = occ.filter((o) => o.date === today);
  const todayHabits = data.habits.filter((h) => isScheduledOn(h, today) || h.frequency === 'weekly');
  const habitsDone = todayHabits.filter((h) => data.logs.get(h.id)?.has(today)).length;
  const activeGoals = data.goals.filter((g) => !g.completedAt).slice(0, 3);
  const upcomingRem = data.reminders.filter((r) => !r.done && (r.repeat !== 'none' || r.date >= today)).slice(0, 3);
  const month = monthKey(today);
  const fin = monthSummary(data.txs, month);
  const balance = availableBalance(data.txs, s.initialBalance, s.initialBalanceDate);
  const dayTotal = todayTasks.length + doneToday + todayHabits.length;
  const dayDone = doneToday + habitsDone;
  const dayPct = dayTotal ? Math.round((dayDone / dayTotal) * 100) : 0;

  const toggleTask = async (id: number, done: boolean) => {
    await tasksRepo.setCompleted(profile.id, id, done);
    bump();
  };
  const toggleHabit = async (id: number) => {
    await habitsRepo.toggle(profile.id, id, today);
    bump();
  };

  const cards: Record<string, React.ReactNode> = {
    today: (
      <Card gradient accentBorder key="today">
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 18 }}>
          <ProgressRing value={dayPct} size={78} stroke={8}>
            <T variant="heading">{dayPct}%</T>
          </ProgressRing>
          <View style={{ flex: 1, gap: 6 }}>
            <T variant="heading">Tu día</T>
            <T secondary variant="caption">
              {todayTasks.length ? `${todayTasks.length} tarea${todayTasks.length === 1 ? '' : 's'} pendiente${todayTasks.length === 1 ? '' : 's'}` : 'Sin tareas pendientes'}
              {' · '}
              {todayEvents.length ? `${todayEvents.length} evento${todayEvents.length === 1 ? '' : 's'}` : 'sin eventos'}
            </T>
            <T secondary variant="caption">{todayHabits.length ? `Hábitos: ${habitsDone} de ${todayHabits.length}` : 'Sin hábitos para hoy'}</T>
          </View>
        </View>
      </Card>
    ),
    tasks: (
      <View key="tasks" style={{ gap: 10 }}>
        <SectionHeader title="Próximas tareas" action="Ver todas" onAction={() => nav.navigate('Agenda', { view: 'tasks' })} />
        <Card padding={6}>
          {upcomingTasks.length === 0 ? (
            <Pressable onPress={() => nav.navigate('TaskForm')} style={{ padding: 14, flexDirection: 'row', gap: 12, alignItems: 'center' }}>
              <Icon name="CirclePlus" size={20} color={t.accent.base} />
              <T secondary>No tenés tareas pendientes. Agregá una.</T>
            </Pressable>
          ) : upcomingTasks.map((task) => {
            const overdue = !!task.dueDate && task.dueDate < today;
            return (
              <Pressable key={task.id} onPress={() => nav.navigate('TaskForm', { id: task.id })} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}>
                <Check checked={false} onPress={() => toggleTask(task.id, true)} color={PRIORITY_COLORS[task.priority]} />
                <View style={{ flex: 1 }}>
                  <T variant="bodyStrong" numberOfLines={1}>{task.title}</T>
                  {task.dueDate ? (
                    <T variant="small" color={overdue ? t.c.danger : t.c.textMuted}>
                      {overdue ? 'Atrasada · ' : ''}{formatRelativeDay(task.dueDate)}{task.dueTime ? ` · ${task.dueTime}` : ''}
                    </T>
                  ) : <T variant="small" muted>Sin fecha</T>}
                </View>
              </Pressable>
            );
          })}
        </Card>
      </View>
    ),
    events: (
      <View key="events" style={{ gap: 10 }}>
        <SectionHeader title="Próximos eventos" action="Calendario" onAction={() => nav.navigate('Agenda', { view: 'calendar' })} />
        <Card padding={6}>
          {occ.length === 0 ? (
            <T secondary style={{ padding: 14 }}>Nada agendado para los próximos 7 días.</T>
          ) : occ.slice(0, 4).map((o) => (
            <Pressable key={`${o.event.id}-${o.date}`} onPress={() => nav.navigate('EventForm', { id: o.event.id })} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}>
              <View style={{ width: 48, alignItems: 'center' }}>
                <T variant="small" color={t.accent.base}>{formatRelativeDay(o.date).split(' ')[0]}</T>
                <T variant="bodyStrong">{o.event.allDay || !o.event.startTime ? '—' : o.event.startTime}</T>
              </View>
              <View style={{ width: 3, alignSelf: 'stretch', borderRadius: 2, backgroundColor: t.accentSoft }} />
              <View style={{ flex: 1 }}>
                <T variant="bodyStrong" numberOfLines={1}>{o.event.type === 'birthday' ? `Cumpleaños de ${o.event.title}` : o.event.title}</T>
                <T variant="small" muted numberOfLines={1}>{formatRelativeDay(o.date)}{o.event.location ? ` · ${o.event.location}` : ''}</T>
              </View>
            </Pressable>
          ))}
        </Card>
      </View>
    ),
    reminders: upcomingRem.length ? (
      <View key="reminders" style={{ gap: 10 }}>
        <SectionHeader title="Recordatorios" action="Ver todos" onAction={() => nav.navigate('Reminders')} />
        <Card padding={6}>
          {upcomingRem.map((r) => (
            <Pressable key={r.id} onPress={() => nav.navigate('ReminderForm', { id: r.id })} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10 }}>
              <IconBox icon={r.kind === 'payment' ? 'Receipt' : 'BellRing'} size={34} color={r.kind === 'payment' ? '#F97316' : t.accent.base} />
              <View style={{ flex: 1 }}>
                <T variant="bodyStrong" numberOfLines={1}>{r.title}</T>
                <T variant="small" muted>
                  {r.repeat === 'none' ? formatRelativeDay(r.date) : r.repeat === 'daily' ? 'Todos los días' : r.repeat === 'weekly' ? 'Cada semana' : 'Cada mes'} · {r.time}
                  {r.amount ? ` · ${formatMoney(r.amount)}` : ''}
                </T>
              </View>
            </Pressable>
          ))}
        </Card>
      </View>
    ) : null,
    habits: (
      <View key="habits" style={{ gap: 10 }}>
        <SectionHeader title="Hábitos de hoy" action="Ver todos" onAction={() => nav.navigate('Habits')} />
        {todayHabits.length === 0 ? (
          <Card onPress={() => nav.navigate('HabitForm')}>
            <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
              <Icon name="CirclePlus" size={20} color={t.accent.base} />
              <T secondary>Creá tu primer hábito.</T>
            </View>
          </Card>
        ) : (
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
            {todayHabits.map((h) => {
              const done = !!data.logs.get(h.id)?.has(today);
              const streak = currentStreak(h, data.logs.get(h.id) ?? new Set(), today);
              return (
                <Pressable
                  key={h.id}
                  onPress={() => { tap(); toggleHabit(h.id); }}
                  style={({ pressed }) => ({
                    width: '48%', flexGrow: 1, padding: 14, borderRadius: t.radius.lg, gap: 10, opacity: pressed ? 0.8 : 1,
                    backgroundColor: done ? h.color + (t.dark ? '26' : '1C') : t.c.surface, borderWidth: 1, borderColor: done ? h.color + '66' : t.c.border,
                  })}
                  accessibilityRole="checkbox"
                  accessibilityState={{ checked: done }}
                >
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Icon name={h.icon} size={20} color={h.color} />
                    <Icon name={done ? 'CircleCheck' : 'Circle'} size={20} color={done ? h.color : t.c.textMuted} />
                  </View>
                  <T variant="bodyStrong" numberOfLines={2}>{h.title}</T>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                    <Icon name="Flame" size={13} color={streak ? '#F97316' : t.c.textMuted} />
                    <T variant="small" muted>{streak} {h.frequency === 'weekly' ? 'sem.' : 'días'}</T>
                  </View>
                </Pressable>
              );
            })}
          </View>
        )}
      </View>
    ),
    goals: (
      <View key="goals" style={{ gap: 10 }}>
        <SectionHeader title="Objetivos" action="Ver todos" onAction={() => nav.navigate('Goals')} />
        <Card>
          {activeGoals.length === 0 ? (
            <Pressable onPress={() => nav.navigate('GoalForm')} style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
              <Icon name="CirclePlus" size={20} color={t.accent.base} />
              <T secondary>Definí un objetivo para empezar.</T>
            </Pressable>
          ) : (
            <View style={{ gap: 16 }}>
              {activeGoals.map((g) => (
                <Pressable key={g.id} onPress={() => nav.navigate('GoalForm', { id: g.id })} style={{ gap: 8 }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 10 }}>
                    <T variant="bodyStrong" numberOfLines={1} style={{ flex: 1 }}>{g.title}</T>
                    <T variant="caption" color={t.accent.base}>{g.progress}%</T>
                  </View>
                  <ProgressBar value={g.progress} />
                </Pressable>
              ))}
            </View>
          )}
        </Card>
      </View>
    ),
    finance: (
      <View key="finance" style={{ gap: 10 }}>
        <SectionHeader title="Finanzas del mes" action="Abrir" onAction={() => nav.navigate('Finance')} />
        <Card onPress={() => nav.navigate('Finance')}>
          <T variant="small" secondary>Saldo disponible</T>
          <T variant="number" style={{ marginTop: 4 }} color={balance < 0 ? t.c.danger : t.c.text}>{formatMoney(balance, s.currency)}</T>
          <View style={{ flexDirection: 'row', marginTop: 14, gap: 12 }}>
            <Stat label="Ingresos" value={formatMoney(fin.income, s.currency)} color={t.c.success} icon="ArrowDownLeft" />
            <Stat label="Gastos" value={formatMoney(fin.expense, s.currency)} color={t.c.danger} icon="ArrowUpRight" />
          </View>
        </Card>
      </View>
    ),
    weekly: s.showWeeklySummary || s.showMonthlySummary ? (
      <View key="weekly" style={{ gap: 10 }}>
        <SectionHeader title="Resumen" action="Estadísticas" onAction={() => nav.navigate('Stats')} />
        {[s.showWeeklySummary && 'week', s.showMonthlySummary && 'month'].filter(Boolean).map((p) => {
          const period = p as 'week' | 'month';
          const st = computePeriodStats(periodRange(period, today), today, { tasks: data.tasks, habits: data.habits, habitLogs: data.logs, goals: data.goals, txs: data.txs });
          return (
            <Card key={period}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                <T variant="bodyStrong">{period === 'week' ? 'Esta semana' : 'Este mes'}</T>
                <Badge label={period === 'week' ? 'Semanal' : 'Mensual'} />
              </View>
              <View style={{ flexDirection: 'row', gap: 10 }}>
                <Stat label="Tareas hechas" value={String(st.tasksCompleted)} />
                <Stat label="Hábitos" value={`${st.habitRate}%`} />
                <Stat label="Gastado" value={formatMoney(st.expense, s.currency)} />
              </View>
            </Card>
          );
        })}
      </View>
    ) : null,
  };

  const visible = s.dashboardCards.filter((c) => c.visible).map((c) => cards[c.key]).filter(Boolean);

  return (
    <Screen tabs hero>
      {header}
      {visible.length ? visible : (
        <Card>
          <T secondary>Ocultaste todas las tarjetas del inicio.</T>
        </Card>
      )}
      <Button title="Personalizar inicio" icon="SlidersHorizontal" variant="ghost" size="sm" onPress={() => nav.navigate('DashboardSettings')} />
    </Screen>
  );
}
