import React from 'react';
import { Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { Avatar, Card, Group, Row, Screen, SectionHeader, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { goalsRepo, habitsRepo, notesRepo, remindersRepo } from '../../db/repos';
import { tap } from '../../ui/haptics';

export default function MoreScreen({ navigation }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { lock } = useApp();
  const { data } = useData(
    async (pid) => {
      const [g, h, n, r] = await Promise.all([goalsRepo.list(pid), habitsRepo.list(pid), notesRepo.list(pid), remindersRepo.list(pid)]);
      return { goals: g.filter((x) => !x.completedAt).length, habits: h.length, notes: n.length, reminders: r.filter((x) => !x.done).length };
    },
    { goals: 0, habits: 0, notes: 0, reminders: 0 },
  );

  const tiles = [
    { label: 'Objetivos', icon: 'Target', color: '#D946EF', route: 'Goals', count: data.goals },
    { label: 'Hábitos', icon: 'Repeat', color: '#06B6D4', route: 'Habits', count: data.habits },
    { label: 'Notas', icon: 'NotebookPen', color: '#F59E0B', route: 'Notes', count: data.notes },
    { label: 'Recordatorios', icon: 'BellRing', color: '#F97316', route: 'Reminders', count: data.reminders },
    { label: 'Estadísticas', icon: 'ChartColumn', color: '#10B981', route: 'Stats' },
    { label: 'Calendario', icon: 'CalendarDays', color: '#3B82F6', route: 'Agenda', params: { view: 'calendar' } },
  ];

  return (
    <Screen title="Más" tabs>
      <Card onPress={() => navigation.navigate('ProfileEdit')} gradient>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
          <Avatar name={profile.name} color={profile.avatarColor} size={54} />
          <View style={{ flex: 1 }}>
            <T variant="heading">{profile.name}</T>
            <T variant="caption" secondary>{profile.age != null ? `${profile.age} años · ` : ''}Ver y editar perfil</T>
          </View>
          <Icon name="ChevronRight" size={20} color={t.c.textMuted} />
        </View>
      </Card>

      <SectionHeader title="Secciones" />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {tiles.map((x) => (
          <Pressable
            key={x.label}
            onPress={() => { tap(); navigation.navigate(x.route, x.params); }}
            style={({ pressed }) => ({ width: '31.5%', flexGrow: 1, backgroundColor: t.c.surface, borderRadius: t.radius.lg, borderWidth: 1, borderColor: t.c.border, padding: 14, gap: 12, opacity: pressed ? 0.8 : 1 })}
          >
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: x.color + (t.dark ? '24' : '18'), alignItems: 'center', justifyContent: 'center' }}>
                <Icon name={x.icon} size={20} color={x.color} />
              </View>
              {x.count ? <T variant="small" muted>{x.count}</T> : null}
            </View>
            <T variant="bodyStrong" numberOfLines={1}>{x.label}</T>
          </Pressable>
        ))}
      </View>

      <SectionHeader title="Cuenta" />
      <Group>
        <Row icon="Settings" title="Configuración" subtitle="Apariencia, notificaciones, seguridad, copias" chevron onPress={() => navigation.navigate('Settings')} />
        <Row icon="LockKeyhole" title="Bloquear / cambiar de perfil" subtitle="Vuelve a la pantalla de PIN" onPress={lock} />
      </Group>
    </Screen>
  );
}
