import React, { useEffect, useRef } from 'react';
import { Animated, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTheme } from '../../state/AppContext';
import { Button, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { LogoMark } from '../../ui/Logo';

const FEATURES = [
  { icon: 'CalendarDays', text: 'Tareas, agenda y recordatorios' },
  { icon: 'Wallet', text: 'Tus finanzas claras y ordenadas' },
  { icon: 'Repeat', text: 'Hábitos y objetivos con seguimiento' },
  { icon: 'ShieldCheck', text: 'Perfil privado protegido con PIN' },
];

export default function WelcomeScreen({ navigation }: any) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const fade = useRef(new Animated.Value(0)).current;
  const rise = useRef(new Animated.Value(24)).current;
  useEffect(() => {
    Animated.parallel([
      Animated.timing(fade, { toValue: 1, duration: 700, delay: 1200, useNativeDriver: true }),
      Animated.spring(rise, { toValue: 0, delay: 1200, useNativeDriver: true, damping: 16 }),
    ]).start();
  }, [fade, rise]);

  return (
    <View style={{ flex: 1, backgroundColor: t.c.bg }}>
      <LinearGradient colors={[t.accent.deep + 'AA', t.accent.base + '22', t.c.bg]} style={{ position: 'absolute', left: 0, right: 0, top: 0, height: 460 }} />
      <Animated.View style={{ flex: 1, paddingTop: insets.top + 56, paddingHorizontal: 26, opacity: fade, transform: [{ translateY: rise }] }}>
        <LogoMark size={64} />
        <T variant="display" style={{ marginTop: 28, fontSize: 34, lineHeight: 40 }}>Tu vida,{'\n'}en orden.</T>
        <T secondary style={{ marginTop: 12, fontSize: 16, lineHeight: 23 }}>
          MY LIFE reúne tu día, tu dinero y tus metas en un solo lugar. Cada persona tiene su propio espacio privado.
        </T>
        <View style={{ marginTop: 34, gap: 16 }}>
          {FEATURES.map((f) => (
            <View key={f.text} style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
              <View style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: t.accentSoft, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name={f.icon} size={19} color={t.accent.light} />
              </View>
              <T variant="bodyStrong">{f.text}</T>
            </View>
          ))}
        </View>
      </Animated.View>
      <Animated.View style={{ paddingHorizontal: 26, paddingBottom: insets.bottom + 24, gap: 12, opacity: fade }}>
        <Button title="Comenzar" icon="ArrowRight" size="lg" onPress={() => navigation.navigate('Setup', { mode: 'first' })} />
        <T variant="small" muted align="center">Todo se guarda en tu teléfono. No necesitás internet.</T>
      </Animated.View>
    </View>
  );
}
