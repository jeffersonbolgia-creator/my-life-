import React, { useEffect, useMemo, useState } from 'react';
import { Alert, Pressable, ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as LocalAuthentication from 'expo-local-authentication';
import { useApp, useTheme } from '../../state/AppContext';
import { Button, Card, ChipGroup, DateField, Field, IconButton, ProgressBar, Segmented, T, TimeField, ToggleRow, Chip } from '../../ui/kit';
import { PinDots, PinPad } from '../../ui/PinPad';
import { Icon } from '../../ui/Icon';
import { LogoMark } from '../../ui/Logo';
import { ACCENTS } from '../../theme/theme';
import { AVATAR_COLORS } from '../../db/defaults';
import { ageFromBirth } from '../../lib/dates';
import { DayPicker } from '../../ui/DayPicker';
import { isValidPin, isWeakPin, pinInUse, SECURITY_QUESTIONS } from '../../security/pin';
import { createProfileFromSetup, HABIT_SUGGESTIONS, type ScheduleBlock } from '../../services/createProfile';
import { requestPermission } from '../../notifications/notifications';
import { firstName } from '../../lib/text';
import type { AccentKey, ThemeMode } from '../../types';
import { success } from '../../ui/haptics';

type StepId =
  | 'name' | 'birth' | 'occupation' | 'school' | 'study' | 'work' | 'activities' | 'routine'
  | 'interests' | 'goals' | 'habits' | 'pin' | 'pinConfirm' | 'recovery' | 'biometrics' | 'style' | 'notifications' | 'done';

const OCCUPATIONS = [
  { value: 'school', label: 'Voy al colegio', icon: 'School' },
  { value: 'study', label: 'Estudio', icon: 'GraduationCap' },
  { value: 'work', label: 'Trabajo', icon: 'Briefcase' },
  { value: 'none', label: 'Nada de esto por ahora', icon: 'Coffee' },
];

const ACTIVITIES = ['Fútbol', 'Gimnasio', 'Natación', 'Básquet', 'Música', 'Idiomas', 'Arte', 'Danza', 'Programación', 'Voluntariado', 'Clases particulares', 'Otro deporte'];
const INTERESTS = ['Tecnología', 'Videojuegos', 'Música', 'Deportes', 'Lectura', 'Cine y series', 'Cocina', 'Viajes', 'Moda', 'Fotografía', 'Ciencia', 'Emprender', 'Naturaleza', 'Autos', 'Anime'];
const GOAL_SUGGESTIONS = ['Ahorrar dinero', 'Aprobar todas las materias', 'Ponerme en forma', 'Aprender un idioma', 'Conseguir trabajo', 'Leer 12 libros este año', 'Ser más organizado', 'Aprender a programar'];


function ScheduleEditor({ value, onChange, label }: { value: ScheduleBlock; onChange: (v: ScheduleBlock) => void; label: string }) {
  return (
    <View style={{ gap: 14 }}>
      <T variant="caption" secondary>{label}</T>
      <DayPicker value={value.days} onChange={(days) => onChange({ ...value, days })} />
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <TimeField label="Desde" value={value.start} onChange={(start) => onChange({ ...value, start })} placeholder="--:--" />
        <TimeField label="Hasta" value={value.end} onChange={(end) => onChange({ ...value, end })} placeholder="--:--" />
      </View>
    </View>
  );
}

function CustomAdder({ placeholder, onAdd }: { placeholder: string; onAdd: (v: string) => void }) {
  const [v, setV] = useState('');
  const t = useTheme();
  const add = () => {
    if (v.trim()) onAdd(v.trim());
    setV('');
  };
  return (
    <Field
      value={v}
      onChangeText={setV}
      placeholder={placeholder}
      onSubmitEditing={add}
      returnKeyType="done"
      right={<Pressable onPress={add} hitSlop={10}><Icon name="Plus" size={20} color={t.accent.base} /></Pressable>}
    />
  );
}

export default function SetupScreen({ navigation, route }: any) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const { profiles, refreshProfiles, unlock } = useApp();
  const mode: 'first' | 'add' = route.params?.mode ?? 'first';

  const [name, setName] = useState('');
  const [birth, setBirth] = useState<string | null>(null);
  const [ageText, setAgeText] = useState('');
  const [occ, setOcc] = useState<string[]>([]);
  const [schoolLevel, setSchoolLevel] = useState<string>('Secundaria');
  const [school, setSchool] = useState<ScheduleBlock>({ title: 'Colegio', days: [1, 2, 3, 4, 5], start: null, end: null });
  const [studyWhat, setStudyWhat] = useState('');
  const [study, setStudy] = useState<ScheduleBlock>({ title: 'Estudio', days: [], start: null, end: null });
  const [workWhat, setWorkWhat] = useState('');
  const [work, setWork] = useState<ScheduleBlock>({ title: 'Trabajo', days: [1, 2, 3, 4, 5], start: null, end: null });
  const [activities, setActivities] = useState<string[]>([]);
  const [wake, setWake] = useState<string | null>(null);
  const [sleep, setSleep] = useState<string | null>(null);
  const [interests, setInterests] = useState<string[]>([]);
  const [extraInterests, setExtraInterests] = useState<string[]>([]);
  const [goals, setGoals] = useState<string[]>([]);
  const [extraGoals, setExtraGoals] = useState<string[]>([]);
  const [habits, setHabits] = useState<string[]>([]);
  const [extraHabits, setExtraHabits] = useState<string[]>([]);
  const [pinLength, setPinLength] = useState<4 | 6>(4);
  const [pin, setPin] = useState('');
  const [pin2, setPin2] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [question, setQuestion] = useState(SECURITY_QUESTIONS[0]);
  const [answer, setAnswer] = useState('');
  const [bioAvailable, setBioAvailable] = useState(false);
  const [biometrics, setBiometrics] = useState(false);
  const [themeMode, setThemeMode] = useState<ThemeMode>('dark');
  const [accent, setAccent] = useState<AccentKey>('violet');
  const [notifState, setNotifState] = useState<'idle' | 'granted' | 'denied'>('idle');
  const [saving, setSaving] = useState(false);
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    (async () => {
      try {
        const hw = await LocalAuthentication.hasHardwareAsync();
        const en = hw && (await LocalAuthentication.isEnrolledAsync());
        setBioAvailable(!!en);
      } catch {
        setBioAvailable(false);
      }
    })();
  }, []);

  const steps: StepId[] = useMemo(() => {
    const s: StepId[] = ['name', 'birth', 'occupation'];
    if (occ.includes('school')) s.push('school');
    if (occ.includes('study')) s.push('study');
    if (occ.includes('work')) s.push('work');
    s.push('activities', 'routine', 'interests', 'goals', 'habits', 'pin', 'pinConfirm', 'recovery');
    if (bioAvailable) s.push('biometrics');
    s.push('style', 'notifications', 'done');
    return s;
  }, [occ, bioAvailable]);

  const step = steps[Math.min(stepIndex, steps.length - 1)];
  const progress = ((stepIndex + 1) / steps.length) * 100;
  const fn = firstName(name) || 'vos';
  const age = birth ? ageFromBirth(birth) : ageText ? Number(ageText) : null;

  const next = () => setStepIndex((i) => Math.min(i + 1, steps.length - 1));
  const back = () => {
    if (stepIndex === 0) navigation.goBack();
    else {
      if (step === 'pinConfirm') { setPin(''); setPin2(''); }
      setPinError(null);
      setStepIndex((i) => i - 1);
    }
  };

  const otherIds = profiles.map((p) => p.id);

  const onPinDigit = async (d: string) => {
    // ignora toques extra mientras se avanza al paso siguiente
    if (step === 'pin' ? pin.length >= pinLength : pin2.length >= pinLength) return;
    setPinError(null);
    if (step === 'pin') {
      const v = (pin + d).slice(0, pinLength);
      setPin(v);
      if (v.length === pinLength) {
        if (isWeakPin(v)) {
          setPinError('Ese PIN es muy fácil de adivinar. Probá con otro.');
          setTimeout(() => setPin(''), 500);
          return;
        }
        if (await pinInUse(otherIds, v)) {
          setPinError('Ese PIN ya lo usa otro perfil. Elegí uno distinto.');
          setTimeout(() => setPin(''), 500);
          return;
        }
        setTimeout(next, 180);
      }
    } else {
      const v = (pin2 + d).slice(0, pinLength);
      setPin2(v);
      if (v.length === pinLength) {
        if (v !== pin) {
          setPinError('Los PIN no coinciden. Volvé a intentarlo.');
          setTimeout(() => setPin2(''), 500);
        } else setTimeout(next, 180);
      }
    }
  };

  const canContinue = (): boolean => {
    switch (step) {
      case 'name': return name.trim().length >= 2;
      case 'birth': return !ageText || (Number(ageText) > 0 && Number(ageText) < 120);
      case 'occupation': return occ.length > 0;
      case 'recovery': return answer.trim().length >= 2;
      default: return true;
    }
  };

  const finish = async () => {
    if (!isValidPin(pin, pinLength)) return;
    setSaving(true);
    try {
      const schedules: ScheduleBlock[] = [];
      if (occ.includes('school')) schedules.push({ ...school, title: 'Colegio' });
      if (occ.includes('study')) schedules.push({ ...study, title: studyWhat.trim() || 'Estudio' });
      if (occ.includes('work')) schedules.push({ ...work, title: workWhat.trim() ? `Trabajo · ${workWhat.trim()}` : 'Trabajo' });
      const avatarColor = AVATAR_COLORS[(profiles.length * 3 + name.length) % AVATAR_COLORS.length];
      const pid = await createProfileFromSetup(
        {
          name: name.trim(),
          birthDate: birth,
          age: age && Number.isFinite(age) ? age : null,
          answers: {
            studiesAtSchool: occ.includes('school'),
            schoolLevel: occ.includes('school') ? schoolLevel : undefined,
            studies: occ.includes('study'),
            studyWhat: studyWhat.trim() || undefined,
            works: occ.includes('work'),
            workWhat: workWhat.trim() || undefined,
            activities,
            interests: [...interests, ...extraInterests],
            goals: [...goals, ...extraGoals],
            habitsToImprove: [...habits, ...extraHabits],
            wakeTime: wake ?? undefined,
            sleepTime: sleep ?? undefined,
          },
          schedules,
          goals: [...goals, ...extraGoals],
          habits: [...habits, ...extraHabits],
          pin,
          pinLength,
          securityQuestion: question,
          securityAnswer: answer,
          biometrics,
          themeMode,
          accent,
          avatarColor,
        },
        otherIds,
      );
      success();
      await refreshProfiles();
      await unlock(pid);
    } catch (e: any) {
      Alert.alert('No se pudo crear el perfil', String(e?.message ?? e));
      setSaving(false);
    }
  };

  const Title = ({ title, text }: { title: string; text?: string }) => (
    <View style={{ gap: 8, marginBottom: 22 }}>
      <T variant="title" style={{ fontSize: 26, lineHeight: 32 }}>{title}</T>
      {text ? <T secondary style={{ fontSize: 15.5, lineHeight: 22 }}>{text}</T> : null}
    </View>
  );

  const renderStep = () => {
    switch (step) {
      case 'name':
        return (
          <>
            <LogoMark size={52} />
            <View style={{ height: 22 }} />
            <Title
              title={mode === 'add' ? 'Nuevo perfil' : '¡Hola! ¿Cómo te llamás?'}
              text={mode === 'add' ? 'Este perfil tendrá su propio PIN y sus datos serán privados.' : 'Vamos a armar tu espacio en unos pocos pasos. Podés saltear lo que quieras y editarlo después.'}
            />
            <Field label="Tu nombre" value={name} onChangeText={setName} placeholder="Ej.: Juan" autoFocus autoCapitalize="words" returnKeyType="next" onSubmitEditing={() => canContinue() && next()} maxLength={40} />
          </>
        );
      case 'birth':
        return (
          <>
            <Title title={`Un gusto, ${fn}.`} text="¿Cuándo es tu cumpleaños? Lo agregamos a tu calendario para recordártelo." />
            <View style={{ gap: 16 }}>
              <DateField label="Fecha de nacimiento" value={birth} onChange={(v) => { setBirth(v); if (v) setAgeText(''); }} maximumDate={new Date()} placeholder="Elegir fecha" />
              {!birth && (
                <Field label="O sólo tu edad" value={ageText} onChangeText={(v) => setAgeText(v.replace(/\D/g, '').slice(0, 3))} keyboardType="number-pad" placeholder="Ej.: 17" />
              )}
              {birth && age != null ? <T secondary>Tenés {age} años.</T> : null}
            </View>
          </>
        );
      case 'occupation':
        return (
          <>
            <Title title="¿A qué te dedicás?" text="Podés elegir más de una opción. Así adaptamos tus horarios." />
            <View style={{ gap: 10 }}>
              {OCCUPATIONS.map((o) => {
                const on = occ.includes(o.value);
                return (
                  <Card
                    key={o.value}
                    accentBorder={on}
                    onPress={() => {
                      if (o.value === 'none') setOcc(on ? [] : ['none']);
                      else setOcc((cur) => (on ? cur.filter((x) => x !== o.value) : [...cur.filter((x) => x !== 'none'), o.value]));
                    }}
                    style={on ? { backgroundColor: t.accentSofter } : undefined}
                  >
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                      <Icon name={o.icon} size={22} color={on ? t.accent.base : t.c.textSecondary} />
                      <T variant="bodyStrong" style={{ flex: 1 }}>{o.label}</T>
                      <Icon name={on ? 'CircleCheck' : 'Circle'} size={22} color={on ? t.accent.base : t.c.textMuted} />
                    </View>
                  </Card>
                );
              })}
            </View>
          </>
        );
      case 'school':
        return (
          <>
            <Title title="Tu colegio" text="¿Qué días y en qué horario vas? Lo cargamos como horario semanal y te avisamos antes." />
            <View style={{ gap: 18 }}>
              <ChipGroup options={['Primaria', 'Secundaria', 'Otro'].map((v) => ({ value: v, label: v }))} value={schoolLevel} onChange={setSchoolLevel} />
              <ScheduleEditor value={school} onChange={setSchool} label="Días y horario" />
            </View>
          </>
        );
      case 'study':
        return (
          <>
            <Title title="¿Qué estudiás?" text="Facultad, terciario, un curso... Si tenés horario fijo, agregalo." />
            <View style={{ gap: 18 }}>
              <Field label="Carrera o curso" value={studyWhat} onChangeText={setStudyWhat} placeholder="Ej.: Ingeniería, curso de inglés" />
              <ScheduleEditor value={study} onChange={setStudy} label="Días y horario (opcional)" />
            </View>
          </>
        );
      case 'work':
        return (
          <>
            <Title title="Tu trabajo" text="¿De qué trabajás y cuál es tu horario?" />
            <View style={{ gap: 18 }}>
              <Field label="Trabajo (opcional)" value={workWhat} onChangeText={setWorkWhat} placeholder="Ej.: Atención al cliente" />
              <ScheduleEditor value={work} onChange={setWork} label="Días y horario" />
            </View>
          </>
        );
      case 'activities':
        return (
          <>
            <Title title="¿Qué actividades hacés?" text="Deportes, clases, hobbies con horario..." />
            <ChipGroup multi options={ACTIVITIES.map((v) => ({ value: v, label: v }))} value={activities} onChange={setActivities} />
          </>
        );
      case 'routine':
        return (
          <>
            <Title title="Tu rutina" text="Con tu hora de levantarte te mandamos un resumen del día cada mañana (lo podés desactivar)." />
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <TimeField label="Me levanto" value={wake} onChange={setWake} placeholder="--:--" />
              <TimeField label="Me acuesto" value={sleep} onChange={setSleep} placeholder="--:--" />
            </View>
          </>
        );
      case 'interests':
        return (
          <>
            <Title title="¿Qué te interesa?" text="Elegí todo lo que quieras." />
            <View style={{ gap: 16 }}>
              <ChipGroup multi options={[...INTERESTS, ...extraInterests].map((v) => ({ value: v, label: v }))} value={[...interests, ...extraInterests]} onChange={(v: string[]) => { setInterests(v.filter((x) => INTERESTS.includes(x))); setExtraInterests(v.filter((x) => !INTERESTS.includes(x))); }} />
              <CustomAdder placeholder="Agregar otro interés" onAdd={(v) => setExtraInterests((c) => (c.includes(v) ? c : [...c, v]))} />
            </View>
          </>
        );
      case 'goals':
        return (
          <>
            <Title title="¿Qué objetivos tenés?" text="Los guardamos en tu sección de objetivos para que puedas seguir tu progreso." />
            <View style={{ gap: 16 }}>
              <ChipGroup multi options={[...GOAL_SUGGESTIONS, ...extraGoals].map((v) => ({ value: v, label: v }))} value={[...goals, ...extraGoals]} onChange={(v: string[]) => { setGoals(v.filter((x) => GOAL_SUGGESTIONS.includes(x))); setExtraGoals(v.filter((x) => !GOAL_SUGGESTIONS.includes(x))); }} />
              <CustomAdder placeholder="Escribir un objetivo propio" onAdd={(v) => setExtraGoals((c) => (c.includes(v) ? c : [...c, v]))} />
            </View>
          </>
        );
      case 'habits': {
        const sug = HABIT_SUGGESTIONS.map((h) => h.title);
        return (
          <>
            <Title title="¿Qué hábitos querés mejorar?" text="Los vas a poder marcar cada día y ver tus rachas." />
            <View style={{ gap: 16 }}>
              <ChipGroup
                multi
                options={[...HABIT_SUGGESTIONS.map((h) => ({ value: h.title, label: h.title, icon: h.icon })), ...extraHabits.map((v) => ({ value: v, label: v, icon: 'Sparkles' }))]}
                value={[...habits, ...extraHabits]}
                onChange={(v: string[]) => { setHabits(v.filter((x) => sug.includes(x))); setExtraHabits(v.filter((x) => !sug.includes(x))); }}
              />
              <CustomAdder placeholder="Agregar otro hábito" onAdd={(v) => setExtraHabits((c) => (c.includes(v) ? c : [...c, v]))} />
            </View>
          </>
        );
      }
      case 'pin':
      case 'pinConfirm':
        return (
          <View style={{ alignItems: 'stretch' }}>
            <Title
              title={step === 'pin' ? 'Creá tu PIN' : 'Confirmá tu PIN'}
              text={step === 'pin' ? 'Con este PIN entrás a tu perfil. Tiene que ser distinto al de las otras personas.' : 'Ingresalo de nuevo para confirmar.'}
            />
            {step === 'pin' && (
              <Segmented
                style={{ marginBottom: 26 }}
                value={String(pinLength)}
                options={[{ value: '4', label: '4 dígitos' }, { value: '6', label: '6 dígitos' }]}
                onChange={(v) => { setPinLength(v === '6' ? 6 : 4); setPin(''); }}
              />
            )}
            <PinDots length={pinLength} filled={step === 'pin' ? pin.length : pin2.length} error={!!pinError} />
            <T variant="caption" color={pinError ? t.c.danger : t.c.textMuted} align="center" style={{ marginTop: 14, minHeight: 36 }}>
              {pinError ?? ' '}
            </T>
            <PinPad onDigit={onPinDigit} onDelete={() => (step === 'pin' ? setPin((p) => p.slice(0, -1)) : setPin2((p) => p.slice(0, -1)))} />
          </View>
        );
      case 'recovery':
        return (
          <>
            <Title title="Recuperación del PIN" text="Si te olvidás el PIN, vas a poder crear uno nuevo respondiendo esta pregunta. Elegí una respuesta que sólo vos sepas." />
            <View style={{ gap: 16 }}>
              <View style={{ gap: 8 }}>
                {SECURITY_QUESTIONS.map((q) => (
                  <Chip key={q} label={q} selected={q === question} onPress={() => setQuestion(q)} />
                ))}
              </View>
              <Field label="Respuesta" value={answer} onChangeText={setAnswer} placeholder="Tu respuesta" autoCapitalize="none" hint="No distingue mayúsculas ni acentos." />
            </View>
          </>
        );
      case 'biometrics':
        return (
          <>
            <Title title="Huella digital" text="Podés entrar a tu perfil con tu huella en lugar del PIN." />
            <Card>
              <ToggleRow icon="Fingerprint" title="Desbloquear con huella" value={biometrics} onChange={setBiometrics} />
            </Card>
            <Card style={{ marginTop: 14, backgroundColor: t.c.surface2 }}>
              <View style={{ flexDirection: 'row', gap: 12 }}>
                <Icon name="Info" size={18} color={t.c.warning} />
                <T variant="caption" secondary style={{ flex: 1 }}>
                  El teléfono no distingue de quién es cada huella. Activalo sólo si en este teléfono no hay huellas de otras personas registradas.
                </T>
              </View>
            </Card>
          </>
        );
      case 'style':
        return (
          <>
            <Title title="Tu estilo" text="Elegí cómo querés ver tu MY LIFE. Lo podés cambiar cuando quieras." />
            <View style={{ gap: 22 }}>
              <Segmented value={themeMode} onChange={setThemeMode} options={[{ value: 'dark', label: 'Oscuro' }, { value: 'light', label: 'Claro' }, { value: 'system', label: 'Automático' }]} />
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 14 }}>
                {Object.values(ACCENTS).map((a) => (
                  <Pressable key={a.key} onPress={() => setAccent(a.key)} style={{ alignItems: 'center', gap: 6, width: 64 }} accessibilityLabel={a.name}>
                    <View style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: a.base, alignItems: 'center', justifyContent: 'center', borderWidth: 3, borderColor: accent === a.key ? t.c.text : 'transparent' }}>
                      {accent === a.key ? <Icon name="Check" size={20} color="#fff" strokeWidth={3} /> : null}
                    </View>
                    <T variant="small" secondary>{a.name}</T>
                  </Pressable>
                ))}
              </View>
            </View>
          </>
        );
      case 'notifications':
        return (
          <>
            <Title title="Notificaciones" text="MY LIFE usa notificaciones del teléfono para avisarte de tareas, eventos, hábitos, pagos y objetivos, aunque la app esté cerrada. Funcionan sin internet." />
            <Card>
              <View style={{ gap: 14 }}>
                {[
                  ['BellRing', 'Recordatorios a la hora que elijas'],
                  ['Cake', 'Cumpleaños y fechas importantes'],
                  ['Wallet', 'Avisos de pagos'],
                  ['SlidersHorizontal', 'Activás o desactivás cada tipo'],
                ].map(([i, txt]) => (
                  <View key={txt} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                    <Icon name={i} size={19} color={t.accent.base} />
                    <T>{txt}</T>
                  </View>
                ))}
              </View>
            </Card>
            <View style={{ marginTop: 18 }}>
              {notifState === 'granted' ? (
                <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center' }}>
                  <Icon name="CircleCheck" size={20} color={t.c.success} />
                  <T color={t.c.success}>Notificaciones activadas</T>
                </View>
              ) : (
                <Button
                  title={notifState === 'denied' ? 'Permiso denegado (podés activarlo luego)' : 'Permitir notificaciones'}
                  variant={notifState === 'denied' ? 'secondary' : 'primary'}
                  icon="Bell"
                  onPress={async () => {
                    const r = await requestPermission();
                    setNotifState(r === 'granted' ? 'granted' : 'denied');
                  }}
                />
              )}
            </View>
          </>
        );
      case 'done':
        return (
          <View style={{ alignItems: 'center', paddingTop: 30 }}>
            <View style={{ width: 84, height: 84, borderRadius: 30, backgroundColor: t.accentSoft, alignItems: 'center', justifyContent: 'center', marginBottom: 24 }}>
              <Icon name="Sparkles" size={38} color={t.accent.base} />
            </View>
            <T variant="title" align="center" style={{ fontSize: 26 }}>Todo listo, {fn}</T>
            <T secondary align="center" style={{ marginTop: 10, fontSize: 15.5, lineHeight: 22 }}>
              Tu espacio está preparado
              {goals.length + extraGoals.length ? ` con ${goals.length + extraGoals.length} objetivo(s)` : ''}
              {habits.length + extraHabits.length ? ` y ${habits.length + extraHabits.length} hábito(s)` : ''}. Recordá tu PIN: lo vas a usar cada vez que entres.
            </T>
          </View>
        );
    }
  };

  const isPinStep = step === 'pin' || step === 'pinConfirm';

  return (
    <View style={{ flex: 1, backgroundColor: t.c.bg, paddingTop: insets.top + 6 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 18, paddingBottom: 8 }}>
        <IconButton icon="ChevronLeft" label="Atrás" onPress={back} />
        <View style={{ flex: 1 }}>
          <ProgressBar value={progress} height={5} />
        </View>
        <T variant="small" muted>{stepIndex + 1}/{steps.length}</T>
      </View>
      <ScrollView contentContainerStyle={{ padding: 22, paddingTop: 22, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
        {renderStep()}
      </ScrollView>
      {!isPinStep && (
        <View style={{ paddingHorizontal: 22, paddingBottom: insets.bottom + 18, gap: 8 }}>
          {step === 'done' ? (
            <Button title="Entrar a MY LIFE" icon="ArrowRight" size="lg" loading={saving} onPress={finish} />
          ) : (
            <>
              <Button title="Continuar" size="lg" disabled={!canContinue()} onPress={next} />
              {!['name', 'occupation', 'recovery', 'style', 'notifications'].includes(step) && (
                <Button title="Saltar" variant="ghost" onPress={next} size="sm" />
              )}
            </>
          )}
        </View>
      )}
    </View>
  );
}
