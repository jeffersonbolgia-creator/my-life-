import React, { useEffect, useMemo, useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Card, ChipGroup, DateField, Field, FormActions, Screen, Segmented, T } from '../../ui/kit';
import { financeRepo } from '../../db/repos';
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '../../logic/finance';
import { centsToInput, formatMoney, multiplyAmount, parseAmount, parseQuantity } from '../../lib/money';
import { todayISO } from '../../lib/dates';
import type { TxKind } from '../../types';
import { success, toast } from '../../ui/haptics';

const EMOJIS = ['🛒', '🍔', '🥤', '☕', '🍕', '🚌', '⛽', '🏠', '💡', '📱', '👕', '🎮', '🎬', '💊', '📚', '🎁', '🐶', '✂️', '🏋️', '💸'];

export default function TxFormScreen({ navigation, route }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { bump } = useApp();
  const id: number | undefined = route.params?.id;
  const [kind, setKind] = useState<TxKind>(route.params?.kind ?? 'expense');
  const [name, setName] = useState('');
  const [emoji, setEmoji] = useState('');
  const [category, setCategory] = useState(kind === 'income' ? 'Sueldo' : 'Comida');
  const [mode, setMode] = useState<'units' | 'total'>('units');
  const [qty, setQty] = useState('1');
  const [unit, setUnit] = useState('');
  const [total, setTotal] = useState('');
  const [date, setDate] = useState<string | null>(todayISO());
  const [description, setDescription] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) return;
    financeRepo.get(profile.id, id).then((x) => {
      if (!x) return;
      setKind(x.kind);
      setName(x.name);
      setEmoji(x.emoji);
      setCategory(x.category);
      setDate(x.date);
      setDescription(x.description);
      if (x.unitPrice != null) {
        setMode('units');
        setQty(String(x.quantity).replace('.', ','));
        setUnit(centsToInput(x.unitPrice));
      } else {
        setMode('total');
        setTotal(centsToInput(x.amount));
      }
    });
  }, [id, profile.id]);

  const cats = kind === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;
  const computed = useMemo(() => {
    if (kind === 'income' || mode === 'total') return parseAmount(total);
    const q = parseQuantity(qty);
    const u = parseAmount(unit);
    return q != null && u != null ? multiplyAmount(q, u) : null;
  }, [kind, mode, qty, unit, total]);

  const switchKind = (k: TxKind) => {
    setKind(k);
    setCategory(k === 'income' ? 'Sueldo' : 'Comida');
    if (k === 'income') setMode('total');
  };

  const save = async () => {
    const e: Record<string, string> = {};
    if (!name.trim()) e.name = kind === 'income' ? 'Escribí de dónde viene el ingreso' : 'Escribí qué compraste';
    if (kind === 'expense' && mode === 'units') {
      if (parseQuantity(qty) == null) e.qty = 'Cantidad inválida';
      if (parseAmount(unit) == null || parseAmount(unit)! <= 0) e.unit = 'Precio inválido';
    } else if (computed == null || computed <= 0) e.total = 'Importe inválido';
    if (!date) e.date = 'Elegí la fecha';
    setErrors(e);
    if (Object.keys(e).length) return;
    setSaving(true);
    const units = kind === 'expense' && mode === 'units';
    const data = {
      kind,
      name: name.trim(),
      emoji: kind === 'expense' ? emoji : '',
      category,
      quantity: units ? parseQuantity(qty)! : 1,
      unitPrice: units ? parseAmount(unit)! : null,
      amount: computed!,
      date: date!,
      description: description.trim(),
    };
    try {
      if (id) await financeRepo.update(profile.id, id, data);
      else await financeRepo.create(profile.id, data);
      success();
      toast(kind === 'income' ? 'Ingreso registrado' : 'Gasto registrado');
      bump();
      navigation.goBack();
    } catch (err: any) {
      setSaving(false);
      Alert.alert('Error', String(err?.message ?? err));
    }
  };

  const remove = () =>
    Alert.alert('Eliminar movimiento', '¿Seguro que querés eliminarlo?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Eliminar', style: 'destructive', onPress: async () => { await financeRepo.remove(profile.id, id!); bump(); navigation.goBack(); } },
    ]);

  return (
    <Screen title={id ? 'Editar movimiento' : kind === 'income' ? 'Nuevo ingreso' : 'Nuevo gasto'} back>
      <Segmented value={kind} onChange={switchKind} options={[{ value: 'expense', label: 'Gasto' }, { value: 'income', label: 'Ingreso' }]} />

      <Card gradient accentBorder style={{ alignItems: 'center' }}>
        <T variant="small" secondary>Total</T>
        <T variant="display" color={kind === 'income' ? t.c.success : t.c.text} style={{ marginTop: 4 }}>
          {computed != null && computed > 0 ? formatMoney(computed, profile.settings.currency) : '$ 0'}
        </T>
      </Card>

      <Field
        label={kind === 'income' ? 'Descripción del ingreso' : 'Producto o compra'}
        value={name}
        onChangeText={setName}
        placeholder={kind === 'income' ? 'Ej.: Sueldo de noviembre' : 'Ej.: Gaseosa'}
        error={errors.name}
        autoFocus={!id}
        maxLength={80}
      />

      {kind === 'expense' && (
        <View style={{ gap: 8 }}>
          <T variant="caption" secondary>Emoji (opcional)</T>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {EMOJIS.map((e) => (
              <Pressable
                key={e}
                onPress={() => setEmoji(emoji === e ? '' : e)}
                style={{ width: 42, height: 42, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: emoji === e ? t.accentSoft : t.c.surface2, borderWidth: 1, borderColor: emoji === e ? t.accent.base : t.c.border }}
              >
                <T style={{ fontSize: 20 }}>{e}</T>
              </Pressable>
            ))}
          </View>
        </View>
      )}

      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Categoría</T>
        <ChipGroup options={cats.map((c) => ({ value: c, label: c }))} value={category} onChange={setCategory} />
      </View>

      {kind === 'expense' && (
        <Segmented value={mode} onChange={setMode} options={[{ value: 'units', label: 'Por unidades' }, { value: 'total', label: 'Importe total' }]} />
      )}

      {kind === 'expense' && mode === 'units' ? (
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Field label="Cantidad" value={qty} onChangeText={setQty} keyboardType="decimal-pad" style={{ flex: 0.8 }} error={errors.qty} selectTextOnFocus />
          <Field label="Precio por unidad" value={unit} onChangeText={setUnit} keyboardType="decimal-pad" prefix="$" placeholder="0" style={{ flex: 1.2 }} error={errors.unit} />
        </View>
      ) : (
        <Field label="Importe" value={total} onChangeText={setTotal} keyboardType="decimal-pad" prefix="$" placeholder="0" error={errors.total} />
      )}
      {kind === 'expense' && mode === 'units' && computed != null && parseQuantity(qty) != null && (
        <T variant="caption" secondary>{qty} × {formatMoney(parseAmount(unit) ?? 0)} = {formatMoney(computed)}</T>
      )}

      <DateField label={kind === 'income' ? 'Fecha' : 'Fecha de compra'} value={date} onChange={setDate} clearable={false} />
      <Field label="Descripción (opcional)" value={description} onChangeText={setDescription} multiline placeholder="Notas sobre este movimiento" />
      <FormActions onSave={save} saving={saving} onDelete={id ? remove : undefined} />
    </Screen>
  );
}
