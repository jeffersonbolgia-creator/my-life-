import React, { useState } from 'react';
import { Pressable, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { Button, Card, DateField, EmptyState, Field, IconButton, Screen, SectionHeader, Sheet, T } from '../../ui/kit';
import { Donut, GroupedBars, Legend } from '../../ui/charts';
import { Icon } from '../../ui/Icon';
import { financeRepo } from '../../db/repos';
import { availableBalance, categoryBreakdown, monthlySeries, monthSummary, percentChange, dailyAverageExpense } from '../../logic/finance';
import { addMonthsToKey, formatMonthYear, monthKey, todayISO, MONTHS_SHORT, formatRelativeDay } from '../../lib/dates';
import { formatMoney, formatMoneyCompact, parseAmount, centsToInput, formatQuantity } from '../../lib/money';
import { CATEGORY_COLORS } from '../../theme/theme';
import type { Transaction } from '../../types';
import { toast } from '../../ui/haptics';

export function TxRow({ tx, onPress, onLongPress }: { tx: Transaction; onPress?: () => void; onLongPress?: () => void }) {
  const t = useTheme();
  const income = tx.kind === 'income';
  return (
    <Pressable onPress={onPress} onLongPress={onLongPress} delayLongPress={350} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 11, paddingHorizontal: 12 }}>
      <View style={{ width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: income ? t.c.success + '1F' : t.c.surface2 }}>
        {tx.emoji ? <T style={{ fontSize: 20 }}>{tx.emoji}</T> : <Icon name={income ? 'ArrowDownLeft' : 'ShoppingBag'} size={19} color={income ? t.c.success : t.c.textSecondary} />}
      </View>
      <View style={{ flex: 1 }}>
        <T variant="bodyStrong" numberOfLines={1}>{tx.name}</T>
        <T variant="small" muted numberOfLines={1}>
          {tx.category} · {formatRelativeDay(tx.date)}
          {tx.quantity !== 1 || tx.unitPrice ? ` · ${formatQuantity(tx.quantity)} × ${tx.unitPrice ? formatMoney(tx.unitPrice) : ''}` : ''}
        </T>
      </View>
      <T variant="bodyStrong" color={income ? t.c.success : t.c.text}>{income ? '+' : '-'}{formatMoney(tx.amount).replace('-', '')}</T>
    </Pressable>
  );
}

export default function FinanceScreen() {
  const t = useTheme();
  const nav = useNavigation<any>();
  const profile = useProfile();
  const { updateSettings } = useApp();
  const s = profile.settings;
  const today = todayISO();
  const [month, setMonth] = useState(monthKey(today));
  const [balOpen, setBalOpen] = useState(false);
  const [balText, setBalText] = useState('');
  const [balDate, setBalDate] = useState<string | null>(null);
  const { data: txs } = useData<Transaction[]>((pid) => financeRepo.list(pid), []);

  const sum = monthSummary(txs, month);
  const prev = monthSummary(txs, addMonthsToKey(month, -1));
  const balance = availableBalance(txs, s.initialBalance, s.initialBalanceDate);
  const cats = categoryBreakdown(txs, month, 'expense');
  const series = monthlySeries(txs, month, 6);
  const change = percentChange(sum.expense, prev.expense);
  const recent = txs.filter((x) => monthKey(x.date) === month).slice(0, 8);
  const avg = dailyAverageExpense(txs, month, today);
  const isCurrent = month === monthKey(today);

  const openBalance = () => {
    setBalText(s.initialBalance ? centsToInput(s.initialBalance) : '');
    setBalDate(s.initialBalanceDate);
    setBalOpen(true);
  };
  const saveBalance = async () => {
    const v = balText.trim() ? parseAmount(balText) : 0;
    if (v == null) return toast('Importe inválido');
    await updateSettings({ initialBalance: v, initialBalanceDate: balDate });
    setBalOpen(false);
    toast('Saldo inicial guardado');
  };

  return (
    <Screen title="Finanzas" tabs right={<IconButton icon="History" label="Historial" onPress={() => nav.navigate('FinanceHistory', { month })} />}>
      {/* Tarjeta principal */}
      <View style={{ borderRadius: t.radius.xl, overflow: 'hidden' }}>
        <LinearGradient colors={t.gradients ? [t.accent.deep, t.accent.base] : [t.accent.base, t.accent.base]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ padding: 20 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <T variant="caption" color="#FFFFFFCC">Saldo disponible</T>
            <Pressable onPress={openBalance} hitSlop={10} style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
              <Icon name="SquarePen" size={14} color="#FFFFFFCC" />
              <T variant="small" color="#FFFFFFCC">Saldo inicial</T>
            </Pressable>
          </View>
          <T variant="display" color="#fff" style={{ marginTop: 6, fontSize: 32 }} numberOfLines={1}>{formatMoney(balance, s.currency)}</T>
          <View style={{ flexDirection: 'row', marginTop: 18, gap: 10 }}>
            <View style={{ flex: 1, backgroundColor: '#FFFFFF1F', borderRadius: 14, padding: 12 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
                <Icon name="ArrowDownLeft" size={14} color="#fff" />
                <T variant="small" color="#FFFFFFCC">Ingresos del mes</T>
              </View>
              <T variant="bodyStrong" color="#fff" style={{ marginTop: 4 }} numberOfLines={1}>{formatMoney(sum.income, s.currency)}</T>
            </View>
            <View style={{ flex: 1, backgroundColor: '#FFFFFF1F', borderRadius: 14, padding: 12 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
                <Icon name="ArrowUpRight" size={14} color="#fff" />
                <T variant="small" color="#FFFFFFCC">Gastos del mes</T>
              </View>
              <T variant="bodyStrong" color="#fff" style={{ marginTop: 4 }} numberOfLines={1}>{formatMoney(sum.expense, s.currency)}</T>
            </View>
          </View>
        </LinearGradient>
      </View>

      <View style={{ flexDirection: 'row', gap: 10 }}>
        <Button title="Gasto" icon="Plus" style={{ flex: 1 }} size="lg" onPress={() => nav.navigate('TxForm', { kind: 'expense' })} />
        <Button title="Ingreso" icon="Plus" variant="secondary" style={{ flex: 1 }} size="lg" onPress={() => nav.navigate('TxForm', { kind: 'income' })} />
      </View>

      {/* Selector de mes */}
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <IconButton icon="ChevronLeft" label="Mes anterior" size={36} onPress={() => setMonth((m) => addMonthsToKey(m, -1))} />
        <T variant="heading" align="center" style={{ flex: 1 }}>{formatMonthYear(month)}</T>
        <IconButton icon="ChevronRight" label="Mes siguiente" size={36} onPress={() => setMonth((m) => addMonthsToKey(m, 1))} />
      </View>

      <View style={{ flexDirection: 'row', gap: 10 }}>
        <Card style={{ flex: 1 }}>
          <T variant="small" secondary>Resultado del mes</T>
          <T variant="heading" color={sum.net >= 0 ? t.c.success : t.c.danger} style={{ marginTop: 6 }} numberOfLines={1}>{formatMoney(sum.net, s.currency, { sign: true })}</T>
        </Card>
        <Card style={{ flex: 1 }}>
          <T variant="small" secondary>vs. mes anterior</T>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 6 }}>
            {change != null ? <Icon name={change > 0 ? 'TrendingUp' : 'TrendingDown'} size={18} color={change > 0 ? t.c.danger : t.c.success} /> : null}
            <T variant="heading" color={change == null ? t.c.textMuted : change > 0 ? t.c.danger : t.c.success}>
              {change == null ? '—' : `${change > 0 ? '+' : ''}${String(change).replace('.', ',')}%`}
            </T>
          </View>
          <T variant="small" muted>en gastos</T>
        </Card>
      </View>
      {sum.expense > 0 && (
        <T variant="small" muted align="center">Promedio de gasto diario {isCurrent ? 'en lo que va del mes' : 'del mes'}: {formatMoney(avg, s.currency)}</T>
      )}

      <SectionHeader title="Gastos por categoría" />
      <Card>
        {cats.length === 0 ? (
          <T secondary>No hay gastos registrados en {formatMonthYear(month).toLowerCase()}.</T>
        ) : (
          <View style={{ gap: 18 }}>
            <View style={{ alignItems: 'center' }}>
              <Donut data={cats.map((c, i) => ({ value: c.total, color: CATEGORY_COLORS[i % CATEGORY_COLORS.length] }))} size={170} stroke={20}>
                <T variant="small" muted>Total</T>
                <T variant="heading">{formatMoneyCompact(sum.expense, s.currency)}</T>
              </Donut>
            </View>
            {cats.map((c, i) => (
              <View key={c.category} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <View style={{ width: 10, height: 10, borderRadius: 3, backgroundColor: CATEGORY_COLORS[i % CATEGORY_COLORS.length] }} />
                <T style={{ flex: 1 }} numberOfLines={1}>{c.category}</T>
                <T variant="caption" muted>{String(c.percent).replace('.', ',')}%</T>
                <T variant="bodyStrong" style={{ minWidth: 92, textAlign: 'right' }}>{formatMoney(c.total, s.currency)}</T>
              </View>
            ))}
          </View>
        )}
      </Card>

      <SectionHeader title="Últimos 6 meses" />
      <Card>
        <GroupedBars
          labels={series.map((m) => MONTHS_SHORT[Number(m.month.slice(5, 7)) - 1])}
          series={[
            { name: 'Ingresos', color: t.c.success, values: series.map((m) => m.income) },
            { name: 'Gastos', color: t.c.danger, values: series.map((m) => m.expense) },
          ]}
        />
        <View style={{ marginTop: 12 }}>
          <Legend items={[{ color: t.c.success, label: 'Ingresos' }, { color: t.c.danger, label: 'Gastos' }]} />
        </View>
      </Card>

      <SectionHeader title="Movimientos" action="Ver historial" onAction={() => nav.navigate('FinanceHistory', { month })} />
      {recent.length === 0 ? (
        <Card>
          <EmptyState icon="Receipt" title="Sin movimientos" text="Registrá tus compras e ingresos para ver tu resumen." />
        </Card>
      ) : (
        <Card padding={2}>
          {recent.map((tx, i) => (
            <View key={tx.id} style={i ? { borderTopWidth: 1, borderTopColor: t.c.border } : undefined}>
              <TxRow tx={tx} onPress={() => nav.navigate('TxForm', { id: tx.id })} />
            </View>
          ))}
        </Card>
      )}

      <Sheet visible={balOpen} onClose={() => setBalOpen(false)} title="Saldo inicial">
        <View style={{ gap: 14 }}>
          <T secondary>Es el dinero que tenías antes de empezar a registrar. Se suma a tus ingresos y se le restan tus gastos para calcular el saldo disponible.</T>
          <Field label="Importe" value={balText} onChangeText={setBalText} keyboardType="decimal-pad" prefix="$" placeholder="0" />
          <DateField label="Desde (opcional)" value={balDate} onChange={setBalDate} placeholder="Contar todos los movimientos" />
          <T variant="small" muted>Si elegís una fecha, sólo se cuentan los movimientos desde ese día.</T>
          <Button title="Guardar" onPress={saveBalance} />
        </View>
      </Sheet>
    </Screen>
  );
}
