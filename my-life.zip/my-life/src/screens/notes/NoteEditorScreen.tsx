import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, Pressable, ScrollView, TextInput, View, KeyboardAvoidingView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { ChipGroup, IconButton, T, Check } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { notesRepo, type NoteInput } from '../../db/repos';
import { NOTE_CATEGORIES } from '../../db/defaults';
import { FONT } from '../../theme/theme';
import type { NoteItem } from '../../types';

export default function NoteEditorScreen({ navigation, route }: any) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const profile = useProfile();
  const { bump } = useApp();
  const [noteId, setNoteId] = useState<number | undefined>(route.params?.id);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [isList, setIsList] = useState<boolean>(!!route.params?.list);
  const [items, setItems] = useState<NoteItem[]>(route.params?.list ? [{ text: '', done: false }] : []);
  const [category, setCategory] = useState('General');
  const [favorite, setFavorite] = useState(false);
  const [status, setStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const [showCats, setShowCats] = useState(false);
  const loaded = useRef(!route.params?.id);
  const skipNext = useRef(false);
  const dirty = useRef(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const latest = useRef<NoteInput>({ title: '', body: '', category: 'General', isList: false, items: [], favorite: false });
  const idRef = useRef<number | undefined>(route.params?.id);
  const inputs = useRef<(TextInput | null)[]>([]);

  useEffect(() => {
    if (!route.params?.id) return;
    notesRepo.get(profile.id, route.params.id).then((n) => {
      if (!n) return;
      setTitle(n.title);
      setBody(n.body);
      setIsList(n.isList);
      setItems(n.items);
      setCategory(n.category || 'General');
      setFavorite(n.favorite);
      loaded.current = true;
      skipNext.current = true;
    });
  }, [route.params?.id, profile.id]);

  latest.current = { title: title.trim(), body, category, isList, items: items.filter((i) => i.text.trim() || i.done), favorite };

  const isEmpty = (n: NoteInput) => !n.title && !n.body.trim() && n.items.length === 0;

  const persist = useCallback(async () => {
    if (!dirty.current) return;
    const n = latest.current;
    dirty.current = false;
    if (isEmpty(n) && !idRef.current) return;
    setStatus('saving');
    try {
      if (idRef.current) await notesRepo.update(profile.id, idRef.current, n);
      else {
        const nid = await notesRepo.create(profile.id, n);
        idRef.current = nid;
        setNoteId(nid);
      }
      setStatus('saved');
      bump();
    } catch {
      setStatus('idle');
    }
  }, [profile.id, bump]);

  // Guardado automático: 700 ms después del último cambio
  useEffect(() => {
    if (!loaded.current) return;
    if (skipNext.current) {
      skipNext.current = false;
      return;
    }
    dirty.current = true;
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(persist, 700);
  }, [title, body, isList, items, category, favorite, persist]);

  // Al salir, guarda lo pendiente (y descarta notas nuevas vacías)
  useEffect(() => {
    const unsub = navigation.addListener('beforeRemove', () => {
      if (timer.current) clearTimeout(timer.current);
      persist();
    });
    return unsub;
  }, [navigation, persist]);

  const toggleMode = () => {
    if (!isList) {
      const lines = body.split('\n').map((l) => l.trim()).filter(Boolean);
      setItems(lines.length ? lines.map((text) => ({ text, done: false })) : [{ text: '', done: false }]);
      setBody('');
    } else {
      setBody(items.map((i) => i.text).filter(Boolean).join('\n'));
      setItems([]);
    }
    setIsList(!isList);
  };

  const remove = () =>
    Alert.alert('Eliminar nota', '¿Seguro que querés eliminarla?', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Eliminar',
        style: 'destructive',
        onPress: async () => {
          dirty.current = false;
          if (timer.current) clearTimeout(timer.current);
          if (idRef.current) await notesRepo.remove(profile.id, idRef.current);
          idRef.current = undefined;
          bump();
          navigation.goBack();
        },
      },
    ]);

  const updateItem = (i: number, patch: Partial<NoteItem>) => setItems((cur) => cur.map((it, k) => (k === i ? { ...it, ...patch } : it)));
  const addItemAfter = (i: number) => {
    setItems((cur) => [...cur.slice(0, i + 1), { text: '', done: false }, ...cur.slice(i + 1)]);
    setTimeout(() => inputs.current[i + 1]?.focus(), 60);
  };
  const removeItem = (i: number) => setItems((cur) => cur.filter((_, k) => k !== i));

  return (
    <View style={{ flex: 1, backgroundColor: t.c.bg, paddingTop: insets.top + 8 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 18, paddingBottom: 10 }}>
        <IconButton icon="ChevronLeft" label="Volver" onPress={() => navigation.goBack()} />
        <View style={{ flex: 1 }}>
          <T variant="small" muted>{status === 'saving' ? 'Guardando…' : status === 'saved' ? 'Guardado' : noteId ? 'Nota' : 'Nueva nota'}</T>
        </View>
        <IconButton icon="Star" label="Favorita" color={favorite ? '#F59E0B' : undefined} onPress={() => setFavorite((v) => !v)} />
        <IconButton icon={isList ? 'AlignLeft' : 'ListChecks'} label={isList ? 'Convertir en texto' : 'Convertir en lista'} onPress={toggleMode} />
        <IconButton icon="Tag" label="Categoría" onPress={() => setShowCats((v) => !v)} />
        {noteId ? <IconButton icon="Trash2" label="Eliminar" onPress={remove} /> : null}
      </View>
      {showCats && (
        <View style={{ paddingHorizontal: 18, paddingBottom: 10 }}>
          <ChipGroup options={NOTE_CATEGORIES.map((c) => ({ value: c, label: c }))} value={category} onChange={setCategory} />
        </View>
      )}
      <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding">
        <ScrollView contentContainerStyle={{ paddingHorizontal: 22, paddingBottom: insets.bottom + 60 }} keyboardShouldPersistTaps="handled">
          <TextInput
            value={title}
            onChangeText={setTitle}
            placeholder="Título"
            placeholderTextColor={t.c.textMuted}
            style={{ color: t.c.text, fontFamily: FONT.bold, fontSize: 24, paddingVertical: 8 }}
            cursorColor={t.accent.base}
            selectionColor={t.accent.base}
            maxLength={120}
            autoFocus={!route.params?.id && !route.params?.list}
          />
          <T variant="small" muted style={{ marginBottom: 10 }}>{category}</T>
          {isList ? (
            <View style={{ gap: 4 }}>
              {items.map((it, i) => (
                <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                  <Check checked={it.done} onPress={() => updateItem(i, { done: !it.done })} size={22} />
                  <TextInput
                    ref={(r) => { inputs.current[i] = r; }}
                    value={it.text}
                    onChangeText={(v) => updateItem(i, { text: v })}
                    onSubmitEditing={() => addItemAfter(i)}
                    blurOnSubmit={false}
                    placeholder="Elemento"
                    placeholderTextColor={t.c.textMuted}
                    style={{ flex: 1, color: t.c.text, fontFamily: FONT.regular, fontSize: 16, paddingVertical: 10, textDecorationLine: it.done ? 'line-through' : 'none', opacity: it.done ? 0.55 : 1 }}
                    cursorColor={t.accent.base}
                    autoFocus={!!route.params?.list && i === 0 && !route.params?.id}
                  />
                  <Pressable onPress={() => removeItem(i)} hitSlop={10} accessibilityLabel="Quitar">
                    <Icon name="X" size={16} color={t.c.textMuted} />
                  </Pressable>
                </View>
              ))}
              <Pressable onPress={() => addItemAfter(items.length - 1)} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 12 }}>
                <Icon name="Plus" size={20} color={t.accent.base} />
                <T color={t.accent.base}>Agregar elemento</T>
              </Pressable>
            </View>
          ) : (
            <TextInput
              value={body}
              onChangeText={setBody}
              placeholder="Escribí tu nota…"
              placeholderTextColor={t.c.textMuted}
              multiline
              style={{ color: t.c.text, fontFamily: FONT.regular, fontSize: 16, lineHeight: 24, minHeight: 300, textAlignVertical: 'top' }}
              cursorColor={t.accent.base}
              selectionColor={t.accent.base}
            />
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}
