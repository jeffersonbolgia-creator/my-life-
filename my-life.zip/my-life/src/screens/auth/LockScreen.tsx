import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Pressable, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as LocalAuthentication from 'expo-local-authentication';
import { useApp, useTheme } from '../../state/AppContext';
import { T } from '../../ui/kit';
import { PinDots, PinPad } from '../../ui/PinPad';
import { LogoMark } from '../../ui/Logo';
import { checkPin, getLockState, registerFailure, resetFailures } from '../../security/pin';
import { success } from '../../ui/haptics';
import { firstName } from '../../lib/text';

const MAX_PROFILES = 4;

export default function LockScreen({ navigation }: any) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const { profiles, lastProfileId, unlock } = useApp();
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [shake, setShake] = useState(false);
  const [busy, setBusy] = useState(false);
  const [lockedUntil, setLockedUntil] = useState(0);
  const [now, setNow] = useState(Date.now());
  const bioTried = useRef(false);

  const lengths: number[] = useMemo(() => [...new Set<number>(profiles.map((p) => p.settings.pinLength))].sort(), [profiles]);
  const maxLen = Math.max(4, ...lengths);
  const bioProfile = profiles.find((p) => p.id === lastProfileId && p.settings.biometrics) ?? null;

  useEffect(() => {
    getLockState().then((s) => setLockedUntil(s.lockedUntil)).catch(() => {});
  }, []);

  useEffect(() => {
    if (lockedUntil <= Date.now()) return;
    const i = setInterval(() => {
      const n = Date.now();
      setNow(n);
      if (n >= lockedUntil) clearInterval(i);
    }, 500);
    return () => clearInterval(i);
  }, [lockedUntil]);

  const locked = lockedUntil > now;
  const secondsLeft = Math.ceil((lockedUntil - now) / 1000);

  const tryBiometrics = useCallback(async () => {
    if (!bioProfile) return;
    try {
      const r = await LocalAuthentication.authenticateAsync({
        promptMessage: `Entrar como ${firstName(bioProfile.name)}`,
        cancelLabel: 'Usar PIN',
        disableDeviceFallback: true,
      });
      if (r.success) {
        success();
        await resetFailures();
        await unlock(bioProfile.id);
      }
    } catch {
      // si falla, se usa el PIN
    }
  }, [bioProfile, unlock]);

  useEffect(() => {
    if (bioProfile && !bioTried.current) {
      bioTried.current = true;
      const tm = setTimeout(tryBiometrics, 1500);
      return () => clearTimeout(tm);
    }
  }, [bioProfile, tryBiometrics]);

  const pinRef = useRef('');
  const missRef = useRef(false);
  const updatePin = (v: string) => {
    pinRef.current = v;
    setPin(v);
  };

  const fail = async () => {
    missRef.current = false;
    const s = await registerFailure();
    setLockedUntil(s.lockedUntil);
    setNow(Date.now());
    const left = 5 - (s.failures % 5);
    setError(s.lockedUntil > Date.now() ? 'Demasiados intentos.' : `PIN incorrecto. ${left === 5 ? '' : `Te quedan ${left} intento${left === 1 ? '' : 's'} antes del bloqueo.`}`);
    setShake(true);
    setTimeout(() => {
      setShake(false);
      updatePin('');
    }, 450);
  };

  const verify = (value: string) => {
    // Si hay perfiles con PIN de 6 y se escribieron 4, es una comprobación intermedia:
    // no se bloquea el teclado para no perder los dígitos que siguen.
    const final = value.length >= maxLen;
    if (final) setBusy(true);
    setTimeout(async () => {
      try {
        const candidates = profiles.filter((p) => p.settings.pinLength === value.length);
        candidates.sort((a, b) => (a.id === lastProfileId ? -1 : b.id === lastProfileId ? 1 : 0));
        for (const p of candidates) {
          if (await checkPin(p.id, value)) {
            if (pinRef.current !== value) return; // el usuario siguió escribiendo
            success();
            await resetFailures();
            setBusy(false);
            await unlock(p.id);
            return;
          }
        }
        setBusy(false);
        if (!final) {
          // No coincide con ningún PIN de 4: si borra para reintentar, cuenta como intento fallido.
          missRef.current = true;
          return;
        }
        await fail();
      } catch {
        setBusy(false);
        await fail();
      }
    }, final ? 30 : 0);
  };

  const onDigit = (d: string) => {
    if (locked || busy) return;
    setError(null);
    const v = (pinRef.current + d).slice(0, maxLen);
    if (v === pinRef.current) return;
    updatePin(v);
    if (lengths.includes(v.length)) verify(v);
  };

  const onDelete = () => {
    if (locked || busy) return;
    if (missRef.current) {
      void fail();
      return;
    }
    updatePin(pinRef.current.slice(0, -1));
  };

  return (
    <View style={{ flex: 1, backgroundColor: t.c.bg }}>
      <LinearGradient colors={[t.accent.deep + '66', t.c.bg]} style={{ position: 'absolute', left: 0, right: 0, top: 0, height: 380 }} />
      <View style={{ flex: 1, paddingTop: insets.top + 50, alignItems: 'center', paddingHorizontal: 24 }}>
        <LogoMark size={60} />
        <T variant="label" muted style={{ marginTop: 18, letterSpacing: 4 }}>MY LIFE</T>
        <T variant="title" style={{ marginTop: 18 }}>Ingresá tu PIN</T>
        <T secondary style={{ marginTop: 6 }}>Se abrirá tu espacio personal</T>
        <View style={{ marginTop: 34, height: 20, justifyContent: 'center' }}>
          {busy ? <ActivityIndicator color={t.accent.base} /> : <PinDots length={maxLen} filled={pin.length} error={shake} />}
        </View>
        <T variant="caption" align="center" color={locked ? t.c.warning : t.c.danger} style={{ marginTop: 16, minHeight: 36 }}>
          {locked ? `Bloqueado por seguridad. Esperá ${secondsLeft} s.` : error ?? ''}
        </T>
      </View>
      <View style={{ paddingHorizontal: 30, paddingBottom: insets.bottom + 16 }}>
        <PinPad
          disabled={locked || busy}
          onDigit={onDigit}
          onDelete={onDelete}
          leftKey={bioProfile ? { icon: 'Fingerprint', label: 'Usar huella', onPress: tryBiometrics } : null}
        />
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 22, paddingHorizontal: 6 }}>
          <Pressable onPress={() => navigation.navigate('Recovery')} hitSlop={10}>
            <T variant="caption" color={t.accent.light}>¿Olvidaste tu PIN?</T>
          </Pressable>
          {profiles.length < MAX_PROFILES && (
            <Pressable onPress={() => navigation.navigate('Setup', { mode: 'add' })} hitSlop={10}>
              <T variant="caption" secondary>Agregar perfil</T>
            </Pressable>
          )}
        </View>
      </View>
    </View>
  );
}
