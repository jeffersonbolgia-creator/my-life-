import React, { useState } from 'react';
import { Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { Card, Check, EmptyState, IconBox, IconButton, Screen, Segmented, T } from '../../ui/kit';
import { remindersRepo } from '../../db/repos';
import { formatRelativeDay, todayISO } from '../../lib/dates';
import { formatMoney } from '../../lib/money';
import type { Reminder } from '../../types';

export const REPEAT_LABEL: Record<string, string> = { none: 'Una vez', daily: 'Todos los días', weekly: 'Cada semana', monthly: 'Cada mes' };

export default function RemindersScreen({ navigation }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { bump } = useApp();
  const [tab, setTab] = useState<'all' | 'payment' | 'done'>('all');
  const { data } = useData<Reminder[]>((pid) => remindersRepo.list(pid), []);
  const today = todayISO();
  const list = data.filter((r) => (tab === 'done' ? r.done : !r.done && (tab === 'all' || r.kind === 'payment')));

  const toggle = async (r: Reminder) => {
    await remindersRepo.setDone(profile.id, r.id, !r.done);
    bump();
  };

  return (
    <Screen title="Recordatorios" back right={<IconButton icon="Plus" label="Nuevo recordatorio" filled onPress={() => navigation.navigate('ReminderForm', { kind: tab === 'payment' ? 'payment' : 'general' })} />}>
      <Segmented value={tab} onChange={setTab} options={[{ value: 'all', label: 'Activos' }, { value: 'payment', label: 'Pagos' }, { value: 'done', label: 'Hechos' }]} />
      {list.length === 0 ? (
        <EmptyState
          icon={tab === 'payment' ? 'Receipt' : 'BellRing'}
          title={tab === 'done' ? 'Nada marcado como hecho' : tab === 'payment' ? 'Sin pagos programados' : 'Sin recordatorios'}
          text={tab === 'payment' ? 'Agregá vencimientos (luz, internet, celular…) y te avisamos.' : 'Te avisamos con una notificación a la hora que elijas.'}
          action={tab === 'done' ? undefined : 'Agregar'}
          onAction={() => navigation.navigate('ReminderForm', { kind: tab === 'payment' ? 'payment' : 'general' })}
        />
      ) : (
        <Card padding={2}>
          {list.map((r, i) => {
            const late = !r.done && r.repeat === 'none' && r.date < today;
            return (
              <Pressable key={r.id} onPress={() => navigation.navigate('ReminderForm', { id: r.id })} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderTopWidth: i ? 1 : 0, borderTopColor: t.c.border }}>
                <IconBox icon={r.kind === 'payment' ? 'Receipt' : 'BellRing'} size={38} color={r.kind === 'payment' ? '#F97316' : t.accent.base} />
                <View style={{ flex: 1 }}>
                  <T variant="bodyStrong" numberOfLines={1} style={r.done ? { textDecorationLine: 'line-through', opacity: 0.55 } : undefined}>{r.title}</T>
                  <T variant="small" color={late ? t.c.danger : t.c.textMuted}>
                    {r.repeat === 'none' ? formatRelativeDay(r.date) : REPEAT_LABEL[r.repeat]} · {r.time}
                    {r.amount ? ` · ${formatMoney(r.amount, profile.settings.currency)}` : ''}
                  </T>
                </View>
                <Check checked={r.done} onPress={() => toggle(r)} />
              </Pressable>
            );
          })}
        </Card>
      )}
      <T variant="small" muted align="center">Marcar un recordatorio como hecho desactiva sus avisos.</T>
    </Screen>
  );
}
