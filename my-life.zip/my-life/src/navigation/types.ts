export type RootStackParamList = {
  Welcome: undefined;
  Setup: { mode: 'first' | 'add' };
  Lock: undefined;
  Recovery: undefined;
  Main: undefined;
  TaskForm: { id?: number; date?: string } | undefined;
  EventForm: { id?: number; date?: string; type?: string } | undefined;
  GoalForm: { id?: number } | undefined;
  HabitForm: { id?: number } | undefined;
  NoteEditor: { id?: number; list?: boolean } | undefined;
  TxForm: { id?: number; kind?: 'income' | 'expense' } | undefined;
  ReminderForm: { id?: number; kind?: 'general' | 'payment' } | undefined;
  Goals: undefined;
  Habits: undefined;
  Notes: undefined;
  Stats: undefined;
  Reminders: undefined;
  FinanceHistory: { month?: string } | undefined;
  Settings: undefined;
  ProfileEdit: undefined;
  Appearance: undefined;
  NotificationSettings: undefined;
  DashboardSettings: undefined;
  Security: undefined;
  Backup: undefined;
  About: undefined;
};

export type TabParamList = {
  Home: undefined;
  Agenda: { view?: 'tasks' | 'calendar' } | undefined;
  Add: undefined;
  Finance: undefined;
  More: undefined;
};
