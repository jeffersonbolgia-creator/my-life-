import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Animated, StyleSheet, View, Text, ScrollView } from 'react-native';
import { NavigationContainer, DarkTheme, DefaultTheme, createNavigationContainerRef } from '@react-navigation/native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import * as SystemUI from 'expo-system-ui';
import * as Notifications from 'expo-notifications';
import { useFonts, Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold } from '@expo-google-fonts/inter';
import { AppProvider, useApp } from './state/AppContext';
import RootNavigator from './navigation/RootNavigator';
import { openExpoDb } from './db/expoDb';
import { migrate, setDb } from './db/db';
import { profilesRepo } from './db/repos';
import { initSecurity } from './security/secureStore';
import { initNotifications } from './notifications/notifications';
import { setHapticsEnabled } from './ui/haptics';
import { LogoMark } from './ui/Logo';
import type { Profile } from './types';

SplashScreen.preventAutoHideAsync().catch(() => {});

export const navigationRef = createNavigationContainerRef<any>();

class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) {
    return { error };
  }
  render() {
    if (this.state.error) {
      return (
        <ScrollView style={{ flex: 1, backgroundColor: '#0B0A10' }} contentContainerStyle={{ padding: 28, paddingTop: 80, gap: 12 }}>
          <Text style={{ color: '#F5F3FA', fontSize: 22, fontWeight: '700' }}>Algo salió mal</Text>
          <Text style={{ color: '#A9A4B8', fontSize: 15 }}>
            Tus datos están guardados. Cerrá la app y volvé a abrirla. Si el problema sigue, este es el detalle técnico:
          </Text>
          <Text style={{ color: '#6F6A80', fontSize: 12 }}>{String(this.state.error?.message ?? this.state.error)}</Text>
        </ScrollView>
      );
    }
    return this.props.children;
  }
}

function Themed() {
  const { theme, profile } = useApp();
  const pending = useRef<{ profileId: number; route?: string } | null>(null);

  useEffect(() => {
    SystemUI.setBackgroundColorAsync(theme.c.bg).catch(() => {});
  }, [theme.c.bg]);

  useEffect(() => {
    if (profile) setHapticsEnabled(profile.settings.haptics);
  }, [profile]);

  // Al tocar una notificación: abrir la sección correspondiente (después de desbloquear).
  const handled = useRef<string | null>(null);
  const profileId = profile?.id ?? null;
  useEffect(() => {
    const take = (resp: any) => {
      const data = resp?.notification?.request?.content?.data as any;
      if (!data || typeof data.profileId !== 'number') return;
      const key = `${resp.notification.request.identifier}-${resp.notification.date}`;
      if (handled.current === key) return;
      handled.current = key;
      pending.current = { profileId: data.profileId, route: data.route };
    };
    const go = () => {
      const p = pending.current;
      if (!p || profileId == null || p.profileId !== profileId || !navigationRef.isReady()) return;
      pending.current = null;
      if (!p.route) return;
      const tabRoutes = ['Home', 'Agenda', 'Finance', 'More'];
      if (p.route === 'Tasks') navigationRef.navigate('Main', { screen: 'Agenda', params: { view: 'tasks' } });
      else if (p.route === 'Calendar') navigationRef.navigate('Main', { screen: 'Agenda', params: { view: 'calendar' } });
      else if (tabRoutes.includes(p.route)) navigationRef.navigate('Main', { screen: p.route });
      else navigationRef.navigate(p.route);
    };
    const sub = Notifications.addNotificationResponseReceivedListener((resp) => {
      take(resp);
      go();
    });
    Notifications.getLastNotificationResponseAsync()
      .then((resp) => {
        if (!pending.current) take(resp);
      })
      .catch(() => {});
    const timer = setTimeout(go, 400);
    return () => {
      sub.remove();
      clearTimeout(timer);
    };
  }, [profileId]);

  const navTheme = {
    ...(theme.dark ? DarkTheme : DefaultTheme),
    colors: {
      ...(theme.dark ? DarkTheme : DefaultTheme).colors,
      background: theme.c.bg,
      card: theme.c.surface,
      text: theme.c.text,
      border: theme.c.border,
      primary: theme.accent.base,
    },
  };

  return (
    <NavigationContainer ref={navigationRef} theme={navTheme}>
      <StatusBar style={theme.dark ? 'light' : 'dark'} />
      <RootNavigator />
    </NavigationContainer>
  );
}

function IntroOverlay({ onDone }: { onDone: () => void }) {
  const opacity = useRef(new Animated.Value(1)).current;
  const scale = useRef(new Animated.Value(0.86)).current;
  const textOp = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.sequence([
      Animated.parallel([
        Animated.spring(scale, { toValue: 1, useNativeDriver: true, damping: 14, stiffness: 120 }),
        Animated.timing(textOp, { toValue: 1, duration: 450, delay: 150, useNativeDriver: true }),
      ]),
      Animated.delay(450),
      Animated.timing(opacity, { toValue: 0, duration: 320, useNativeDriver: true }),
    ]).start(() => onDone());
  }, [opacity, scale, textOp, onDone]);
  return (
    <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFill, { backgroundColor: '#0B0A10', alignItems: 'center', justifyContent: 'center', opacity }]}>
      <Animated.View style={{ transform: [{ scale }] }}>
        <LogoMark size={92} />
      </Animated.View>
      <Animated.Text style={{ opacity: textOp, color: '#F5F3FA', fontFamily: 'Inter_700Bold', fontSize: 24, letterSpacing: 6, marginTop: 22 }}>
        MY LIFE
      </Animated.Text>
    </Animated.View>
  );
}

export default function App() {
  const [fontsLoaded, fontError] = useFonts({ Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold });
  const [profiles, setProfiles] = useState<Profile[] | null>(null);
  const [initError, setInitError] = useState<string | null>(null);
  const [intro, setIntro] = useState(true);
  const endIntro = useCallback(() => setIntro(false), []);

  useEffect(() => {
    (async () => {
      try {
        const db = await openExpoDb();
        await migrate(db);
        setDb(db);
        initSecurity();
        initNotifications().catch(() => {});
        setProfiles(await profilesRepo.list());
      } catch (e: any) {
        setInitError(String(e?.message ?? e));
      }
    })();
  }, []);

  const ready = (fontsLoaded || !!fontError) && (profiles !== null || !!initError);

  useEffect(() => {
    if (ready) SplashScreen.hideAsync().catch(() => {});
  }, [ready]);

  if (!ready) return <View style={{ flex: 1, backgroundColor: '#0B0A10' }} />;

  if (initError) {
    return (
      <View style={{ flex: 1, backgroundColor: '#0B0A10', padding: 28, justifyContent: 'center', gap: 12 }}>
        <Text style={{ color: '#F5F3FA', fontSize: 20, fontWeight: '700' }}>No se pudo abrir la base de datos</Text>
        <Text style={{ color: '#A9A4B8' }}>{initError}</Text>
      </View>
    );
  }

  return (
    <ErrorBoundary>
      <SafeAreaProvider>
        <AppProvider initialProfiles={profiles!}>
          <View style={{ flex: 1, backgroundColor: '#0B0A10' }}>
            <Themed />
            {intro && <IntroOverlay onDone={endIntro} />}
          </View>
        </AppProvider>
      </SafeAreaProvider>
    </ErrorBoundary>
  );
}
