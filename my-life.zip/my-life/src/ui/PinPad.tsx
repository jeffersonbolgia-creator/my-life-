import React, { useEffect, useRef } from 'react';
import { Animated, Pressable, View } from 'react-native';
import { useTheme } from '../state/AppContext';
import { Icon } from './Icon';
import { T } from './kit';
import { tap, warn } from './haptics';

export function PinDots({ length, filled, error }: { length: number; filled: number; error?: boolean }) {
  const t = useTheme();
  const shake = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (error) {
      warn();
      Animated.sequence([
        Animated.timing(shake, { toValue: 10, duration: 50, useNativeDriver: true }),
        Animated.timing(shake, { toValue: -10, duration: 50, useNativeDriver: true }),
        Animated.timing(shake, { toValue: 7, duration: 50, useNativeDriver: true }),
        Animated.timing(shake, { toValue: 0, duration: 50, useNativeDriver: true }),
      ]).start();
    }
  }, [error, shake]);
  return (
    <Animated.View style={{ flexDirection: 'row', gap: 16, justifyContent: 'center', transform: [{ translateX: shake }] }}>
      {Array.from({ length }).map((_, i) => (
        <View
          key={i}
          style={{
            width: 14, height: 14, borderRadius: 7,
            backgroundColor: error ? t.c.danger : i < filled ? t.accent.base : 'transparent',
            borderWidth: 1.5, borderColor: error ? t.c.danger : i < filled ? t.accent.base : t.c.borderStrong,
          }}
        />
      ))}
    </Animated.View>
  );
}

export function PinPad({ onDigit, onDelete, leftKey, disabled }: { onDigit: (d: string) => void; onDelete: () => void; leftKey?: { icon: string; label: string; onPress: () => void } | null; disabled?: boolean }) {
  const t = useTheme();
  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'L', '0', 'D'];
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', rowGap: 14, opacity: disabled ? 0.4 : 1 }}>
      {keys.map((k) => {
        if (k === 'L' && !leftKey) return <View key={k} style={{ width: '33.3%' }} />;
        const isNum = /\d/.test(k);
        return (
          <View key={k} style={{ width: '33.3%', alignItems: 'center' }}>
            <Pressable
              disabled={disabled}
              onPress={() => {
                tap();
                if (isNum) onDigit(k);
                else if (k === 'D') onDelete();
                else leftKey?.onPress();
              }}
              accessibilityRole="button"
              accessibilityLabel={isNum ? k : k === 'D' ? 'Borrar' : leftKey?.label}
              style={({ pressed }) => ({
                width: 74, height: 74, borderRadius: 37, alignItems: 'center', justifyContent: 'center',
                backgroundColor: isNum ? (pressed ? t.accentSoft : t.c.surface) : pressed ? t.c.surface2 : 'transparent',
                borderWidth: isNum ? 1 : 0, borderColor: t.c.border,
              })}
            >
              {isNum ? (
                <T variant="title" style={{ fontSize: 26 }}>{k}</T>
              ) : k === 'D' ? (
                <Icon name="Delete" size={24} color={t.c.textSecondary} />
              ) : (
                <Icon name={leftKey!.icon} size={26} color={t.accent.base} />
              )}
            </Pressable>
          </View>
        );
      })}
    </View>
  );
}
