import React from 'react';
import Svg, { Defs, LinearGradient, Stop, Rect, Circle, Path } from 'react-native-svg';

/** Isotipo de MY LIFE: órbita con un punto (la vida en movimiento) sobre un cuadrado violeta. */
export function LogoMark({ size = 72, from = '#6D28D9', to = '#A78BFA' }: { size?: number; from?: string; to?: string }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 100 100">
      <Defs>
        <LinearGradient id="lg" x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor={from} />
          <Stop offset="1" stopColor={to} />
        </LinearGradient>
      </Defs>
      <Rect x="0" y="0" width="100" height="100" rx="28" fill="url(#lg)" />
      <Circle cx="50" cy="50" r="22" stroke="#FFFFFF" strokeOpacity={0.95} strokeWidth="6" fill="none" />
      <Path d="M 24 65 A 30 30 0 0 0 76 65" stroke="#FFFFFF" strokeOpacity={0.45} strokeWidth="4" fill="none" strokeLinecap="round" />
      <Circle cx="68" cy="34" r="7" fill="#FFFFFF" />
    </Svg>
  );
}
