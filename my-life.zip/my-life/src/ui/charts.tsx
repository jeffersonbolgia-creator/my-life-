import React from 'react';
import { View } from 'react-native';
import Svg, { Circle, G, Path, Rect, Line } from 'react-native-svg';
import { useTheme } from '../state/AppContext';
import { T } from './kit';

/** Barras agrupadas (ej. ingresos vs. gastos por mes). */
export function GroupedBars({
  labels, series, height = 150,
}: {
  labels: string[]; series: { color: string; values: number[]; name: string }[]; height?: number;
}) {
  const t = useTheme();
  const [width, setWidth] = React.useState(0);
  const max = Math.max(1, ...series.flatMap((s) => s.values));
  const n = labels.length;
  const groupW = n ? width / n : 0;
  const barW = Math.max(4, Math.min(16, (groupW - 14) / series.length));
  const chartH = height - 22;
  return (
    <View onLayout={(e) => setWidth(e.nativeEvent.layout.width)} style={{ height }}>
      {width > 0 && (
        <Svg width={width} height={chartH}>
          {[0.25, 0.5, 0.75, 1].map((p) => (
            <Line key={p} x1={0} x2={width} y1={chartH - chartH * p * 0.92} y2={chartH - chartH * p * 0.92} stroke={t.c.border} strokeWidth={1} />
          ))}
          {labels.map((_, i) => {
            const gx = i * groupW + (groupW - barW * series.length - 4 * (series.length - 1)) / 2;
            return (
              <G key={i}>
                {series.map((s, j) => {
                  const v = s.values[i] ?? 0;
                  const h = v > 0 ? Math.max(3, (v / max) * chartH * 0.92) : 0;
                  return <Rect key={j} x={gx + j * (barW + 4)} y={chartH - h} width={barW} height={h} rx={Math.min(5, barW / 2)} fill={s.color} />;
                })}
              </G>
            );
          })}
        </Svg>
      )}
      <View style={{ flexDirection: 'row', marginTop: 6 }}>
        {labels.map((l, i) => (
          <T key={i} variant="small" muted align="center" style={{ width: groupW || undefined, flex: groupW ? undefined : 1 }}>{l}</T>
        ))}
      </View>
    </View>
  );
}

/** Barras simples (ej. tareas completadas por día). */
export function SimpleBars({ values, labels, color, height = 110 }: { values: number[]; labels: string[]; color?: string; height?: number }) {
  const t = useTheme();
  const c = color ?? t.accent.base;
  return (
    <GroupedBars
      labels={labels}
      height={height}
      series={[{ name: 'v', color: c, values }]}
    />
  );
}

function arcPath(cx: number, cy: number, r: number, start: number, end: number): string {
  const s = { x: cx + r * Math.cos(start), y: cy + r * Math.sin(start) };
  const e = { x: cx + r * Math.cos(end), y: cy + r * Math.sin(end) };
  const large = end - start > Math.PI ? 1 : 0;
  return `M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 1 ${e.x} ${e.y}`;
}

/** Gráfico de anillo por categorías. */
export function Donut({ data, size = 150, stroke = 18, children }: { data: { value: number; color: string }[]; size?: number; stroke?: number; children?: React.ReactNode }) {
  const t = useTheme();
  const total = data.reduce((s, d) => s + d.value, 0);
  const r = (size - stroke) / 2;
  const cx = size / 2;
  let angle = -Math.PI / 2;
  const gap = data.length > 1 ? 0.04 : 0;
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} style={{ position: 'absolute' }}>
        <Circle cx={cx} cy={cx} r={r} stroke={t.c.surface3} strokeWidth={stroke} fill="none" />
        {total > 0 && data.map((d, i) => {
          const sweep = (d.value / total) * Math.PI * 2;
          const start = angle + gap / 2;
          const end = angle + sweep - gap / 2;
          angle += sweep;
          if (sweep >= Math.PI * 2 - 0.001) return <Circle key={i} cx={cx} cy={cx} r={r} stroke={d.color} strokeWidth={stroke} fill="none" />;
          if (end <= start) return null;
          return <Path key={i} d={arcPath(cx, cx, r, start, end)} stroke={d.color} strokeWidth={stroke} fill="none" strokeLinecap="round" />;
        })}
      </Svg>
      {children}
    </View>
  );
}

export function Legend({ items }: { items: { color: string; label: string }[] }) {
  return (
    <View style={{ flexDirection: 'row', gap: 16, flexWrap: 'wrap' }}>
      {items.map((i) => (
        <View key={i.label} style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <View style={{ width: 10, height: 10, borderRadius: 3, backgroundColor: i.color }} />
          <T variant="small" secondary>{i.label}</T>
        </View>
      ))}
    </View>
  );
}
