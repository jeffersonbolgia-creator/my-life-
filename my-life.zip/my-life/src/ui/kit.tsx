import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator, Animated, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet,
  Switch, Text, TextInput, View, type StyleProp, type TextStyle, type ViewStyle, type TextInputProps,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import DateTimePicker, { DateTimePickerAndroid } from '@react-native-community/datetimepicker';
import Svg, { Circle } from 'react-native-svg';
import { useTheme } from '../state/AppContext';
import { FONT, type Theme } from '../theme/theme';
import { Icon } from './Icon';
import { tap } from './haptics';
import { formatUserDate, isValidTime, parseISODate, timeFromDate, toISODate, formatRelativeDay } from '../lib/dates';
import { initials } from '../lib/text';

// ---------------- Texto ----------------

type Variant = 'display' | 'title' | 'heading' | 'body' | 'bodyStrong' | 'caption' | 'label' | 'small' | 'number';

const VARIANTS: Record<Variant, TextStyle> = {
  display: { fontFamily: FONT.bold, fontSize: 30, lineHeight: 36, letterSpacing: -0.6 },
  title: { fontFamily: FONT.bold, fontSize: 22, lineHeight: 28, letterSpacing: -0.4 },
  heading: { fontFamily: FONT.semibold, fontSize: 17, lineHeight: 22, letterSpacing: -0.2 },
  body: { fontFamily: FONT.regular, fontSize: 15, lineHeight: 21 },
  bodyStrong: { fontFamily: FONT.semibold, fontSize: 15, lineHeight: 21 },
  caption: { fontFamily: FONT.medium, fontSize: 13, lineHeight: 18 },
  label: { fontFamily: FONT.semibold, fontSize: 11.5, lineHeight: 15, letterSpacing: 0.8, textTransform: 'uppercase' },
  small: { fontFamily: FONT.medium, fontSize: 11.5, lineHeight: 15 },
  number: { fontFamily: FONT.bold, fontSize: 26, lineHeight: 32, letterSpacing: -0.6 },
};

export function T({
  variant = 'body', color, muted, secondary, align, style, children, numberOfLines, onPress,
}: {
  variant?: Variant; color?: string; muted?: boolean; secondary?: boolean; align?: TextStyle['textAlign'];
  style?: StyleProp<TextStyle>; children?: React.ReactNode; numberOfLines?: number; onPress?: () => void;
}) {
  const t = useTheme();
  const c = color ?? (muted ? t.c.textMuted : secondary ? t.c.textSecondary : t.c.text);
  return (
    <Text onPress={onPress} numberOfLines={numberOfLines} style={[VARIANTS[variant], { color: c, textAlign: align }, style]} maxFontSizeMultiplier={1.35}>
      {children}
    </Text>
  );
}

// ---------------- Pantalla ----------------

export function useBottomSpace() {
  const insets = useSafeAreaInsets();
  return insets.bottom + 110;
}

export function Screen({
  title, subtitle, back, right, children, scroll = true, hero, padded = true, tabs = false, refreshControl, contentStyle,
}: {
  title?: string; subtitle?: string; back?: boolean; right?: React.ReactNode; children?: React.ReactNode; scroll?: boolean;
  hero?: boolean; padded?: boolean; tabs?: boolean; refreshControl?: React.ReactElement<any>; contentStyle?: StyleProp<ViewStyle>;
}) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const nav = useNavigation<any>();
  const bottom = tabs ? insets.bottom + 110 : insets.bottom + 32;
  const header = (title || back || right) ? (
    <View style={[styles.header, { paddingTop: insets.top + 8 }]}>
      <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1, gap: 12 }}>
        {back && <IconButton icon="ChevronLeft" onPress={() => nav.goBack()} label="Volver" />}
        <View style={{ flex: 1 }}>
          {title ? <T variant={back ? 'heading' : 'title'} numberOfLines={1}>{title}</T> : null}
          {subtitle ? <T variant="caption" secondary numberOfLines={1}>{subtitle}</T> : null}
        </View>
      </View>
      {right ? <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>{right}</View> : null}
    </View>
  ) : <View style={{ height: insets.top + 8 }} />;
  const body = scroll ? (
    <ScrollView
      contentContainerStyle={[{ paddingHorizontal: padded ? 18 : 0, paddingBottom: bottom, gap: t.space(4) }, contentStyle]}
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}
      refreshControl={refreshControl}
    >
      {children}
    </ScrollView>
  ) : (
    <View style={[{ flex: 1, paddingHorizontal: padded ? 18 : 0 }, contentStyle]}>{children}</View>
  );
  return (
    <View style={{ flex: 1, backgroundColor: t.c.bg }}>
      {hero && t.gradients && (
        <LinearGradient colors={t.heroGradient} style={[StyleSheet.absoluteFill, { height: 340 }]} start={{ x: 0, y: 0 }} end={{ x: 0.6, y: 1 }} />
      )}
      <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding">
        {header}
        {body}
      </KeyboardAvoidingView>
    </View>
  );
}

// ---------------- Tarjetas ----------------

export function Card({
  children, onPress, style, padding = 16, gradient, accentBorder,
}: {
  children?: React.ReactNode; onPress?: () => void; style?: StyleProp<ViewStyle>; padding?: number; gradient?: boolean; accentBorder?: boolean;
}) {
  const t = useTheme();
  const scale = useRef(new Animated.Value(1)).current;
  const base: ViewStyle = {
    borderRadius: t.radius.lg,
    backgroundColor: t.c.surface,
    borderWidth: 1,
    borderColor: accentBorder ? t.accentSoft : t.c.border,
    padding,
    overflow: 'hidden',
    ...(t.dark ? {} : { shadowColor: t.c.shadow, shadowOpacity: 0.06, shadowRadius: 14, shadowOffset: { width: 0, height: 6 }, elevation: 2 }),
  };
  const inner = (
    <>
      {gradient && t.gradients && (
        <LinearGradient colors={[t.accentSoft, 'rgba(0,0,0,0)']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
      )}
      {children}
    </>
  );
  if (!onPress) return <View style={[base, style]}>{inner}</View>;
  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      <Pressable
        onPress={onPress}
        onPressIn={() => Animated.spring(scale, { toValue: 0.98, useNativeDriver: true, speed: 40 }).start()}
        onPressOut={() => Animated.spring(scale, { toValue: 1, useNativeDriver: true, speed: 30 }).start()}
        android_ripple={{ color: t.accentSofter }}
        style={[base, style]}
      >
        {inner}
      </Pressable>
    </Animated.View>
  );
}

export function SectionHeader({ title, action, onAction, style }: { title: string; action?: string; onAction?: () => void; style?: StyleProp<ViewStyle> }) {
  const t = useTheme();
  return (
    <View style={[{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 }, style]}>
      <T variant="label" muted>{title}</T>
      {action ? (
        <Pressable onPress={onAction} hitSlop={10}>
          <T variant="caption" color={t.accent.base}>{action}</T>
        </Pressable>
      ) : null}
    </View>
  );
}

export function IconBox({ icon, color, size = 40, soft = true }: { icon: string; color?: string; size?: number; soft?: boolean }) {
  const t = useTheme();
  const c = color ?? t.accent.base;
  return (
    <View style={{
      width: size, height: size, borderRadius: size * 0.32, alignItems: 'center', justifyContent: 'center',
      backgroundColor: soft ? c + (t.dark ? '24' : '1A') : c,
    }}>
      <Icon name={icon} size={size * 0.48} color={soft ? c : '#fff'} />
    </View>
  );
}

// ---------------- Botones ----------------

export function Button({
  title, onPress, variant = 'primary', icon, loading, disabled, style, size = 'md', full = true,
}: {
  title: string; onPress?: () => void; variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'outline';
  icon?: string; loading?: boolean; disabled?: boolean; style?: StyleProp<ViewStyle>; size?: 'sm' | 'md' | 'lg'; full?: boolean;
}) {
  const t = useTheme();
  const h = size === 'sm' ? 40 : size === 'lg' ? 56 : 50;
  const fg = variant === 'primary' || variant === 'danger' ? '#fff' : variant === 'secondary' || variant === 'outline' ? t.c.text : t.accent.base;
  const bg = variant === 'secondary' ? t.c.surface2 : variant === 'danger' ? t.c.danger : 'transparent';
  const content = (
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, height: h, paddingHorizontal: 18 }}>
      {loading ? <ActivityIndicator color={fg} /> : icon ? <Icon name={icon} size={18} color={fg} /> : null}
      <T variant="bodyStrong" color={fg}>{title}</T>
    </View>
  );
  return (
    <Pressable
      onPress={() => { if (!disabled && !loading && onPress) { tap(); onPress(); } }}
      disabled={disabled || loading}
      style={({ pressed }) => [{
        borderRadius: t.radius.md, overflow: 'hidden', backgroundColor: bg, opacity: disabled ? 0.45 : pressed ? 0.85 : 1,
        alignSelf: full ? 'stretch' : 'flex-start',
        borderWidth: variant === 'outline' ? 1 : 0, borderColor: t.c.borderStrong,
      }, style]}
      accessibilityRole="button"
      accessibilityLabel={title}
    >
      {variant === 'primary' ? (
        <LinearGradient colors={t.gradients ? t.gradient : [t.accent.base, t.accent.base]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
          {content}
        </LinearGradient>
      ) : content}
    </Pressable>
  );
}

export function IconButton({ icon, onPress, label, color, size = 40, filled, badge }: { icon: string; onPress?: () => void; label: string; color?: string; size?: number; filled?: boolean; badge?: boolean }) {
  const t = useTheme();
  return (
    <Pressable
      onPress={() => { tap(); onPress?.(); }}
      hitSlop={6}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={({ pressed }) => ({
        width: size, height: size, borderRadius: size / 2, alignItems: 'center', justifyContent: 'center',
        backgroundColor: filled ? t.accent.base : t.c.surface2, opacity: pressed ? 0.7 : 1,
        borderWidth: filled ? 0 : 1, borderColor: t.c.border,
      })}
    >
      <Icon name={icon} size={size * 0.46} color={filled ? '#fff' : color ?? t.c.text} />
      {badge ? <View style={{ position: 'absolute', top: 8, right: 9, width: 8, height: 8, borderRadius: 4, backgroundColor: t.c.danger }} /> : null}
    </Pressable>
  );
}

// ---------------- Formularios ----------------

export function Field({
  label, error, hint, style, inputStyle, prefix, right, ...rest
}: TextInputProps & { label?: string; error?: string | null; hint?: string; style?: StyleProp<ViewStyle>; inputStyle?: StyleProp<TextStyle>; prefix?: string; right?: React.ReactNode }) {
  const t = useTheme();
  const [focus, setFocus] = useState(false);
  return (
    <View style={[{ gap: 6 }, style]}>
      {label ? <T variant="caption" secondary>{label}</T> : null}
      <View style={{
        flexDirection: 'row', alignItems: rest.multiline ? 'flex-start' : 'center', backgroundColor: t.c.surface2, borderRadius: t.radius.md,
        borderWidth: 1, borderColor: error ? t.c.danger : focus ? t.accent.base : t.c.border, paddingHorizontal: 14,
        minHeight: rest.multiline ? 96 : 50,
      }}>
        {prefix ? <T variant="bodyStrong" secondary style={{ marginRight: 6 }}>{prefix}</T> : null}
        <TextInput
          placeholderTextColor={t.c.textMuted}
          selectionColor={t.accent.base}
          cursorColor={t.accent.base}
          {...rest}
          onFocus={(e) => { setFocus(true); rest.onFocus?.(e); }}
          onBlur={(e) => { setFocus(false); rest.onBlur?.(e); }}
          style={[{
            flex: 1, color: t.c.text, fontFamily: FONT.regular, fontSize: 15.5, paddingVertical: rest.multiline ? 12 : 0,
            textAlignVertical: rest.multiline ? 'top' : 'center', minHeight: rest.multiline ? 96 : 48,
          }, inputStyle]}
        />
        {right}
      </View>
      {error ? <T variant="small" color={t.c.danger}>{error}</T> : hint ? <T variant="small" muted>{hint}</T> : null}
    </View>
  );
}

export function Chip({ label, selected, onPress, icon, color }: { label: string; selected?: boolean; onPress?: () => void; icon?: string; color?: string }) {
  const t = useTheme();
  const c = color ?? t.accent.base;
  return (
    <Pressable
      onPress={() => { tap(); onPress?.(); }}
      style={({ pressed }) => ({
        flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, height: 38, borderRadius: 19,
        backgroundColor: selected ? c + (t.dark ? '2E' : '1F') : t.c.surface2,
        borderWidth: 1, borderColor: selected ? c : t.c.border, opacity: pressed ? 0.75 : 1,
      })}
      accessibilityRole="button"
      accessibilityState={{ selected }}
    >
      {icon ? <Icon name={icon} size={15} color={selected ? c : t.c.textSecondary} /> : null}
      <T variant="caption" color={selected ? c : t.c.textSecondary}>{label}</T>
    </Pressable>
  );
}

export function ChipGroup<V extends string | number>({
  options, value, onChange, multi,
}: {
  options: { value: V; label: string; icon?: string; color?: string }[];
  value: V | V[] | null; onChange: (v: any) => void; multi?: boolean;
}) {
  const sel = (v: V) => (multi ? (value as V[]).includes(v) : value === v);
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
      {options.map((o) => (
        <Chip
          key={String(o.value)}
          label={o.label}
          icon={o.icon}
          color={o.color}
          selected={sel(o.value)}
          onPress={() => {
            if (multi) {
              const arr = value as V[];
              onChange(arr.includes(o.value) ? arr.filter((x) => x !== o.value) : [...arr, o.value]);
            } else onChange(o.value);
          }}
        />
      ))}
    </View>
  );
}

export function Segmented<V extends string>({ options, value, onChange, style }: { options: { value: V; label: string }[]; value: V; onChange: (v: V) => void; style?: StyleProp<ViewStyle> }) {
  const t = useTheme();
  return (
    <View style={[{ flexDirection: 'row', backgroundColor: t.c.surface2, borderRadius: t.radius.md, padding: 4, borderWidth: 1, borderColor: t.c.border }, style]}>
      {options.map((o) => {
        const on = o.value === value;
        return (
          <Pressable
            key={o.value}
            onPress={() => { tap(); onChange(o.value); }}
            style={{ flex: 1, height: 36, borderRadius: t.radius.sm, alignItems: 'center', justifyContent: 'center', backgroundColor: on ? t.c.surface : 'transparent', ...(on && !t.dark ? { elevation: 1 } : {}) }}
            accessibilityRole="tab"
            accessibilityState={{ selected: on }}
          >
            <T variant="caption" color={on ? t.c.text : t.c.textSecondary}>{o.label}</T>
          </Pressable>
        );
      })}
    </View>
  );
}

export function Row({
  icon, iconColor, title, subtitle, right, onPress, chevron, danger, style,
}: {
  icon?: string; iconColor?: string; title: string; subtitle?: string; right?: React.ReactNode; onPress?: () => void; chevron?: boolean; danger?: boolean; style?: StyleProp<ViewStyle>;
}) {
  const t = useTheme();
  return (
    <Pressable
      onPress={onPress ? () => { tap(); onPress(); } : undefined}
      disabled={!onPress}
      android_ripple={onPress ? { color: t.accentSofter } : undefined}
      style={[{ flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 12, minHeight: 56 }, style]}
    >
      {icon ? <IconBox icon={icon} size={36} color={danger ? t.c.danger : iconColor} /> : null}
      <View style={{ flex: 1 }}>
        <T variant="bodyStrong" color={danger ? t.c.danger : undefined}>{title}</T>
        {subtitle ? <T variant="caption" secondary style={{ marginTop: 1 }}>{subtitle}</T> : null}
      </View>
      {right}
      {chevron ? <Icon name="ChevronRight" size={18} color={t.c.textMuted} /> : null}
    </Pressable>
  );
}

export function ToggleRow({ icon, title, subtitle, value, onChange, disabled }: { icon?: string; title: string; subtitle?: string; value: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  const t = useTheme();
  return (
    <Row
      icon={icon}
      title={title}
      subtitle={subtitle}
      onPress={disabled ? undefined : () => onChange(!value)}
      right={
        <Switch
          value={value}
          disabled={disabled}
          onValueChange={(v) => { tap(); onChange(v); }}
          trackColor={{ false: t.c.surface3, true: t.accent.base }}
          thumbColor={'#FFFFFF'}
        />
      }
    />
  );
}

export function Divider({ inset = 0 }: { inset?: number }) {
  const t = useTheme();
  return <View style={{ height: StyleSheet.hairlineWidth, backgroundColor: t.c.borderStrong, marginLeft: inset }} />;
}

export function Group({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  const items = React.Children.toArray(children).filter(Boolean);
  return (
    <Card padding={0} style={[{ paddingHorizontal: 16 }, style]}>
      {items.map((c, i) => (
        <View key={i}>
          {i > 0 ? <Divider /> : null}
          {c}
        </View>
      ))}
    </Card>
  );
}

// ---------------- Fecha y hora ----------------

export function DateField({ label, value, onChange, clearable = true, placeholder = 'Sin fecha', minimumDate, maximumDate }: {
  label?: string; value: string | null; onChange: (v: string | null) => void; clearable?: boolean; placeholder?: string; minimumDate?: Date; maximumDate?: Date;
}) {
  const t = useTheme();
  const [iosOpen, setIosOpen] = useState(false);
  const open = () => {
    tap();
    const current = value ? parseISODate(value) : new Date();
    if (Platform.OS === 'android') {
      DateTimePickerAndroid.open({
        value: current,
        mode: 'date',
        minimumDate,
        maximumDate,
        onChange: (e: any, d?: Date) => { if (e.type === 'set' && d) onChange(toISODate(d)); },
      });
    } else setIosOpen(true);
  };
  return (
    <View style={{ gap: 6, flex: 1 }}>
      {label ? <T variant="caption" secondary>{label}</T> : null}
      <Pressable onPress={open} style={pickerBox(t)}>
        <Icon name="CalendarDays" size={18} color={value ? t.accent.base : t.c.textMuted} />
        <T style={{ flex: 1 }} color={value ? t.c.text : t.c.textMuted} numberOfLines={1}>
          {value ? `${formatRelativeDay(value)} · ${formatUserDate(value)}` : placeholder}
        </T>
        {clearable && value ? (
          <Pressable hitSlop={10} onPress={() => onChange(null)}><Icon name="X" size={16} color={t.c.textMuted} /></Pressable>
        ) : null}
      </Pressable>
      {iosOpen && (
        <DateTimePicker value={value ? parseISODate(value) : new Date()} mode="date" onChange={(_: any, d?: Date) => { setIosOpen(false); if (d) onChange(toISODate(d)); }} />
      )}
    </View>
  );
}

export function TimeField({ label, value, onChange, clearable = true, placeholder = 'Sin hora' }: { label?: string; value: string | null; onChange: (v: string | null) => void; clearable?: boolean; placeholder?: string }) {
  const t = useTheme();
  const open = () => {
    tap();
    const d = new Date();
    if (isValidTime(value)) {
      const [h, m] = value.split(':').map(Number);
      d.setHours(h, m, 0, 0);
    } else d.setMinutes(0, 0, 0);
    if (Platform.OS === 'android') {
      DateTimePickerAndroid.open({
        value: d,
        mode: 'time',
        is24Hour: true,
        onChange: (e: any, sel?: Date) => { if (e.type === 'set' && sel) onChange(timeFromDate(sel)); },
      });
    }
  };
  return (
    <View style={{ gap: 6, flex: 1 }}>
      {label ? <T variant="caption" secondary>{label}</T> : null}
      <Pressable onPress={open} style={pickerBox(t)}>
        <Icon name="Clock" size={18} color={value ? t.accent.base : t.c.textMuted} />
        <T style={{ flex: 1 }} color={value ? t.c.text : t.c.textMuted}>{value ?? placeholder}</T>
        {clearable && value ? (
          <Pressable hitSlop={10} onPress={() => onChange(null)}><Icon name="X" size={16} color={t.c.textMuted} /></Pressable>
        ) : null}
      </Pressable>
    </View>
  );
}

const pickerBox = (t: Theme): ViewStyle => ({
  flexDirection: 'row', alignItems: 'center', gap: 10, height: 50, paddingHorizontal: 14, borderRadius: t.radius.md,
  backgroundColor: t.c.surface2, borderWidth: 1, borderColor: t.c.border,
});

// ---------------- Progreso ----------------

export function ProgressBar({ value, color, height = 8, track }: { value: number; color?: string; height?: number; track?: string }) {
  const t = useTheme();
  const anim = useRef(new Animated.Value(0)).current;
  const v = Math.max(0, Math.min(100, value || 0));
  useEffect(() => {
    Animated.timing(anim, { toValue: v, duration: 500, useNativeDriver: false }).start();
  }, [v, anim]);
  return (
    <View style={{ height, borderRadius: height / 2, backgroundColor: track ?? t.c.surface3, overflow: 'hidden' }}>
      <Animated.View style={{ height, borderRadius: height / 2, backgroundColor: color ?? t.accent.base, width: anim.interpolate({ inputRange: [0, 100], outputRange: ['0%', '100%'] }) }} />
    </View>
  );
}

export function ProgressRing({ value, size = 64, stroke = 7, color, children }: { value: number; size?: number; stroke?: number; color?: string; children?: React.ReactNode }) {
  const t = useTheme();
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const v = Math.max(0, Math.min(100, value || 0));
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} style={StyleSheet.absoluteFill}>
        <Circle cx={size / 2} cy={size / 2} r={r} stroke={t.c.surface3} strokeWidth={stroke} fill="none" />
        <Circle
          cx={size / 2} cy={size / 2} r={r} stroke={color ?? t.accent.base} strokeWidth={stroke} fill="none"
          strokeDasharray={`${circ} ${circ}`} strokeDashoffset={circ * (1 - v / 100)} strokeLinecap="round"
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      </Svg>
      {children}
    </View>
  );
}

// ---------------- Otros ----------------

export function Check({ checked, onPress, color, size = 26 }: { checked: boolean; onPress?: () => void; color?: string; size?: number }) {
  const t = useTheme();
  const c = color ?? t.accent.base;
  return (
    <Pressable
      onPress={() => { tap(); onPress?.(); }}
      hitSlop={10}
      accessibilityRole="checkbox"
      accessibilityState={{ checked }}
      style={{
        width: size, height: size, borderRadius: size / 2, borderWidth: 2, borderColor: checked ? c : t.c.borderStrong,
        backgroundColor: checked ? c : 'transparent', alignItems: 'center', justifyContent: 'center',
      }}
    >
      {checked ? <Icon name="Check" size={size * 0.6} color="#fff" strokeWidth={3} /> : null}
    </Pressable>
  );
}

export function EmptyState({ icon, title, text, action, onAction }: { icon: string; title: string; text?: string; action?: string; onAction?: () => void }) {
  const t = useTheme();
  return (
    <View style={{ alignItems: 'center', paddingVertical: 36, paddingHorizontal: 24, gap: 10 }}>
      <View style={{ width: 64, height: 64, borderRadius: 22, backgroundColor: t.accentSoft, alignItems: 'center', justifyContent: 'center', marginBottom: 6 }}>
        <Icon name={icon} size={28} color={t.accent.base} />
      </View>
      <T variant="heading" align="center">{title}</T>
      {text ? <T secondary align="center">{text}</T> : null}
      {action ? <Button title={action} onPress={onAction} full={false} size="sm" style={{ marginTop: 8 }} /> : null}
    </View>
  );
}

export function Avatar({ name, color, size = 44 }: { name: string; color: string; size?: number }) {
  return (
    <LinearGradient colors={[color, color + 'AA']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ width: size, height: size, borderRadius: size / 2, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ color: '#fff', fontFamily: FONT.semibold, fontSize: size * 0.38 }}>{initials(name)}</Text>
    </LinearGradient>
  );
}

export function Badge({ label, color }: { label: string; color?: string }) {
  const t = useTheme();
  const c = color ?? t.accent.base;
  return (
    <View style={{ paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8, backgroundColor: c + (t.dark ? '26' : '1A'), alignSelf: 'flex-start' }}>
      <T variant="small" color={c}>{label}</T>
    </View>
  );
}

/** Hoja inferior modal con animación. */
export function Sheet({ visible, onClose, title, children }: { visible: boolean; onClose: () => void; title?: string; children: React.ReactNode }) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const y = useRef(new Animated.Value(400)).current;
  const fade = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.spring(y, { toValue: 0, useNativeDriver: true, damping: 22, stiffness: 220 }),
        Animated.timing(fade, { toValue: 1, duration: 180, useNativeDriver: true }),
      ]).start();
    } else {
      y.setValue(400);
      fade.setValue(0);
    }
  }, [visible, y, fade]);
  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={onClose} statusBarTranslucent navigationBarTranslucent>
      <Animated.View style={[StyleSheet.absoluteFill, { backgroundColor: t.c.overlay, opacity: fade }]}>
        <Pressable style={{ flex: 1 }} onPress={onClose} accessibilityLabel="Cerrar" />
      </Animated.View>
      <Animated.View style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, transform: [{ translateY: y }],
        backgroundColor: t.c.bgElevated, borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingTop: 10,
        paddingBottom: insets.bottom + 16, paddingHorizontal: 18, borderWidth: 1, borderColor: t.c.border,
      }}>
        <View style={{ alignSelf: 'center', width: 40, height: 4, borderRadius: 2, backgroundColor: t.c.borderStrong, marginBottom: 14 }} />
        {title ? <T variant="heading" style={{ marginBottom: 14 }}>{title}</T> : null}
        {children}
      </Animated.View>
    </Modal>
  );
}

export function Stat({ label, value, color, icon }: { label: string; value: string; color?: string; icon?: string }) {
  const t = useTheme();
  return (
    <View style={{ flex: 1, gap: 6 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
        {icon ? <Icon name={icon} size={14} color={color ?? t.c.textSecondary} /> : null}
        <T variant="small" secondary>{label}</T>
      </View>
      <T variant="heading" color={color} numberOfLines={1} style={{ fontFamily: FONT.bold }}>{value}</T>
    </View>
  );
}

export function FormActions({ onSave, onDelete, saving, saveLabel = 'Guardar' }: { onSave: () => void; onDelete?: () => void; saving?: boolean; saveLabel?: string }) {
  return (
    <View style={{ gap: 10, marginTop: 8 }}>
      <Button title={saveLabel} icon="Check" onPress={onSave} loading={saving} size="lg" />
      {onDelete ? <Button title="Eliminar" icon="Trash2" variant="ghost" onPress={onDelete} /> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingBottom: 14, gap: 12 },
});
