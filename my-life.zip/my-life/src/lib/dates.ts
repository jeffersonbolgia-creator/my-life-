// Utilidades de fecha. Trabajamos siempre con fechas locales en formato
// 'YYYY-MM-DD' y horas 'HH:mm' para evitar problemas de zona horaria.

export const WEEKDAYS_LONG = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
export const WEEKDAYS_SHORT = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
export const WEEKDAYS_LETTER = ['D', 'L', 'M', 'M', 'J', 'V', 'S'];
export const MONTHS_LONG = [
  'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
  'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre',
];
export const MONTHS_SHORT = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];

/** Orden de días de la semana empezando por lunes (0 = domingo según JS). */
export const WEEK_ORDER = [1, 2, 3, 4, 5, 6, 0];

const pad = (n: number) => (n < 10 ? '0' + n : String(n));

export function toISODate(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function parseISODate(s: string): Date {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

export function isValidISODate(s: string | null | undefined): s is string {
  if (!s || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = parseISODate(s);
  return toISODate(d) === s;
}

export function todayISO(now: Date = new Date()): string {
  return toISODate(now);
}

export function addDays(s: string, n: number): string {
  const d = parseISODate(s);
  d.setDate(d.getDate() + n);
  return toISODate(d);
}

/** Suma meses manteniendo el día; si no existe (31 de febrero) usa el último día del mes. */
export function addMonths(s: string, n: number): string {
  const d = parseISODate(s);
  const day = d.getDate();
  const target = new Date(d.getFullYear(), d.getMonth() + n, 1);
  const dim = daysInMonth(target.getFullYear(), target.getMonth());
  target.setDate(Math.min(day, dim));
  return toISODate(target);
}

export function daysInMonth(year: number, monthIndex: number): number {
  return new Date(year, monthIndex + 1, 0).getDate();
}

export function weekday(s: string): number {
  return parseISODate(s).getDay();
}

/** Lunes de la semana de la fecha dada. */
export function startOfWeek(s: string): string {
  const wd = weekday(s);
  const diff = wd === 0 ? -6 : 1 - wd;
  return addDays(s, diff);
}

export function startOfMonth(s: string): string {
  return s.slice(0, 7) + '-01';
}

export function endOfMonth(s: string): string {
  const d = parseISODate(s);
  return `${s.slice(0, 7)}-${pad(daysInMonth(d.getFullYear(), d.getMonth()))}`;
}

export function monthKey(s: string): string {
  return s.slice(0, 7);
}

export function addMonthsToKey(key: string, n: number): string {
  return monthKey(addMonths(key + '-01', n));
}

export function diffDays(a: string, b: string): number {
  // a - b en días
  const da = parseISODate(a);
  const db = parseISODate(b);
  return Math.round((Date.UTC(da.getFullYear(), da.getMonth(), da.getDate()) -
    Date.UTC(db.getFullYear(), db.getMonth(), db.getDate())) / 86400000);
}

export function rangeDays(from: string, to: string): string[] {
  const out: string[] = [];
  let cur = from;
  let guard = 0;
  while (cur <= to && guard < 3700) {
    out.push(cur);
    cur = addDays(cur, 1);
    guard++;
  }
  return out;
}

export function isValidTime(t: string | null | undefined): t is string {
  return !!t && /^([01]\d|2[0-3]):[0-5]\d$/.test(t);
}

export function timeToMinutes(t: string): number {
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
}

export function minutesToTime(min: number): string {
  const m = ((min % 1440) + 1440) % 1440;
  return `${pad(Math.floor(m / 60))}:${pad(m % 60)}`;
}

export function combineDateTime(date: string, time: string | null | undefined): Date {
  const d = parseISODate(date);
  if (isValidTime(time)) {
    const [h, m] = time.split(':').map(Number);
    d.setHours(h, m, 0, 0);
  }
  return d;
}

export function timeFromDate(d: Date): string {
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function capitalize(s: string): string {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
}

/** "miércoles 4 de noviembre" */
export function formatLongDate(s: string): string {
  const d = parseISODate(s);
  return `${WEEKDAYS_LONG[d.getDay()]} ${d.getDate()} de ${MONTHS_LONG[d.getMonth()]}`;
}

/** "4 nov" o "4 nov 2025" si no es el año actual */
export function formatShortDate(s: string, now: Date = new Date()): string {
  const d = parseISODate(s);
  const base = `${d.getDate()} ${MONTHS_SHORT[d.getMonth()]}`;
  return d.getFullYear() === now.getFullYear() ? base : `${base} ${d.getFullYear()}`;
}

/** "Hoy", "Mañana", "Ayer" o "vie 7 nov" */
export function formatRelativeDay(s: string, now: Date = new Date()): string {
  const diff = diffDays(s, toISODate(now));
  if (diff === 0) return 'Hoy';
  if (diff === 1) return 'Mañana';
  if (diff === -1) return 'Ayer';
  const d = parseISODate(s);
  const label = `${WEEKDAYS_SHORT[d.getDay()]} ${formatShortDate(s, now)}`;
  return capitalize(label);
}

export function formatMonthYear(key: string): string {
  const [y, m] = key.split('-').map(Number);
  return `${capitalize(MONTHS_LONG[m - 1])} ${y}`;
}

export function ageFromBirth(birth: string, now: Date = new Date()): number | null {
  if (!isValidISODate(birth)) return null;
  const b = parseISODate(birth);
  let age = now.getFullYear() - b.getFullYear();
  const m = now.getMonth() - b.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < b.getDate())) age--;
  return age >= 0 && age < 130 ? age : null;
}

export function greetingFor(now: Date = new Date()): string {
  const h = now.getHours();
  if (h >= 5 && h < 13) return 'Buen día';
  if (h >= 13 && h < 20) return 'Buenas tardes';
  return 'Buenas noches';
}

/** Matriz de semanas (lunes a domingo) para una vista mensual. */
export function monthGrid(key: string): string[][] {
  const first = key + '-01';
  let cur = startOfWeek(first);
  const last = endOfMonth(first);
  const weeks: string[][] = [];
  while (cur <= last || weeks.length < 6) {
    const week: string[] = [];
    for (let i = 0; i < 7; i++) {
      week.push(cur);
      cur = addDays(cur, 1);
    }
    weeks.push(week);
    if (weeks.length >= 6) break;
  }
  return weeks;
}

/** Interpreta una fecha escrita "DD/MM/AAAA" o "AAAA-MM-DD". */
export function parseUserDate(input: string): string | null {
  const s: string = input.trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return isValidISODate(s) ? s : null;
  const m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/);
  if (!m) return null;
  const iso = `${m[3]}-${pad(Number(m[2]))}-${pad(Number(m[1]))}`;
  return isValidISODate(iso) ? iso : null;
}

export function formatUserDate(iso: string): string {
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
}
