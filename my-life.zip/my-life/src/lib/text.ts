const ACCENTS: Record<string, string> = {
  á: 'a', à: 'a', ä: 'a', â: 'a', ã: 'a',
  é: 'e', è: 'e', ë: 'e', ê: 'e',
  í: 'i', ì: 'i', ï: 'i', î: 'i',
  ó: 'o', ò: 'o', ö: 'o', ô: 'o', õ: 'o',
  ú: 'u', ù: 'u', ü: 'u', û: 'u',
  ñ: 'n', ç: 'c',
};

/** Minúsculas, sin acentos y sin espacios repetidos (para búsquedas y respuestas de seguridad). */
export function normalizeText(s: string): string {
  return (s || '')
    .toLowerCase()
    .replace(/[áàäâãéèëêíìïîóòöôõúùüûñç]/g, (c) => ACCENTS[c] ?? c)
    .replace(/\s+/g, ' ')
    .trim();
}

export function matchesSearch(haystack: string, query: string): boolean {
  const q = normalizeText(query);
  if (!q) return true;
  const h = normalizeText(haystack);
  return q.split(' ').every((part) => h.includes(part));
}

export function firstName(name: string): string {
  return (name || '').trim().split(/\s+/)[0] || '';
}

export function initials(name: string): string {
  const parts = (name || '').trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return '?';
  return (parts[0][0] + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase();
}

export function plural(n: number, one: string, many: string): string {
  return `${n} ${n === 1 ? one : many}`;
}

export function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}
