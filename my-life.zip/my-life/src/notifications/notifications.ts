// Notificaciones locales reales de Android (no dependen de servidores).
// Se programan en el sistema, así que suenan aunque la app esté cerrada.

import * as Notifications from 'expo-notifications';
import { Platform, Linking } from 'react-native';
import { buildNotificationPlan, type ChannelId, type PlannedNotification } from '../logic/notificationPlan';
import { eventsRepo, goalsRepo, habitsRepo, profilesRepo, remindersRepo, tasksRepo } from '../db/repos';

const CHANNELS: { id: ChannelId; name: string; description: string }[] = [
  { id: 'tasks', name: 'Tareas', description: 'Recordatorios de tareas con fecha' },
  { id: 'events', name: 'Eventos y cumpleaños', description: 'Avisos del calendario' },
  { id: 'habits', name: 'Hábitos', description: 'Recordatorios de tus hábitos' },
  { id: 'payments', name: 'Pagos', description: 'Recordatorios de pagos' },
  { id: 'reminders', name: 'Recordatorios', description: 'Recordatorios generales' },
  { id: 'goals', name: 'Objetivos', description: 'Fechas límite de objetivos' },
  { id: 'summary', name: 'Resumen diario', description: 'Resumen programado de tu día' },
];

let initialized = false;

export async function initNotifications(): Promise<void> {
  if (initialized) return;
  initialized = true;
  Notifications.setNotificationHandler({
    handleNotification: async () =>
      ({
        shouldShowAlert: true,
        shouldShowBanner: true,
        shouldShowList: true,
        shouldPlaySound: true,
        shouldSetBadge: false,
      }) as any,
  });
  if (Platform.OS === 'android') {
    for (const c of CHANNELS) {
      try {
        await Notifications.setNotificationChannelAsync(c.id, {
          name: c.name,
          description: c.description,
          importance: Notifications.AndroidImportance.HIGH,
          vibrationPattern: [0, 220, 120, 220],
          lightColor: '#8B5CF6',
          lockscreenVisibility: Notifications.AndroidNotificationVisibility.PRIVATE,
          sound: 'default',
          enableVibrate: true,
        });
      } catch (e) {
        console.warn('No se pudo crear el canal', c.id, e);
      }
    }
  }
}

export type PermissionState = 'granted' | 'denied' | 'undetermined';

export async function getPermission(): Promise<PermissionState> {
  try {
    const p = await Notifications.getPermissionsAsync();
    if (p.granted) return 'granted';
    return p.canAskAgain === false || p.status === 'denied' ? 'denied' : 'undetermined';
  } catch {
    return 'undetermined';
  }
}

export async function requestPermission(): Promise<PermissionState> {
  try {
    const p = await Notifications.requestPermissionsAsync();
    return p.granted ? 'granted' : p.canAskAgain === false ? 'denied' : 'undetermined';
  } catch {
    return 'denied';
  }
}

export function openSystemNotificationSettings() {
  Linking.openSettings().catch(() => {});
}

function toTrigger(n: PlannedNotification): any {
  const t = n.trigger;
  const T = Notifications.SchedulableTriggerInputTypes;
  if (t.kind === 'date') return { type: T.DATE, date: t.date, channelId: n.channel };
  if (t.kind === 'daily') return { type: T.DAILY, hour: t.hour, minute: t.minute, channelId: n.channel };
  return { type: T.WEEKLY, weekday: t.weekday, hour: t.hour, minute: t.minute, channelId: n.channel };
}

async function cancelProfile(profileId: number) {
  const prefix = `p${profileId}:`;
  const all = await Notifications.getAllScheduledNotificationsAsync();
  for (const n of all) {
    if (n.identifier?.startsWith(prefix)) {
      await Notifications.cancelScheduledNotificationAsync(n.identifier).catch(() => {});
    }
  }
}

/** Reprograma todas las notificaciones de un perfil según sus datos actuales. */
export async function syncProfileNotifications(profileId: number): Promise<number> {
  await initNotifications();
  const profile = await profilesRepo.get(profileId);
  if (!profile) return 0;
  await cancelProfile(profileId);
  if ((await getPermission()) !== 'granted') return 0;
  const [tasks, events, habits, reminders, goals] = await Promise.all([
    tasksRepo.list(profileId),
    eventsRepo.list(profileId),
    habitsRepo.list(profileId),
    remindersRepo.list(profileId),
    goalsRepo.list(profileId),
  ]);
  const plan = buildNotificationPlan({
    profileId,
    profileName: profile.name.split(' ')[0],
    settings: profile.settings.notifications,
    tasks,
    events,
    habits,
    reminders,
    goals,
    now: new Date(),
  });
  let ok = 0;
  for (const n of plan) {
    try {
      await Notifications.scheduleNotificationAsync({
        identifier: n.id,
        content: { title: n.title, body: n.body, data: n.data, sound: 'default' },
        trigger: toTrigger(n),
      });
      ok++;
    } catch (e) {
      console.warn('No se pudo programar', n.id, e);
    }
  }
  return ok;
}

export async function cancelAllForProfile(profileId: number) {
  await cancelProfile(profileId).catch(() => {});
}

const timers = new Map<number, ReturnType<typeof setTimeout>>();

/** Reprograma con una pequeña demora para agrupar varios cambios seguidos. */
export function scheduleSync(profileId: number, delay = 1200) {
  const prev = timers.get(profileId);
  if (prev) clearTimeout(prev);
  timers.set(
    profileId,
    setTimeout(() => {
      timers.delete(profileId);
      syncProfileNotifications(profileId).catch((e) => console.warn('sync notifications', e));
    }, delay),
  );
}

/** Envía una notificación de prueba en 5 segundos. */
export async function sendTestNotification(name: string): Promise<boolean> {
  await initNotifications();
  if ((await getPermission()) !== 'granted') return false;
  await Notifications.scheduleNotificationAsync({
    content: { title: 'MY LIFE', body: `¡Listo, ${name}! Las notificaciones funcionan.`, sound: 'default' },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL, seconds: 5, channelId: 'reminders' } as any,
  });
  return true;
}

export async function countScheduled(profileId: number): Promise<number> {
  const all = await Notifications.getAllScheduledNotificationsAsync();
  return all.filter((n) => n.identifier?.startsWith(`p${profileId}:`)).length;
}
