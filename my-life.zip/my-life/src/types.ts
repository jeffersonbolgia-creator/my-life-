import type { CurrencyCode } from './lib/money';

export type ThemeMode = 'dark' | 'light' | 'system';
export type AccentKey = 'violet' | 'indigo' | 'fuchsia' | 'blue' | 'emerald' | 'amber' | 'rose';

export type DashboardCardKey =
  | 'today'
  | 'tasks'
  | 'events'
  | 'reminders'
  | 'habits'
  | 'goals'
  | 'finance'
  | 'weekly';

export interface NotificationSettings {
  enabled: boolean;
  tasks: boolean;
  events: boolean;
  habits: boolean;
  payments: boolean;
  reminders: boolean;
  goals: boolean;
  dailySummary: boolean;
  dailySummaryTime: string; // HH:mm
  defaultTime: string; // hora para avisos sin horario
  discreet: boolean; // ocultar el contenido en la notificación
}

export interface ProfileSettings {
  themeMode: ThemeMode;
  accent: AccentKey;
  gradients: boolean;
  haptics: boolean;
  compact: boolean;
  dashboardCards: { key: DashboardCardKey; visible: boolean }[];
  showWeeklySummary: boolean;
  showMonthlySummary: boolean;
  autoLockMinutes: number; // 0 = inmediato, -1 = nunca
  biometrics: boolean;
  pinLength: 4 | 6;
  notifications: NotificationSettings;
  currency: CurrencyCode;
  initialBalance: number; // centavos
  initialBalanceDate: string | null;
}

export interface ProfileAnswers {
  studiesAtSchool?: boolean;
  schoolLevel?: string;
  studies?: boolean;
  studyWhat?: string;
  works?: boolean;
  workWhat?: string;
  activities?: string[];
  interests?: string[];
  goals?: string[];
  habitsToImprove?: string[];
  wakeTime?: string;
  sleepTime?: string;
  scheduleDays?: number[];
  scheduleStart?: string;
  scheduleEnd?: string;
}

export interface Profile {
  id: number;
  name: string;
  birthDate: string | null;
  age: number | null;
  avatarColor: string;
  answers: ProfileAnswers;
  settings: ProfileSettings;
  securityQuestion: string;
  createdAt: string;
}

export type Priority = 0 | 1 | 2; // baja, media, alta

export interface Task {
  id: number;
  profileId: number;
  title: string;
  description: string;
  dueDate: string | null;
  dueTime: string | null;
  priority: Priority;
  category: string;
  remindMinutes: number | null; // null = sin aviso; 0 = a la hora
  completedAt: string | null;
  createdAt: string;
}

export type EventType = 'event' | 'appointment' | 'birthday' | 'important' | 'schedule';
export type Recurrence = 'none' | 'daily' | 'weekly' | 'monthly' | 'yearly';

export interface CalendarEvent {
  id: number;
  profileId: number;
  title: string;
  type: EventType;
  date: string;
  startTime: string | null;
  endTime: string | null;
  allDay: boolean;
  recurrence: Recurrence;
  weekdays: number[]; // para recurrencia semanal (0 = domingo)
  untilDate: string | null;
  remindMinutes: number | null;
  location: string;
  notes: string;
  createdAt: string;
}

export type GoalTerm = 'short' | 'long';

export interface Goal {
  id: number;
  profileId: number;
  title: string;
  description: string;
  term: GoalTerm;
  targetDate: string | null;
  progress: number; // 0..100
  completedAt: string | null;
  createdAt: string;
}

export type HabitFrequency = 'daily' | 'weekly';

export interface Habit {
  id: number;
  profileId: number;
  title: string;
  frequency: HabitFrequency;
  weekdays: number[]; // para 'daily': días en que aplica (vacío = todos)
  targetPerWeek: number; // para 'weekly'
  reminderTime: string | null;
  color: string;
  icon: string;
  archived: boolean;
  createdAt: string;
}

export interface NoteItem {
  text: string;
  done: boolean;
}

export interface Note {
  id: number;
  profileId: number;
  title: string;
  body: string;
  category: string;
  isList: boolean;
  items: NoteItem[];
  favorite: boolean;
  createdAt: string;
  updatedAt: string;
}

export type TxKind = 'income' | 'expense';

export interface Transaction {
  id: number;
  profileId: number;
  kind: TxKind;
  name: string;
  emoji: string;
  category: string;
  quantity: number;
  unitPrice: number | null; // centavos
  amount: number; // centavos, siempre positivo
  date: string;
  description: string;
  createdAt: string;
}

export type ReminderKind = 'general' | 'payment';
export type ReminderRepeat = 'none' | 'daily' | 'weekly' | 'monthly';

export interface Reminder {
  id: number;
  profileId: number;
  title: string;
  kind: ReminderKind;
  date: string;
  time: string;
  repeat: ReminderRepeat;
  amount: number | null;
  notes: string;
  done: boolean;
  createdAt: string;
}
