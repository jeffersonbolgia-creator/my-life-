// Crea un perfil nuevo a partir de las respuestas de la bienvenida,
// y arma su espacio inicial (horarios, cumpleaños, objetivos y hábitos).

import { profilesRepo, eventsRepo, goalsRepo, habitsRepo } from '../db/repos';
import { defaultSettings } from '../db/defaults';
import { setPin, setRecoveryAnswer, deleteSecrets } from '../security/pin';
import { ageFromBirth, isValidISODate, isValidTime, todayISO, minutesToTime, timeToMinutes } from '../lib/dates';
import type { AccentKey, ProfileAnswers, ThemeMode } from '../types';

export interface ScheduleBlock {
  title: string;
  days: number[];
  start: string | null;
  end: string | null;
}

export interface SetupData {
  name: string;
  birthDate: string | null;
  age: number | null;
  answers: ProfileAnswers;
  schedules: ScheduleBlock[];
  goals: string[];
  habits: string[];
  pin: string;
  pinLength: 4 | 6;
  securityQuestion: string;
  securityAnswer: string;
  biometrics: boolean;
  themeMode: ThemeMode;
  accent: AccentKey;
  avatarColor: string;
}

export const HABIT_SUGGESTIONS: { title: string; icon: string; color: string }[] = [
  { title: 'Tomar 2 litros de agua', icon: 'Droplets', color: '#3B82F6' },
  { title: 'Leer 20 minutos', icon: 'BookOpen', color: '#F59E0B' },
  { title: 'Hacer ejercicio', icon: 'Dumbbell', color: '#10B981' },
  { title: 'Dormir temprano', icon: 'Moon', color: '#6366F1' },
  { title: 'Meditar', icon: 'Brain', color: '#D946EF' },
  { title: 'Estudiar', icon: 'GraduationCap', color: '#8B5CF6' },
  { title: 'Caminar', icon: 'Footprints', color: '#06B6D4' },
  { title: 'Menos celular', icon: 'Smartphone', color: '#F43F5E' },
  { title: 'Ordenar mi cuarto', icon: 'House', color: '#84CC16' },
  { title: 'Registrar mis gastos', icon: 'Wallet', color: '#F97316' },
];

export function habitStyleFor(title: string): { icon: string; color: string } {
  const s = HABIT_SUGGESTIONS.find((h) => h.title === title);
  return s ? { icon: s.icon, color: s.color } : { icon: 'Sparkles', color: '#8B5CF6' };
}

export async function createProfileFromSetup(d: SetupData, otherProfileIds: number[]): Promise<number> {
  const name = d.name.trim();
  if (!name) throw new Error('Falta el nombre');
  const birth = isValidISODate(d.birthDate) ? d.birthDate : null;
  const age = birth ? ageFromBirth(birth) : d.age;
  const settings = defaultSettings();
  settings.themeMode = d.themeMode;
  settings.accent = d.accent;
  settings.pinLength = d.pinLength;
  settings.biometrics = d.biometrics;
  if (isValidTime(d.answers.wakeTime)) {
    settings.notifications.dailySummary = true;
    settings.notifications.dailySummaryTime = minutesToTime(timeToMinutes(d.answers.wakeTime) + 15);
  }

  const pid = await profilesRepo.create({
    name,
    birthDate: birth,
    age: age ?? null,
    avatarColor: d.avatarColor,
    answers: d.answers,
    settings,
    securityQuestion: d.securityQuestion,
  });

  try {
    await setPin(pid, d.pin);
    await setRecoveryAnswer(pid, d.securityAnswer);
  } catch (e) {
    await profilesRepo.remove(pid);
    await deleteSecrets(pid).catch(() => {});
    throw e;
  }

  const today = todayISO();
  // Horarios de colegio / estudio / trabajo como eventos semanales
  for (const s of d.schedules) {
    if (!s.days.length) continue;
    await eventsRepo.create(pid, {
      title: s.title,
      type: 'schedule',
      date: today,
      startTime: isValidTime(s.start) ? s.start : null,
      endTime: isValidTime(s.end) ? s.end : null,
      allDay: !isValidTime(s.start),
      recurrence: 'weekly',
      weekdays: s.days,
      untilDate: null,
      remindMinutes: isValidTime(s.start) ? 30 : null,
      location: '',
      notes: '',
    });
  }
  // Cumpleaños propio
  if (birth) {
    await eventsRepo.create(pid, {
      title: name.split(' ')[0],
      type: 'birthday',
      date: birth,
      startTime: null,
      endTime: null,
      allDay: true,
      recurrence: 'yearly',
      weekdays: [],
      untilDate: null,
      remindMinutes: 0,
      location: '',
      notes: '¡Tu cumpleaños!',
    });
  }
  for (const g of d.goals.map((x) => x.trim()).filter(Boolean)) {
    await goalsRepo.create(pid, { title: g, description: '', term: 'short', targetDate: null, progress: 0 });
  }
  for (const h of d.habits.map((x) => x.trim()).filter(Boolean)) {
    const st = habitStyleFor(h);
    await habitsRepo.create(pid, { title: h, frequency: 'daily', weekdays: [], targetPerWeek: 3, reminderTime: null, color: st.color, icon: st.icon });
  }
  void otherProfileIds;
  return pid;
}
