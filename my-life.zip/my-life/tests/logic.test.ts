import { test } from 'node:test';
import assert from 'node:assert/strict';
import type { CalendarEvent, Habit, Task, Transaction, Reminder, Goal } from '../src/types';
import { currentStreak, bestStreak, completionRate, isScheduledOn, weekProgress } from '../src/logic/habits';
import { occurrencesInRange, birthdayAge } from '../src/logic/calendar';
import * as F from '../src/logic/finance';
import { buildNotificationPlan } from '../src/logic/notificationPlan';
import { computePeriodStats, periodRange } from '../src/logic/stats';
import { defaultSettings } from '../src/db/defaults';
import { addDays } from '../src/lib/dates';

const habit = (p: Partial<Habit>): Habit => ({
  id: 1, profileId: 1, title: 'Leer', frequency: 'daily', weekdays: [], targetPerWeek: 3, reminderTime: null,
  color: '#8B5CF6', icon: 'book', archived: false, createdAt: '2026-10-01T10:00:00', ...p,
});

test('hábitos: racha diaria (hoy sin marcar no corta la racha)', () => {
  const h = habit({});
  const logs = new Set(['2026-11-01', '2026-11-02', '2026-11-03']);
  assert.equal(currentStreak(h, logs, '2026-11-04'), 3);
  logs.add('2026-11-04');
  assert.equal(currentStreak(h, logs, '2026-11-04'), 4);
  assert.equal(currentStreak(h, new Set(['2026-11-01', '2026-11-02']), '2026-11-04'), 0);
});

test('hábitos: días específicos (lunes a viernes) no cortan la racha el fin de semana', () => {
  const h = habit({ weekdays: [1, 2, 3, 4, 5] });
  // vie 30/10, lun 2/11, mar 3/11
  const logs = new Set(['2026-10-30', '2026-11-02', '2026-11-03']);
  assert.equal(currentStreak(h, logs, '2026-11-04'), 3);
  assert.ok(!isScheduledOn(h, '2026-11-01'));
  assert.equal(bestStreak(h, logs, '2026-11-04'), 3);
});

test('hábitos: objetivo semanal', () => {
  const h = habit({ frequency: 'weekly', targetPerWeek: 2, createdAt: '2026-10-12T09:00:00' });
  const logs = new Set(['2026-10-13', '2026-10-15', '2026-10-20', '2026-10-22', '2026-10-27', '2026-10-28', '2026-11-03']);
  assert.equal(currentStreak(h, logs, '2026-11-04'), 3); // semana actual aún incompleta
  logs.add('2026-11-04');
  assert.equal(currentStreak(h, logs, '2026-11-04'), 4);
  assert.deepEqual(weekProgress(h, logs, '2026-11-04'), { done: 2, target: 2 });
});

test('hábitos: porcentaje de cumplimiento', () => {
  const h = habit({ createdAt: '2026-11-01T08:00:00' });
  const logs = new Set(['2026-11-01', '2026-11-03']);
  assert.equal(completionRate(h, logs, '2026-11-01', '2026-11-04'), 50);
});

const ev = (p: Partial<CalendarEvent>): CalendarEvent => ({
  id: 1, profileId: 1, title: 'Evento', type: 'event', date: '2026-11-04', startTime: '10:00', endTime: null, allDay: false,
  recurrence: 'none', weekdays: [], untilDate: null, remindMinutes: null, location: '', notes: '', createdAt: '2026-11-01T00:00:00', ...p,
});

test('calendario: repeticiones', () => {
  const weekly = ev({ id: 2, title: 'Colegio', type: 'schedule', recurrence: 'weekly', weekdays: [1, 2, 3, 4, 5], date: '2026-11-02', startTime: '07:30' });
  const occ = occurrencesInRange([weekly], '2026-11-02', '2026-11-08');
  assert.equal(occ.length, 5);
  const monthly = ev({ id: 3, recurrence: 'monthly', date: '2026-01-31' });
  const m = occurrencesInRange([monthly], '2026-02-01', '2026-04-30').map((o) => o.date);
  assert.deepEqual(m, ['2026-02-28', '2026-03-31', '2026-04-30']);
  const bday = ev({ id: 4, type: 'birthday', title: 'Mamá', recurrence: 'yearly', date: '1975-03-12', allDay: true });
  const b = occurrencesInRange([bday], '2027-01-01', '2027-12-31');
  assert.equal(b.length, 1);
  assert.equal(b[0].date, '2027-03-12');
  assert.equal(birthdayAge(bday, '2027-03-12'), 52);
  const until = ev({ id: 5, recurrence: 'daily', date: '2026-11-01', untilDate: '2026-11-03' });
  assert.equal(occurrencesInRange([until], '2026-10-01', '2026-12-01').length, 3);
});

test('calendario: orden por día y hora', () => {
  const a = ev({ id: 1, startTime: '18:00' });
  const b = ev({ id: 2, startTime: '08:00' });
  const c = ev({ id: 3, allDay: true, startTime: null });
  const occ = occurrencesInRange([a, b, c], '2026-11-04', '2026-11-04');
  assert.deepEqual(occ.map((o) => o.event.id), [3, 2, 1]);
});

const tx = (p: Partial<Transaction>): Transaction => ({
  id: 1, profileId: 1, kind: 'expense', name: 'x', emoji: '', category: 'Otros', quantity: 1, unitPrice: null, amount: 100,
  date: '2026-11-04', description: '', createdAt: '2026-11-04T00:00:00', ...p,
});

test('finanzas: resumen del mes, saldo y categorías', () => {
  const txs = [
    tx({ kind: 'income', amount: 50000000, date: '2026-11-01', category: 'Sueldo' }),
    tx({ kind: 'expense', amount: 600000, date: '2026-11-02', category: 'Comida' }),
    tx({ kind: 'expense', amount: 400000, date: '2026-11-03', category: 'Transporte' }),
    tx({ kind: 'expense', amount: 1000000, date: '2026-10-20', category: 'Comida' }),
  ];
  const s = F.monthSummary(txs, '2026-11');
  assert.equal(s.income, 50000000);
  assert.equal(s.expense, 1000000);
  assert.equal(F.availableBalance(txs, 2000000, null), 2000000 + 50000000 - 2000000);
  assert.equal(F.availableBalance(txs, 2000000, '2026-11-01'), 2000000 + 50000000 - 1000000);
  const cats = F.categoryBreakdown(txs, '2026-11');
  assert.equal(cats[0].category, 'Comida');
  assert.equal(cats[0].percent, 60);
  const series = F.monthlySeries(txs, '2026-11', 3);
  assert.deepEqual(series.map((x) => x.month), ['2026-09', '2026-10', '2026-11']);
  assert.equal(series[1].expense, 1000000);
  assert.equal(F.percentChange(150, 100), 50);
  assert.equal(F.percentChange(100, 0), null);
});

test('notificaciones: plan completo y respetando configuración', () => {
  const now = new Date(2026, 10, 4, 18, 0);
  const s = defaultSettings().notifications;
  const task: Task = {
    id: 7, profileId: 1, title: 'Entregar TP', description: '', dueDate: '2026-11-05', dueTime: '10:00', priority: 2,
    category: 'Estudio', remindMinutes: 60, completedAt: null, createdAt: '2026-11-01T00:00:00',
  };
  const pastTask: Task = { ...task, id: 8, dueDate: '2026-11-01' };
  const doneTask: Task = { ...task, id: 9, completedAt: '2026-11-03T00:00:00' };
  const rem: Reminder = {
    id: 3, profileId: 1, title: 'Pagar internet', kind: 'payment', date: '2026-11-10', time: '09:00', repeat: 'monthly',
    amount: 1500000, notes: '', done: false, createdAt: '2026-11-01T00:00:00',
  };
  const h = habit({ id: 4, reminderTime: '21:00', weekdays: [1, 3, 5] });
  const goal: Goal = { id: 5, profileId: 1, title: 'Ahorrar', description: '', term: 'short', targetDate: '2026-11-20', progress: 40, completedAt: null, createdAt: '2026-11-01T00:00:00' };
  const birthday = ev({ id: 6, type: 'birthday', title: 'Mamá', recurrence: 'yearly', date: '1975-11-12', allDay: true, remindMinutes: 0 });
  const plan = buildNotificationPlan({
    profileId: 1, profileName: 'Juan', settings: s, tasks: [task, pastTask, doneTask], events: [birthday], habits: [h], reminders: [rem], goals: [goal], now,
  });
  const ids = plan.map((p) => p.id);
  assert.ok(ids.includes('p1:task:7'));
  assert.ok(!ids.includes('p1:task:8'));
  assert.ok(!ids.includes('p1:task:9'));
  const t = plan.find((p) => p.id === 'p1:task:7')!;
  assert.equal(t.trigger.kind, 'date');
  assert.equal((t.trigger as any).date.getHours(), 9); // 1 h antes de las 10
  assert.ok(ids.includes('p1:rem:3:2026-11-10'));
  assert.ok(ids.includes('p1:rem:3:2026-12-10'));
  assert.equal(plan.filter((p) => p.id.startsWith('p1:habit:4')).length, 3);
  assert.equal((plan.find((p) => p.id === 'p1:habit:4:1')!.trigger as any).weekday, 2); // lunes = 2 en Android
  assert.ok(ids.includes('p1:goal:5:pre') && ids.includes('p1:goal:5:due'));
  assert.ok(ids.includes('p1:event:6:2026-11-12'));
  assert.ok(plan.every((p) => p.id.startsWith('p1:')));

  const off = buildNotificationPlan({
    profileId: 1, profileName: 'Juan', settings: { ...s, tasks: false, payments: false }, tasks: [task], events: [], habits: [], reminders: [rem], goals: [], now,
  });
  assert.equal(off.length, 0);
  const none = buildNotificationPlan({ profileId: 1, profileName: 'Juan', settings: { ...s, enabled: false }, tasks: [task], events: [], habits: [h], reminders: [], goals: [], now });
  assert.equal(none.length, 0);

  const discreet = buildNotificationPlan({ profileId: 2, profileName: 'Tomi', settings: { ...s, discreet: true }, tasks: [task], events: [], habits: [], reminders: [], goals: [], now });
  assert.equal(discreet[0].title, 'MY LIFE');
  assert.ok(!discreet[0].body.includes('TP'));
});

test('notificaciones: límite de avisos únicos', () => {
  const now = new Date(2026, 10, 4, 8, 0);
  const tasks: Task[] = Array.from({ length: 300 }, (_, i) => ({
    id: i + 1, profileId: 1, title: 'T' + i, description: '', dueDate: addDays('2026-11-05', i % 40), dueTime: '10:00', priority: 1,
    category: '', remindMinutes: 0, completedAt: null, createdAt: '2026-11-01T00:00:00',
  }));
  const plan = buildNotificationPlan({ profileId: 1, profileName: 'J', settings: defaultSettings().notifications, tasks, events: [], habits: [], reminders: [], goals: [], now });
  assert.equal(plan.length, 100);
  const times = plan.map((p) => (p.trigger as any).date.getTime());
  assert.deepEqual(times, [...times].sort((a, b) => a - b));
});

test('estadísticas por período', () => {
  const today = '2026-11-04';
  const range = periodRange('week', today);
  assert.deepEqual(range, { from: '2026-11-02', to: '2026-11-08' });
  const tasks = [
    { completedAt: '2026-11-03T10:00:00', dueDate: '2026-11-03' },
    { completedAt: null, dueDate: '2026-11-01' },
    { completedAt: null, dueDate: '2026-11-06' },
  ] as Task[];
  const st = computePeriodStats(range, today, {
    tasks, habits: [habit({ createdAt: '2026-11-02T00:00:00' })], habitLogs: new Map([[1, new Set(['2026-11-02', '2026-11-03'])]]),
    goals: [{ completedAt: '2026-11-02T00:00:00' } as Goal], txs: [tx({ amount: 500, date: '2026-11-03' })],
  });
  assert.equal(st.tasksCompleted, 1);
  assert.equal(st.tasksOverdue, 1);
  assert.equal(st.habitRate, 67);
  assert.equal(st.goalsAchieved, 1);
  assert.equal(st.expense, 500);
});
