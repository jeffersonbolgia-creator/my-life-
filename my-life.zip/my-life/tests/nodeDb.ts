import { DatabaseSync } from 'node:sqlite';
import type { Db, SqlValue } from '../src/db/db';

export function openNodeDb(): Db {
  const raw = new DatabaseSync(':memory:');
  let depth = 0;
  return {
    exec: async (sql) => {
      raw.exec(sql);
    },
    run: async (sql, params: SqlValue[] = []) => {
      const r = raw.prepare(sql).run(...params);
      return { lastInsertRowId: Number(r.lastInsertRowid), changes: Number(r.changes) };
    },
    all: async (sql, params: SqlValue[] = []) => raw.prepare(sql).all(...params).map((r) => ({ ...r })) as any[],
    first: async (sql, params: SqlValue[] = []) => {
      const r = raw.prepare(sql).get(...params);
      return r ? ({ ...r } as any) : null;
    },
    transaction: async (fn) => {
      if (depth > 0) return fn();
      depth++;
      raw.exec('BEGIN');
      try {
        await fn();
        raw.exec('COMMIT');
      } catch (e) {
        raw.exec('ROLLBACK');
        throw e;
      } finally {
        depth--;
      }
    },
  };
}
